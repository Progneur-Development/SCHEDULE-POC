package org.eclipse.nebula.jface.gridviewer;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.jface.viewers.ViewerRow;
import org.eclipse.nebula.widgets.grid.GridItem;

public class GridColumnLabelProvider extends ColumnLabelProvider
{
  public String getRowHeaderText(Object paramObject)
  {
    return null;
  }

  public void update(ViewerCell paramViewerCell)
  {
    super.update(paramViewerCell);
    String str = getRowHeaderText(paramViewerCell.getElement());
    if (str != null)
      ((GridItem)paramViewerCell.getViewerRow().getItem()).setHeaderText(str);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.jface.gridviewer.GridColumnLabelProvider
 * JD-Core Version:    0.6.2
 */