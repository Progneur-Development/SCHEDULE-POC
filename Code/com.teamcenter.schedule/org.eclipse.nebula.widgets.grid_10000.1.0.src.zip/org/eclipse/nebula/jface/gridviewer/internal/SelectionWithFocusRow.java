package org.eclipse.nebula.jface.gridviewer.internal;

import java.util.List;
import org.eclipse.jface.viewers.IElementComparer;
import org.eclipse.jface.viewers.StructuredSelection;

public class SelectionWithFocusRow extends StructuredSelection
{
  private Object focusElement;

  public SelectionWithFocusRow(List paramList, Object paramObject, IElementComparer paramIElementComparer)
  {
    super(paramList, paramIElementComparer);
    this.focusElement = paramObject;
  }

  public Object getFocusElement()
  {
    return this.focusElement;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.jface.gridviewer.internal.SelectionWithFocusRow
 * JD-Core Version:    0.6.2
 */