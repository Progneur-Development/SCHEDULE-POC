package org.eclipse.nebula.jface.gridviewer;

import org.eclipse.jface.viewers.CellEditor.LayoutData;
import org.eclipse.jface.viewers.ColumnViewer;
import org.eclipse.jface.viewers.ColumnViewerEditor;
import org.eclipse.jface.viewers.ColumnViewerEditorActivationEvent;
import org.eclipse.jface.viewers.ColumnViewerEditorActivationStrategy;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.jface.viewers.ViewerRow;
import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridEditor;
import org.eclipse.nebula.widgets.grid.GridItem;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Item;

public class GridViewerEditor extends ColumnViewerEditor
{
  private GridEditor gridEditor;

  GridViewerEditor(ColumnViewer paramColumnViewer, ColumnViewerEditorActivationStrategy paramColumnViewerEditorActivationStrategy, int paramInt)
  {
    super(paramColumnViewer, paramColumnViewerEditorActivationStrategy, paramInt);
    this.gridEditor = new GridEditor((Grid)paramColumnViewer.getControl());
  }

  protected void setEditor(Control paramControl, Item paramItem, int paramInt)
  {
    this.gridEditor.setEditor(paramControl, (GridItem)paramItem, paramInt);
  }

  protected void setLayoutData(CellEditor.LayoutData paramLayoutData)
  {
    this.gridEditor.grabHorizontal = paramLayoutData.grabHorizontal;
    this.gridEditor.horizontalAlignment = paramLayoutData.horizontalAlignment;
    this.gridEditor.minimumWidth = paramLayoutData.minimumWidth;
  }

  public ViewerCell getFocusCell()
  {
    Grid localGrid = (Grid)getViewer().getControl();
    if (localGrid.getCellSelectionEnabled())
    {
      Point localPoint = localGrid.getFocusCell();
      if ((localPoint.x >= 0) && (localPoint.y >= 0))
      {
        GridItem localGridItem = localGrid.getItem(localPoint.y);
        if (localGridItem != null)
        {
          ViewerRow localViewerRow = getViewerRowFromItem(localGridItem);
          return localViewerRow.getCell(localPoint.x);
        }
      }
    }
    return null;
  }

  private ViewerRow getViewerRowFromItem(GridItem paramGridItem)
  {
    if ((getViewer() instanceof GridTableViewer))
      return ((GridTableViewer)getViewer()).getViewerRowFromItem(paramGridItem);
    return ((GridTreeViewer)getViewer()).getViewerRowFromItem(paramGridItem);
  }

  protected void updateFocusCell(ViewerCell paramViewerCell, ColumnViewerEditorActivationEvent paramColumnViewerEditorActivationEvent)
  {
    Grid localGrid = (Grid)getViewer().getControl();
    if ((paramColumnViewerEditorActivationEvent.eventType == 4) || (paramColumnViewerEditorActivationEvent.eventType == 5))
    {
      localGrid.setFocusColumn(localGrid.getColumn(paramViewerCell.getColumnIndex()));
      localGrid.setFocusItem((GridItem)paramViewerCell.getItem());
    }
    localGrid.showColumn(localGrid.getColumn(paramViewerCell.getColumnIndex()));
    localGrid.showItem((GridItem)paramViewerCell.getItem());
  }

  public static void create(GridTableViewer paramGridTableViewer, ColumnViewerEditorActivationStrategy paramColumnViewerEditorActivationStrategy, int paramInt)
  {
    paramGridTableViewer.setColumnViewerEditor(new GridViewerEditor(paramGridTableViewer, paramColumnViewerEditorActivationStrategy, paramInt));
  }

  public static void create(GridTreeViewer paramGridTreeViewer, ColumnViewerEditorActivationStrategy paramColumnViewerEditorActivationStrategy, int paramInt)
  {
    paramGridTreeViewer.setColumnViewerEditor(new GridViewerEditor(paramGridTreeViewer, paramColumnViewerEditorActivationStrategy, paramInt));
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.jface.gridviewer.GridViewerEditor
 * JD-Core Version:    0.6.2
 */