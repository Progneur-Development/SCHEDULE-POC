package org.eclipse.nebula.jface.gridviewer;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnViewer;
import org.eclipse.jface.viewers.EditingSupport;

public abstract class CheckEditingSupport extends EditingSupport
{
  public CheckEditingSupport(ColumnViewer paramColumnViewer)
  {
    super(paramColumnViewer);
  }

  protected boolean canEdit(Object paramObject)
  {
    return false;
  }

  protected CellEditor getCellEditor(Object paramObject)
  {
    return null;
  }

  protected Object getValue(Object paramObject)
  {
    return null;
  }

  public abstract void setValue(Object paramObject1, Object paramObject2);
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.jface.gridviewer.CheckEditingSupport
 * JD-Core Version:    0.6.2
 */