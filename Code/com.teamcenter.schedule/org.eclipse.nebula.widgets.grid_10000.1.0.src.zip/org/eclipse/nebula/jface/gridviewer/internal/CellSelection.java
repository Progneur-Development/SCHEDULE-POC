package org.eclipse.nebula.jface.gridviewer.internal;

import java.util.ArrayList;
import java.util.List;
import org.eclipse.jface.viewers.IElementComparer;

public class CellSelection extends SelectionWithFocusRow
{
  private List indicesList;
  private List elements;

  public CellSelection(List paramList1, List paramList2, Object paramObject, IElementComparer paramIElementComparer)
  {
    super(paramList1, paramObject, paramIElementComparer);
    this.elements = new ArrayList(paramList1);
    this.indicesList = paramList2;
  }

  public List getIndices(Object paramObject)
  {
    return (List)this.indicesList.get(this.elements.indexOf(paramObject));
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.jface.gridviewer.internal.CellSelection
 * JD-Core Version:    0.6.2
 */