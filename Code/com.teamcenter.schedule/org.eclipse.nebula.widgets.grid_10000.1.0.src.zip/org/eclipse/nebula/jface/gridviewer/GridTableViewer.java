package org.eclipse.nebula.jface.gridviewer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import org.eclipse.jface.viewers.AbstractTableViewer;
import org.eclipse.jface.viewers.CellLabelProvider;
import org.eclipse.jface.viewers.ColumnViewerEditor;
import org.eclipse.jface.viewers.ColumnViewerEditorActivationEvent;
import org.eclipse.jface.viewers.ColumnViewerEditorActivationStrategy;
import org.eclipse.jface.viewers.IElementComparer;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.jface.viewers.ViewerRow;
import org.eclipse.nebula.jface.gridviewer.internal.CellSelection;
import org.eclipse.nebula.jface.gridviewer.internal.SelectionWithFocusRow;
import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridItem;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Widget;

public class GridTableViewer extends AbstractTableViewer
{
  private Grid grid;
  private GridViewerRow cachedRow;
  private CellLabelProvider rowHeaderLabelProvider;
  private boolean autoPreferredHeight = false;

  public GridTableViewer(Composite paramComposite)
  {
    this(paramComposite, 2818);
  }

  public GridTableViewer(Composite paramComposite, int paramInt)
  {
    this(new Grid(paramComposite, paramInt));
  }

  public GridTableViewer(Grid paramGrid)
  {
    this.grid = paramGrid;
    hookControl(paramGrid);
  }

  public Grid getGrid()
  {
    return this.grid;
  }

  protected ViewerRow internalCreateNewRowPart(int paramInt1, int paramInt2)
  {
    GridItem localGridItem;
    if (paramInt2 >= 0)
      localGridItem = new GridItem(this.grid, paramInt1, paramInt2);
    else
      localGridItem = new GridItem(this.grid, paramInt1);
    return getViewerRowFromItem(localGridItem);
  }

  protected ColumnViewerEditor createViewerEditor()
  {
    return new GridViewerEditor(this, new ColumnViewerEditorActivationStrategy(this), 1);
  }

  protected void doClear(int paramInt)
  {
  }

  protected void doClearAll()
  {
  }

  protected void doSetItemCount(int paramInt)
  {
  }

  protected void doDeselectAll()
  {
    this.grid.deselectAll();
  }

  protected Widget doGetColumn(int paramInt)
  {
    return this.grid.getColumn(paramInt);
  }

  protected int doGetColumnCount()
  {
    return this.grid.getColumnCount();
  }

  protected Item doGetItem(int paramInt)
  {
    return this.grid.getItem(paramInt);
  }

  protected int doGetItemCount()
  {
    return this.grid.getItemCount();
  }

  protected Item[] doGetItems()
  {
    return this.grid.getItems();
  }

  protected Item[] doGetSelection()
  {
    return this.grid.getSelection();
  }

  protected int[] doGetSelectionIndices()
  {
    return this.grid.getSelectionIndices();
  }

  protected int doIndexOf(Item paramItem)
  {
    return this.grid.indexOf((GridItem)paramItem);
  }

  protected void doRemove(int[] paramArrayOfInt)
  {
    this.grid.remove(paramArrayOfInt);
  }

  protected void doRemove(int paramInt1, int paramInt2)
  {
    this.grid.remove(paramInt1, paramInt2);
  }

  protected void doRemoveAll()
  {
    this.grid.removeAll();
  }

  protected void doSetSelection(Item[] paramArrayOfItem)
  {
    GridItem[] arrayOfGridItem = new GridItem[paramArrayOfItem.length];
    for (int i = 0; i < paramArrayOfItem.length; i++)
      arrayOfGridItem[i] = ((GridItem)paramArrayOfItem[i]);
    this.grid.setSelection(arrayOfGridItem);
    this.grid.showSelection();
  }

  protected void doSetSelection(int[] paramArrayOfInt)
  {
    this.grid.setSelection(paramArrayOfInt);
  }

  protected void doShowItem(Item paramItem)
  {
    this.grid.showItem((GridItem)paramItem);
  }

  protected void doShowSelection()
  {
    this.grid.showSelection();
  }

  protected Item getItemAt(Point paramPoint)
  {
    return this.grid.getItem(paramPoint);
  }

  public Control getControl()
  {
    return this.grid;
  }

  protected ViewerRow getViewerRowFromItem(Widget paramWidget)
  {
    if (this.cachedRow == null)
      this.cachedRow = new GridViewerRow((GridItem)paramWidget);
    else
      this.cachedRow.setItem((GridItem)paramWidget);
    return this.cachedRow;
  }

  protected void doResetItem(Item paramItem)
  {
    GridItem localGridItem = (GridItem)paramItem;
    int i = Math.max(1, this.grid.getColumnCount());
    for (int j = 0; j < i; j++)
    {
      localGridItem.setText(j, "");
      localGridItem.setImage(null);
    }
  }

  protected void doSelect(int[] paramArrayOfInt)
  {
    this.grid.select(paramArrayOfInt);
  }

  public void setAutoPreferredHeight(boolean paramBoolean)
  {
    this.autoPreferredHeight = paramBoolean;
  }

  public boolean getAutoPreferredHeight()
  {
    return this.autoPreferredHeight;
  }

  protected void doUpdateItem(Widget paramWidget, Object paramObject, boolean paramBoolean)
  {
    super.doUpdateItem(paramWidget, paramObject, paramBoolean);
    updateRowHeader(paramWidget);
    if ((this.autoPreferredHeight) && (!paramWidget.isDisposed()))
      ((GridItem)paramWidget).pack();
  }

  private void updateRowHeader(Widget paramWidget)
  {
    if (this.rowHeaderLabelProvider != null)
    {
      ViewerCell localViewerCell = getViewerRowFromItem(paramWidget).getCell(2147483647);
      this.rowHeaderLabelProvider.update(localViewerCell);
    }
  }

  public void setRowHeaderLabelProvider(CellLabelProvider paramCellLabelProvider)
  {
    this.rowHeaderLabelProvider = paramCellLabelProvider;
  }

  public void refreshRowHeaders(Object paramObject)
  {
    int i = paramObject == null ? 1 : 0;
    GridItem[] arrayOfGridItem1 = getGrid().getItems();
    for (GridItem localGridItem : arrayOfGridItem1)
      if ((i != 0) || (paramObject.equals(localGridItem.getData())))
      {
        i = 1;
        updateRowHeader(localGridItem);
      }
  }

  public void editElement(Object paramObject, int paramInt)
  {
    try
    {
      getControl().setRedraw(false);
      Widget localWidget = findItem(paramObject);
      if (localWidget != null)
      {
        ViewerRow localViewerRow = getViewerRowFromItem(localWidget);
        if (localViewerRow != null)
        {
          ViewerCell localViewerCell = localViewerRow.getCell(paramInt);
          if (localViewerCell != null)
            triggerEditorActivationEvent(new ColumnViewerEditorActivationEvent(localViewerCell));
        }
      }
    }
    finally
    {
      getControl().setRedraw(true);
    }
  }

  protected void setSelectionToWidget(ISelection paramISelection, boolean paramBoolean)
  {
    Object localObject1;
    Object localObject2;
    Object localObject3;
    if ((!this.grid.isCellSelectionEnabled()) || (!(paramISelection instanceof CellSelection)))
    {
      super.setSelectionToWidget(paramISelection, paramBoolean);
      if ((paramISelection instanceof SelectionWithFocusRow))
      {
        localObject1 = ((SelectionWithFocusRow)paramISelection).getFocusElement();
        if (localObject1 != null)
        {
          localObject2 = this.grid.getItems();
          for (localObject3 : localObject2)
            if ((((GridItem)localObject3).getData() == localObject1) || (((GridItem)localObject3).getData().equals(localObject1)) || ((getComparer() != null) && (getComparer().equals(((GridItem)localObject3).getData(), localObject1))))
            {
              this.grid.setFocusItem((GridItem)localObject3);
              break;
            }
        }
      }
    }
    else
    {
      localObject1 = (CellSelection)paramISelection;
      localObject2 = ((CellSelection)localObject1).toList();
      localObject3 = this.grid.getItems();
      ArrayList localArrayList = new ArrayList();
      Object localObject5;
      Object localObject7;
      for (??? = 0; ??? < localObject3.length; ???++)
      {
        ??? = ((List)localObject2).iterator();
        localObject5 = localObject3[???].getData();
        while (((Iterator)???).hasNext())
        {
          Object localObject6 = ((Iterator)???).next();
          if ((localObject5 == localObject6) || ((getComparer() != null) && (getComparer().equals(localObject5, localObject6))))
          {
            Iterator localIterator = ((CellSelection)localObject1).getIndices(localObject6).iterator();
            while (localIterator.hasNext())
            {
              localObject7 = (Integer)localIterator.next();
              localArrayList.add(new Point(((Integer)localObject7).intValue(), ???));
            }
          }
        }
      }
      Point[] arrayOfPoint = new Point[localArrayList.size()];
      localArrayList.toArray(arrayOfPoint);
      this.grid.setCellSelection(arrayOfPoint);
      if (((CellSelection)localObject1).getFocusElement() != null)
      {
        ??? = ((CellSelection)localObject1).getFocusElement();
        for (localObject5 : localObject3)
          if ((localObject5.getData() == ???) || (localObject5.getData().equals(???)) || ((getComparer() != null) && (getComparer().equals(localObject5.getData(), ???))))
          {
            this.grid.setFocusItem(localObject5);
            break;
          }
      }
    }
  }

  public ISelection getSelection()
  {
    if (!this.grid.isCellSelectionEnabled())
    {
      IStructuredSelection localIStructuredSelection = (IStructuredSelection)super.getSelection();
      Object localObject = null;
      if (this.grid.getFocusItem() != null)
        localObject = this.grid.getFocusItem().getData();
      return new SelectionWithFocusRow(localIStructuredSelection.toList(), localObject, getComparer());
    }
    return createCellSelection();
  }

  private CellSelection createCellSelection()
  {
    Point[] arrayOfPoint1 = this.grid.getCellSelection();
    Arrays.sort(arrayOfPoint1, new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        Point localPoint1 = (Point)paramAnonymousObject1;
        Point localPoint2 = (Point)paramAnonymousObject2;
        int i = localPoint1.y - localPoint2.y;
        if (i == 0)
          i = localPoint1.x - localPoint2.x;
        return i;
      }
    });
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    ArrayList localArrayList3 = new ArrayList();
    int i = -1;
    for (localObject : arrayOfPoint1)
    {
      if (i != ((Point)localObject).y)
      {
        i = ((Point)localObject).y;
        localArrayList3 = new ArrayList();
        localArrayList2.add(localArrayList3);
        localArrayList1.add(this.grid.getItem(i).getData());
      }
      localArrayList3.add(Integer.valueOf(((Point)localObject).x));
    }
    Object localObject = null;
    if (this.grid.getFocusItem() != null)
      localObject = this.grid.getFocusItem().getData();
    return new CellSelection(localArrayList1, localArrayList2, localObject, getComparer());
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.jface.gridviewer.GridTableViewer
 * JD-Core Version:    0.6.2
 */