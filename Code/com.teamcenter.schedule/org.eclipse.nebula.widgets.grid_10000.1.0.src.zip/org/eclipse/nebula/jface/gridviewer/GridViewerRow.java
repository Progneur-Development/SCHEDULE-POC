package org.eclipse.nebula.jface.gridviewer;

import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerRow;
import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridColumn;
import org.eclipse.nebula.widgets.grid.GridItem;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Widget;

public class GridViewerRow extends ViewerRow
{
  private GridItem item;

  GridViewerRow(GridItem paramGridItem)
  {
    this.item = paramGridItem;
  }

  public Rectangle getBounds(int paramInt)
  {
    if (paramInt == 2147483647)
      return null;
    if (!this.item.getParent().getColumn(paramInt).isVisible())
      return new Rectangle(0, 0, 0, 0);
    return this.item.getBounds(paramInt);
  }

  public Rectangle getBounds()
  {
    return this.item.getBounds(0);
  }

  public int getColumnCount()
  {
    return this.item.getParent().getColumnCount();
  }

  public Color getBackground(int paramInt)
  {
    if (paramInt == 2147483647)
      return null;
    return this.item.getBackground(paramInt);
  }

  public Font getFont(int paramInt)
  {
    if (paramInt == 2147483647)
      return null;
    return this.item.getFont(paramInt);
  }

  public Color getForeground(int paramInt)
  {
    if (paramInt == 2147483647)
      return null;
    return this.item.getForeground(paramInt);
  }

  public Image getImage(int paramInt)
  {
    if (paramInt == 2147483647)
      return null;
    return this.item.getImage(paramInt);
  }

  public String getText(int paramInt)
  {
    if (paramInt == 2147483647)
      return this.item.getHeaderText();
    return this.item.getText(paramInt);
  }

  public void setBackground(int paramInt, Color paramColor)
  {
    if (paramInt != 2147483647)
      this.item.setBackground(paramInt, paramColor);
  }

  public void setFont(int paramInt, Font paramFont)
  {
    if (paramInt != 2147483647)
      this.item.setFont(paramInt, paramFont);
  }

  public void setForeground(int paramInt, Color paramColor)
  {
    if (paramInt != 2147483647)
      this.item.setForeground(paramInt, paramColor);
  }

  public void setImage(int paramInt, Image paramImage)
  {
    if (paramInt == 2147483647)
      this.item.setHeaderImage(paramImage);
    else
      this.item.setImage(paramInt, paramImage);
  }

  public void setText(int paramInt, String paramString)
  {
    if (paramInt == 2147483647)
      this.item.setHeaderText(paramString);
    else
      this.item.setText(paramInt, paramString == null ? "" : paramString);
  }

  public Control getControl()
  {
    return this.item.getParent();
  }

  public ViewerRow getNeighbor(int paramInt, boolean paramBoolean)
  {
    if (paramInt == 1)
      return getRowAbove();
    if (paramInt == 2)
      return getRowBelow();
    throw new IllegalArgumentException("Illegal value of direction argument.");
  }

  private ViewerRow getRowAbove()
  {
    int i = this.item.getParent().indexOf(this.item) - 1;
    if (i >= 0)
      return new GridViewerRow(this.item.getParent().getItem(i));
    return null;
  }

  private ViewerRow getRowBelow()
  {
    int i = this.item.getParent().indexOf(this.item) + 1;
    if (i < this.item.getParent().getItemCount())
    {
      GridItem localGridItem = this.item.getParent().getItem(i);
      if (localGridItem != null)
        return new GridViewerRow(localGridItem);
    }
    return null;
  }

  public TreePath getTreePath()
  {
    return new TreePath(new Object[] { this.item.getData() });
  }

  public Object clone()
  {
    return new GridViewerRow(this.item);
  }

  public Object getElement()
  {
    return this.item.getData();
  }

  void setItem(GridItem paramGridItem)
  {
    this.item = paramGridItem;
  }

  public Widget getItem()
  {
    return this.item;
  }

  public int getVisualIndex(int paramInt)
  {
    int[] arrayOfInt = this.item.getParent().getColumnOrder();
    for (int i = 0; i < arrayOfInt.length; i++)
      if (arrayOfInt[i] == paramInt)
        return i;
    return -1;
  }

  public int getCreationIndex(int paramInt)
  {
    if ((this.item != null) && (!this.item.isDisposed()) && (hasColumns()) && (isValidOrderIndex(paramInt)))
      return this.item.getParent().getColumnOrder()[paramInt];
    return -1;
  }

  private boolean hasColumns()
  {
    return this.item.getParent().getColumnCount() != 0;
  }

  private boolean isValidOrderIndex(int paramInt)
  {
    return paramInt < this.item.getParent().getColumnOrder().length;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.jface.gridviewer.GridViewerRow
 * JD-Core Version:    0.6.2
 */