package org.eclipse.nebula.jface.gridviewer;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.eclipse.jface.viewers.AbstractTreeViewer;
import org.eclipse.jface.viewers.CellLabelProvider;
import org.eclipse.jface.viewers.ColumnViewerEditor;
import org.eclipse.jface.viewers.ColumnViewerEditorActivationStrategy;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.jface.viewers.ViewerRow;
import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridItem;
import org.eclipse.swt.events.TreeListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.swt.widgets.Widget;

public class GridTreeViewer extends AbstractTreeViewer
{
  private Grid grid;
  private GridViewerRow cachedRow;
  private boolean autoPreferredHeight = false;
  private CellLabelProvider rowHeaderLabelProvider;

  public GridTreeViewer(Composite paramComposite)
  {
    this(paramComposite, 2818);
  }

  public GridTreeViewer(Composite paramComposite, int paramInt)
  {
    this(new Grid(paramComposite, paramInt));
  }

  public GridTreeViewer(Grid paramGrid)
  {
    this.grid = paramGrid;
    hookControl(paramGrid);
  }

  public Grid getGrid()
  {
    return this.grid;
  }

  protected Item getItemAt(Point paramPoint)
  {
    return this.grid.getItem(paramPoint);
  }

  protected ColumnViewerEditor createViewerEditor()
  {
    return new GridViewerEditor(this, new ColumnViewerEditorActivationStrategy(this), 1);
  }

  protected void addTreeListener(Control paramControl, TreeListener paramTreeListener)
  {
    ((Grid)paramControl).addTreeListener(paramTreeListener);
  }

  protected Item[] getChildren(Widget paramWidget)
  {
    if ((paramWidget instanceof GridItem))
      return ((GridItem)paramWidget).getItems();
    if ((paramWidget instanceof Grid))
      return ((Grid)paramWidget).getRootItems();
    return null;
  }

  protected boolean getExpanded(Item paramItem)
  {
    return ((GridItem)paramItem).isExpanded();
  }

  protected int getItemCount(Control paramControl)
  {
    return ((Grid)paramControl).getItemCount();
  }

  protected int getItemCount(Item paramItem)
  {
    return ((GridItem)paramItem).getItemCount();
  }

  protected Item[] getItems(Item paramItem)
  {
    return ((GridItem)paramItem).getItems();
  }

  protected Item getParentItem(Item paramItem)
  {
    return ((GridItem)paramItem).getParentItem();
  }

  protected Item[] getSelection(Control paramControl)
  {
    return ((Grid)paramControl).getSelection();
  }

  protected Item newItem(Widget paramWidget, int paramInt1, int paramInt2)
  {
    GridItem localGridItem;
    if ((paramWidget instanceof GridItem))
      localGridItem = (GridItem)createNewRowPart(getViewerRowFromItem(paramWidget), paramInt1, paramInt2).getItem();
    else
      localGridItem = (GridItem)createNewRowPart(null, paramInt1, paramInt2).getItem();
    return localGridItem;
  }

  private ViewerRow createNewRowPart(ViewerRow paramViewerRow, int paramInt1, int paramInt2)
  {
    if (paramViewerRow == null)
    {
      if (paramInt2 >= 0)
        return getViewerRowFromItem(new GridItem(this.grid, paramInt1, paramInt2));
      return getViewerRowFromItem(new GridItem(this.grid, paramInt1));
    }
    if (paramInt2 >= 0)
      return getViewerRowFromItem(new GridItem((GridItem)paramViewerRow.getItem(), 0, paramInt2));
    return getViewerRowFromItem(new GridItem((GridItem)paramViewerRow.getItem(), 0));
  }

  protected void removeAll(Control paramControl)
  {
    ((Grid)paramControl).removeAll();
  }

  protected void setExpanded(Item paramItem, boolean paramBoolean)
  {
    ((GridItem)paramItem).setExpanded(paramBoolean);
  }

  protected void setSelection(List paramList)
  {
    Item[] arrayOfItem = getSelection(getGrid());
    if (isSameSelection(paramList, arrayOfItem))
      return;
    GridItem[] arrayOfGridItem = new GridItem[paramList.size()];
    paramList.toArray(arrayOfGridItem);
    getGrid().setSelection(arrayOfGridItem);
    getGrid().showSelection();
  }

  protected void showItem(Item paramItem)
  {
    getGrid().showItem((GridItem)paramItem);
  }

  public Control getControl()
  {
    return getGrid();
  }

  protected ViewerRow getViewerRowFromItem(Widget paramWidget)
  {
    if (this.cachedRow == null)
      this.cachedRow = new GridViewerRow((GridItem)paramWidget);
    else
      this.cachedRow.setItem((GridItem)paramWidget);
    return this.cachedRow;
  }

  protected Widget getColumnViewerOwner(int paramInt)
  {
    if ((paramInt < 0) || ((paramInt > 0) && (paramInt >= getGrid().getColumnCount())))
      return null;
    if (getGrid().getColumnCount() == 0)
      return getGrid();
    return getGrid().getColumn(paramInt);
  }

  protected int doGetColumnCount()
  {
    return this.grid.getColumnCount();
  }

  public void setAutoPreferredHeight(boolean paramBoolean)
  {
    this.autoPreferredHeight = paramBoolean;
  }

  public boolean getAutoPreferredHeight()
  {
    return this.autoPreferredHeight;
  }

  protected void doUpdateItem(Item paramItem, Object paramObject)
  {
    super.doUpdateItem(paramItem, paramObject);
    updateRowHeader(paramItem);
    if ((this.autoPreferredHeight) && (!paramItem.isDisposed()))
      ((GridItem)paramItem).pack();
  }

  public void remove(final Object paramObject, final int paramInt)
  {
    final LinkedList localLinkedList = new LinkedList(Arrays.asList(((TreeSelection)getSelection()).getPaths()));
    preservingSelection(new Runnable()
    {
      public void run()
      {
        TreePath localTreePath = null;
        Object localObject1;
        Object localObject2;
        if (GridTreeViewer.this.internalIsInputOrEmptyPath(paramObject))
        {
          localObject1 = (Tree)GridTreeViewer.this.getControl();
          if (paramInt < ((Tree)localObject1).getItemCount())
          {
            TreeItem localTreeItem1 = ((Tree)localObject1).getItem(paramInt);
            if (localTreeItem1.getData() != null)
            {
              localTreePath = GridTreeViewer.this.getTreePathFromItem(localTreeItem1);
              GridTreeViewer.this.disassociate(localTreeItem1);
            }
            localTreeItem1.dispose();
          }
        }
        else
        {
          localObject1 = GridTreeViewer.this.internalFindItems(paramObject);
          for (int j = 0; j < localObject1.length; j++)
          {
            localObject2 = (TreeItem)localObject1[j];
            if ((!((TreeItem)localObject2).isDisposed()) && (paramInt < ((TreeItem)localObject2).getItemCount()))
            {
              TreeItem localTreeItem2 = ((TreeItem)localObject2).getItem(paramInt);
              if (localTreeItem2.getData() != null)
              {
                localTreePath = GridTreeViewer.this.getTreePathFromItem(localTreeItem2);
                GridTreeViewer.this.disassociate(localTreeItem2);
              }
              localTreeItem2.dispose();
            }
          }
        }
        if (localTreePath != null)
        {
          int i = 0;
          Iterator localIterator = localLinkedList.iterator();
          while (localIterator.hasNext())
          {
            localObject2 = (TreePath)localIterator.next();
            if (((TreePath)localObject2).startsWith(localTreePath, GridTreeViewer.this.getComparer()))
            {
              localIterator.remove();
              i = 1;
            }
          }
          if (i != 0)
            GridTreeViewer.this.setSelection(new TreeSelection((TreePath[])localLinkedList.toArray(new TreePath[localLinkedList.size()]), GridTreeViewer.this.getComparer()), false);
        }
      }
    });
  }

  public void setRowHeaderLabelProvider(CellLabelProvider paramCellLabelProvider)
  {
    this.rowHeaderLabelProvider = paramCellLabelProvider;
  }

  private void updateRowHeader(Widget paramWidget)
  {
    if (this.rowHeaderLabelProvider != null)
    {
      ViewerCell localViewerCell = getViewerRowFromItem(paramWidget).getCell(2147483647);
      this.rowHeaderLabelProvider.update(localViewerCell);
    }
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.jface.gridviewer.GridTreeViewer
 * JD-Core Version:    0.6.2
 */