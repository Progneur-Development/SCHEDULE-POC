package org.eclipse.nebula.jface.gridviewer;

import org.eclipse.jface.viewers.ColumnViewer;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.ViewerColumn;
import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridColumn;
import org.eclipse.nebula.widgets.grid.GridItem;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

public final class GridViewerColumn extends ViewerColumn
{
  private ColumnViewer viewer;
  private GridColumn column;
  private CheckEditingSupport checkEditingSupport;
  protected Listener columnResizeListener = null;

  public GridViewerColumn(GridTableViewer paramGridTableViewer, int paramInt)
  {
    this(paramGridTableViewer, paramInt, -1);
  }

  public GridViewerColumn(GridTreeViewer paramGridTreeViewer, int paramInt)
  {
    this(paramGridTreeViewer, paramInt, -1);
  }

  public GridViewerColumn(GridTableViewer paramGridTableViewer, int paramInt1, int paramInt2)
  {
    this(paramGridTableViewer, createColumn((Grid)paramGridTableViewer.getControl(), paramInt1, paramInt2));
  }

  public GridViewerColumn(GridTreeViewer paramGridTreeViewer, int paramInt1, int paramInt2)
  {
    this(paramGridTreeViewer, createColumn((Grid)paramGridTreeViewer.getControl(), paramInt1, paramInt2));
  }

  public GridViewerColumn(GridTreeViewer paramGridTreeViewer, GridColumn paramGridColumn)
  {
    this(paramGridTreeViewer, paramGridColumn);
  }

  public GridViewerColumn(GridTableViewer paramGridTableViewer, GridColumn paramGridColumn)
  {
    this(paramGridTableViewer, paramGridColumn);
  }

  GridViewerColumn(ColumnViewer paramColumnViewer, GridColumn paramGridColumn)
  {
    super(paramColumnViewer, paramGridColumn);
    this.viewer = paramColumnViewer;
    this.column = paramGridColumn;
    hookColumnResizeListener();
  }

  private static GridColumn createColumn(Grid paramGrid, int paramInt1, int paramInt2)
  {
    if (paramInt2 >= 0)
      return new GridColumn(paramGrid, paramInt1, paramInt2);
    return new GridColumn(paramGrid, paramInt1);
  }

  public GridColumn getColumn()
  {
    return this.column;
  }

  public void setEditingSupport(EditingSupport paramEditingSupport)
  {
    if ((paramEditingSupport instanceof CheckEditingSupport))
    {
      if (this.checkEditingSupport == null)
      {
        final int i = getColumn().getParent().indexOf(getColumn());
        getColumn().getParent().addListener(13, new Listener()
        {
          public void handleEvent(Event paramAnonymousEvent)
          {
            if ((paramAnonymousEvent.detail == 32) && (paramAnonymousEvent.index == i))
            {
              GridItem localGridItem = (GridItem)paramAnonymousEvent.item;
              Object localObject = localGridItem.getData();
              GridViewerColumn.this.checkEditingSupport.setValue(localObject, Boolean.valueOf(localGridItem.getChecked(i)));
            }
          }
        });
      }
      this.checkEditingSupport = ((CheckEditingSupport)paramEditingSupport);
    }
    else
    {
      super.setEditingSupport(paramEditingSupport);
    }
  }

  private void hookColumnResizeListener()
  {
    if (this.columnResizeListener == null)
    {
      this.columnResizeListener = new Listener()
      {
        public void handleEvent(Event paramAnonymousEvent)
        {
          boolean bool = false;
          if ((GridViewerColumn.this.viewer instanceof GridTableViewer))
            bool = ((GridTableViewer)GridViewerColumn.this.viewer).getAutoPreferredHeight();
          if ((GridViewerColumn.this.viewer instanceof GridTreeViewer))
            bool = ((GridTreeViewer)GridViewerColumn.this.viewer).getAutoPreferredHeight();
          if ((bool) && (GridViewerColumn.this.column.getWordWrap()))
          {
            Grid localGrid = GridViewerColumn.this.column.getParent();
            for (int i = 0; i < localGrid.getItemCount(); i++)
              localGrid.getItem(i).pack();
            localGrid.redraw();
          }
        }
      };
      this.column.addListener(11, this.columnResizeListener);
      this.column.addListener(23, this.columnResizeListener);
      this.column.addListener(22, this.columnResizeListener);
    }
  }

  private void unhookColumnResizeListener()
  {
    if (this.columnResizeListener != null)
    {
      this.column.removeListener(11, this.columnResizeListener);
      this.columnResizeListener = null;
    }
  }

  protected void handleDispose()
  {
    unhookColumnResizeListener();
    super.handleDispose();
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.jface.gridviewer.GridViewerColumn
 * JD-Core Version:    0.6.2
 */