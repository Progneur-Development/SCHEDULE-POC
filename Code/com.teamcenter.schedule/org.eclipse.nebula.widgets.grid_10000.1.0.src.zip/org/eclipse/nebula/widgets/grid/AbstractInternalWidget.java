package org.eclipse.nebula.widgets.grid;

public abstract class AbstractInternalWidget extends AbstractRenderer
  implements IInternalWidget
{
  String hoverDetail = "";

  public String getHoverDetail()
  {
    return this.hoverDetail;
  }

  public void setHoverDetail(String paramString)
  {
    this.hoverDetail = paramString;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.AbstractInternalWidget
 * JD-Core Version:    0.6.2
 */