package org.eclipse.nebula.widgets.grid;

import org.eclipse.swt.graphics.Rectangle;

public abstract class GridCellRenderer extends AbstractInternalWidget
{
  private int row = 0;
  private int column = 0;
  private int alignment = 16384;
  private boolean tree = false;
  private boolean check = false;
  private boolean rowHover = false;
  private boolean columnHover = false;
  private boolean rowFocus = false;
  private boolean cellFocus = false;
  private boolean cellSelected = false;
  private boolean wordWrap = false;
  private boolean dragging = false;

  public int getRow()
  {
    return this.row;
  }

  public void setRow(int paramInt)
  {
    this.row = paramInt;
  }

  public int getAlignment()
  {
    return this.alignment;
  }

  public void setAlignment(int paramInt)
  {
    this.alignment = paramInt;
  }

  public boolean isCheck()
  {
    return this.check;
  }

  public void setCheck(boolean paramBoolean)
  {
    this.check = paramBoolean;
  }

  public boolean isTree()
  {
    return this.tree;
  }

  public void setTree(boolean paramBoolean)
  {
    this.tree = paramBoolean;
  }

  public int getColumn()
  {
    return this.column;
  }

  public void setColumn(int paramInt)
  {
    this.column = paramInt;
  }

  public boolean isColumnHover()
  {
    return this.columnHover;
  }

  public void setColumnHover(boolean paramBoolean)
  {
    this.columnHover = paramBoolean;
  }

  public boolean isRowHover()
  {
    return this.rowHover;
  }

  public void setRowHover(boolean paramBoolean)
  {
    this.rowHover = paramBoolean;
  }

  public boolean isCellFocus()
  {
    return this.cellFocus;
  }

  public void setCellFocus(boolean paramBoolean)
  {
    this.cellFocus = paramBoolean;
  }

  public boolean isRowFocus()
  {
    return this.rowFocus;
  }

  public void setRowFocus(boolean paramBoolean)
  {
    this.rowFocus = paramBoolean;
  }

  public boolean isCellSelected()
  {
    return this.cellSelected;
  }

  public void setCellSelected(boolean paramBoolean)
  {
    this.cellSelected = paramBoolean;
  }

  public Rectangle getTextBounds(GridItem paramGridItem, boolean paramBoolean)
  {
    return null;
  }

  public boolean isWordWrap()
  {
    return this.wordWrap;
  }

  public void setWordWrap(boolean paramBoolean)
  {
    this.wordWrap = paramBoolean;
  }

  public boolean isDragging()
  {
    return this.dragging;
  }

  public void setDragging(boolean paramBoolean)
  {
    this.dragging = paramBoolean;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridCellRenderer
 * JD-Core Version:    0.6.2
 */