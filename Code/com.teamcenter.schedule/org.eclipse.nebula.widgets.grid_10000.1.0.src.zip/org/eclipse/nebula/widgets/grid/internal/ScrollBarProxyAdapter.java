package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.ScrollBar;

public class ScrollBarProxyAdapter
  implements IScrollBarProxy
{
  private ScrollBar scrollBar;

  public ScrollBarProxyAdapter(ScrollBar paramScrollBar)
  {
    this.scrollBar = paramScrollBar;
  }

  public int getIncrement()
  {
    return this.scrollBar.getIncrement();
  }

  public int getMaximum()
  {
    return this.scrollBar.getMaximum();
  }

  public int getMinimum()
  {
    return this.scrollBar.getMinimum();
  }

  public int getPageIncrement()
  {
    return this.scrollBar.getPageIncrement();
  }

  public int getSelection()
  {
    return this.scrollBar.getSelection();
  }

  public int getThumb()
  {
    return this.scrollBar.getThumb();
  }

  public boolean getVisible()
  {
    return this.scrollBar.getVisible();
  }

  public void setIncrement(int paramInt)
  {
    this.scrollBar.setIncrement(paramInt);
  }

  public void setMaximum(int paramInt)
  {
    this.scrollBar.setMaximum(paramInt);
  }

  public void setMinimum(int paramInt)
  {
    this.scrollBar.setMinimum(paramInt);
  }

  public void setPageIncrement(int paramInt)
  {
    this.scrollBar.setPageIncrement(paramInt);
  }

  public void setSelection(int paramInt)
  {
    this.scrollBar.setSelection(paramInt);
  }

  public void setThumb(int paramInt)
  {
    this.scrollBar.setThumb(paramInt);
  }

  public void setValues(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    this.scrollBar.setValues(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }

  public void setVisible(boolean paramBoolean)
  {
    this.scrollBar.setVisible(paramBoolean);
  }

  public void handleMouseWheel(Event paramEvent)
  {
  }

  public void addSelectionListener(SelectionListener paramSelectionListener)
  {
    this.scrollBar.addSelectionListener(paramSelectionListener);
  }

  public void removeSelectionListener(SelectionListener paramSelectionListener)
  {
    this.scrollBar.removeSelectionListener(paramSelectionListener);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.ScrollBarProxyAdapter
 * JD-Core Version:    0.6.2
 */