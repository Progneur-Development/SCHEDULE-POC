package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

public class TextUtils
{
  public static String getShortText(GC paramGC, String paramString, int paramInt)
  {
    if (paramString == null)
      return null;
    if (paramString.equals(""))
      return "";
    if (paramInt >= paramGC.textExtent(paramString).x)
      return paramString;
    int i = paramGC.textExtent("...").x;
    String str1 = paramString;
    int j = str1.length();
    int k = j / 2;
    int m = k;
    for (int n = k + 1; (m >= 0) && (n < j); n++)
    {
      String str2 = str1.substring(0, m);
      String str3 = str1.substring(n, j);
      int i1 = paramGC.textExtent(str2).x;
      int i2 = paramGC.textExtent(str3).x;
      if (i1 + i + i2 < paramInt)
      {
        str1 = str2 + "..." + str3;
        break;
      }
      m--;
    }
    if ((m == 0) || (n == j))
      str1 = str1.substring(0, 1) + "..." + str1.substring(j - 1, j);
    return str1;
  }

  public static String getShortString(GC paramGC, String paramString, int paramInt)
  {
    if (paramString == null)
      return null;
    if (paramString.equals(""))
      return "";
    if (paramInt >= paramGC.stringExtent(paramString).x)
      return paramString;
    int i = paramGC.stringExtent("...").x;
    String str1 = paramString;
    int j = str1.length();
    int k = j / 2;
    int m = k;
    for (int n = k + 1; (m >= 0) && (n < j); n++)
    {
      String str2 = str1.substring(0, m);
      String str3 = str1.substring(n, j);
      int i1 = paramGC.stringExtent(str2).x;
      int i2 = paramGC.stringExtent(str3).x;
      if (i1 + i + i2 < paramInt)
      {
        str1 = str2 + "..." + str3;
        break;
      }
      m--;
    }
    if ((m == 0) || (n == j))
      str1 = str1.substring(0, 1) + "..." + str1.substring(j - 1, j);
    return str1;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.TextUtils
 * JD-Core Version:    0.6.2
 */