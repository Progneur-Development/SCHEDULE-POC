package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.AbstractRenderer;
import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridItem;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class DefaultRowHeaderRenderer extends AbstractRenderer
{
  int leftMargin = 6;
  int rightMargin = 8;
  int topMargin = 3;
  int bottomMargin = 3;

  public void paint(GC paramGC, Object paramObject)
  {
    GridItem localGridItem = (GridItem)paramObject;
    String str = getHeaderText(localGridItem);
    paramGC.setFont(getDisplay().getSystemFont());
    paramGC.setBackground(getDisplay().getSystemColor(22));
    if ((isSelected()) && (localGridItem.getParent().getCellSelectionEnabled()))
      paramGC.setBackground(localGridItem.getParent().getCellHeaderSelectionBackground());
    paramGC.fillRectangle(getBounds().x, getBounds().y, getBounds().width, getBounds().height + 1);
    if (!localGridItem.getParent().getCellSelectionEnabled())
    {
      if (isSelected())
        paramGC.setForeground(getDisplay().getSystemColor(18));
      else
        paramGC.setForeground(getDisplay().getSystemColor(20));
      paramGC.drawLine(getBounds().x, getBounds().y, getBounds().x + getBounds().width - 1, getBounds().y);
      paramGC.drawLine(getBounds().x, getBounds().y, getBounds().x, getBounds().y + getBounds().height - 1);
      if (!isSelected())
      {
        paramGC.setForeground(getDisplay().getSystemColor(19));
        paramGC.drawLine(getBounds().x + 1, getBounds().y + 1, getBounds().x + getBounds().width - 2, getBounds().y + 1);
        paramGC.drawLine(getBounds().x + 1, getBounds().y + 1, getBounds().x + 1, getBounds().y + getBounds().height - 2);
      }
      if (isSelected())
        paramGC.setForeground(getDisplay().getSystemColor(18));
      else
        paramGC.setForeground(getDisplay().getSystemColor(17));
      paramGC.drawLine(getBounds().x + getBounds().width - 1, getBounds().y, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
      paramGC.drawLine(getBounds().x, getBounds().y + getBounds().height - 1, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
      if (!isSelected())
      {
        paramGC.setForeground(getDisplay().getSystemColor(18));
        paramGC.drawLine(getBounds().x + getBounds().width - 2, getBounds().y + 1, getBounds().x + getBounds().width - 2, getBounds().y + getBounds().height - 2);
        paramGC.drawLine(getBounds().x + 1, getBounds().y + getBounds().height - 2, getBounds().x + getBounds().width - 2, getBounds().y + getBounds().height - 2);
      }
    }
    else
    {
      paramGC.setForeground(getDisplay().getSystemColor(17));
      paramGC.drawLine(getBounds().x + getBounds().width - 1, getBounds().y, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
      paramGC.drawLine(getBounds().x, getBounds().y + getBounds().height - 1, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
    }
    int i = this.leftMargin;
    Image localImage = getHeaderImage(localGridItem);
    if (localImage != null)
    {
      if ((isSelected()) && (!localGridItem.getParent().getCellSelectionEnabled()))
      {
        paramGC.drawImage(localImage, i + 1, getBounds().y + 1 + (getBounds().height - localImage.getBounds().height) / 2);
        i++;
      }
      else
      {
        paramGC.drawImage(localImage, i, getBounds().y + (getBounds().height - localImage.getBounds().height) / 2);
      }
      i += localImage.getBounds().width + 5;
    }
    int j = getBounds().width - i;
    j -= this.rightMargin;
    paramGC.setForeground(getDisplay().getSystemColor(21));
    int k = getBounds().y + (getBounds().height - paramGC.stringExtent(str).y) / 2;
    if ((isSelected()) && (!localGridItem.getParent().getCellSelectionEnabled()))
      paramGC.drawString(TextUtils.getShortString(paramGC, str, j), getBounds().x + i + 1, k + 1, true);
    else
      paramGC.drawString(TextUtils.getShortString(paramGC, str, j), getBounds().x + i, k, true);
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    GridItem localGridItem = (GridItem)paramObject;
    String str = getHeaderText(localGridItem);
    Image localImage = getHeaderImage(localGridItem);
    int i = 0;
    i += this.leftMargin;
    if (localImage != null)
      i += localImage.getBounds().width + 5;
    i += paramGC.stringExtent(str).x + this.rightMargin;
    int j = 0;
    j += this.topMargin;
    if (localImage != null)
      j += Math.max(paramGC.getFontMetrics().getHeight(), localImage.getBounds().height);
    else
      j += paramGC.getFontMetrics().getHeight();
    j += this.bottomMargin;
    return new Point(i, j);
  }

  private Image getHeaderImage(GridItem paramGridItem)
  {
    return paramGridItem.getHeaderImage();
  }

  private String getHeaderText(GridItem paramGridItem)
  {
    String str = paramGridItem.getHeaderText();
    if (str == null)
      str = paramGridItem.getParent().indexOf(paramGridItem) + 1;
    return str;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.DefaultRowHeaderRenderer
 * JD-Core Version:    0.6.2
 */