package org.eclipse.nebula.widgets.grid;

import org.eclipse.nebula.widgets.grid.internal.IScrollBarProxy;
import org.eclipse.swt.custom.ControlEditor;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.TreeEvent;
import org.eclipse.swt.events.TreeListener;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

public class GridEditor extends ControlEditor
{
  Grid table;
  GridItem item;
  int column = -1;
  ControlListener columnListener;
  Listener resizeListener;
  private Listener columnVisibleListener;
  private Listener columnGroupListener;
  private SelectionListener scrollListener;
  private TreeListener treeListener;

  public GridEditor(final Grid paramGrid)
  {
    super(paramGrid);
    this.table = paramGrid;
    this.treeListener = new TreeListener()
    {
      final Runnable runnable;

      public void treeCollapsed(TreeEvent paramAnonymousTreeEvent)
      {
        if ((GridEditor.this.getEditor() == null) || (GridEditor.this.getEditor().isDisposed()))
          return;
        GridEditor.this.getEditor().setVisible(false);
        paramAnonymousTreeEvent.display.asyncExec(this.runnable);
      }

      public void treeExpanded(TreeEvent paramAnonymousTreeEvent)
      {
        if ((GridEditor.this.getEditor() == null) || (GridEditor.this.getEditor().isDisposed()))
          return;
        GridEditor.this.getEditor().setVisible(false);
        paramAnonymousTreeEvent.display.asyncExec(this.runnable);
      }
    };
    paramGrid.addTreeListener(this.treeListener);
    this.columnListener = new ControlListener()
    {
      public void controlMoved(ControlEvent paramAnonymousControlEvent)
      {
        GridEditor.this.layout();
      }

      public void controlResized(ControlEvent paramAnonymousControlEvent)
      {
        GridEditor.this.layout();
      }
    };
    this.columnVisibleListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        GridEditor.this.getEditor().setVisible(((GridColumn)paramAnonymousEvent.widget).isVisible());
        if (GridEditor.this.getEditor().isVisible())
          GridEditor.this.layout();
      }
    };
    this.resizeListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        GridEditor.this.layout();
      }
    };
    this.scrollListener = new SelectionListener()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        GridEditor.this.layout();
      }

      public void widgetDefaultSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
      }
    };
    this.columnGroupListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if ((GridEditor.this.getEditor() == null) || (GridEditor.this.getEditor().isDisposed()))
          return;
        GridEditor.this.getEditor().setVisible(paramGrid.getColumn(GridEditor.this.getColumn()).isVisible());
        if (GridEditor.this.getEditor().isVisible())
          GridEditor.this.layout();
      }
    };
    paramGrid.addListener(11, this.resizeListener);
    if (paramGrid.getVerticalScrollBarProxy() != null)
      paramGrid.getVerticalScrollBarProxy().addSelectionListener(this.scrollListener);
    if (paramGrid.getHorizontalScrollBarProxy() != null)
      paramGrid.getHorizontalScrollBarProxy().addSelectionListener(this.scrollListener);
    this.grabVertical = true;
  }

  protected Rectangle computeBounds2()
  {
    if ((this.item == null) || (this.column == -1) || (this.item.isDisposed()))
      return new Rectangle(0, 0, 0, 0);
    Rectangle localRectangle1 = this.item.getBounds(this.column);
    Rectangle localRectangle2 = this.table.getClientArea();
    if ((localRectangle1.x < localRectangle2.x + localRectangle2.width) && (localRectangle1.x + localRectangle1.width > localRectangle2.x + localRectangle2.width))
      localRectangle1.width = (localRectangle2.x + localRectangle2.width - localRectangle1.x);
    Rectangle localRectangle3 = new Rectangle(localRectangle1.x, localRectangle1.y, this.minimumWidth, this.minimumHeight);
    if (this.grabHorizontal)
      localRectangle3.width = Math.max(localRectangle1.width, this.minimumWidth);
    if (this.grabVertical)
      localRectangle3.height = Math.max(localRectangle1.height, this.minimumHeight);
    if (this.horizontalAlignment == 131072)
      localRectangle3.x += localRectangle1.width - localRectangle3.width;
    else if (this.horizontalAlignment != 16384)
      localRectangle3.x += (localRectangle1.width - localRectangle3.width) / 2;
    if (this.verticalAlignment == 1024)
      localRectangle3.y += localRectangle1.height - localRectangle3.height;
    else if (this.verticalAlignment != 128)
      localRectangle3.y += (localRectangle1.height - localRectangle3.height) / 2;
    GridColumn localGridColumn = this.table.getColumn(this.column);
    if ((localGridColumn != null) && (localGridColumn.isTree()))
    {
      int i = localGridColumn.getCellRenderer().getTextBounds(this.item, false).x;
      localRectangle3.x += i;
      localRectangle3.width -= i;
    }
    return localRectangle3;
  }

  public void dispose()
  {
    if ((!this.table.isDisposed()) && (this.column > -1) && (this.column < this.table.getColumnCount()))
    {
      GridColumn localGridColumn = this.table.getColumn(this.column);
      localGridColumn.removeControlListener(this.columnListener);
      if (localGridColumn.getColumnGroup() != null)
      {
        localGridColumn.getColumnGroup().removeListener(17, this.columnGroupListener);
        localGridColumn.getColumnGroup().removeListener(18, this.columnGroupListener);
      }
    }
    if (!this.table.isDisposed())
    {
      this.table.removeListener(11, this.resizeListener);
      if (this.table.getVerticalScrollBarProxy() != null)
        this.table.getVerticalScrollBarProxy().removeSelectionListener(this.scrollListener);
      if (this.table.getHorizontalScrollBarProxy() != null)
        this.table.getHorizontalScrollBarProxy().removeSelectionListener(this.scrollListener);
    }
    this.columnListener = null;
    this.resizeListener = null;
    this.table = null;
    this.item = null;
    this.column = -1;
    super.dispose();
  }

  public int getColumn()
  {
    return this.column;
  }

  public GridItem getItem()
  {
    return this.item;
  }

  public void setColumn(int paramInt)
  {
    int i = this.table.getColumnCount();
    if (i == 0)
    {
      this.column = (paramInt == 0 ? 0 : -1);
      layout();
      return;
    }
    if ((this.column > -1) && (this.column < i))
    {
      localGridColumn = this.table.getColumn(this.column);
      localGridColumn.removeControlListener(this.columnListener);
      localGridColumn.removeListener(22, this.columnVisibleListener);
      localGridColumn.removeListener(23, this.columnVisibleListener);
      this.column = -1;
    }
    if ((paramInt < 0) || (paramInt >= this.table.getColumnCount()))
      return;
    this.column = paramInt;
    GridColumn localGridColumn = this.table.getColumn(this.column);
    localGridColumn.addControlListener(this.columnListener);
    localGridColumn.addListener(22, this.columnVisibleListener);
    localGridColumn.addListener(23, this.columnVisibleListener);
    if (localGridColumn.getColumnGroup() != null)
    {
      localGridColumn.getColumnGroup().addListener(17, this.columnGroupListener);
      localGridColumn.getColumnGroup().addListener(18, this.columnGroupListener);
    }
    layout();
  }

  public void setItem(GridItem paramGridItem)
  {
    this.item = paramGridItem;
    layout();
  }

  public void setEditor(Control paramControl, GridItem paramGridItem, int paramInt)
  {
    setItem(paramGridItem);
    setColumn(paramInt);
    setEditor(paramControl);
    layout();
  }

  public void layout()
  {
    if (this.table.isDisposed())
      return;
    if ((this.item == null) || (this.item.isDisposed()))
      return;
    int i = this.table.getColumnCount();
    if ((i == 0) && (this.column != 0))
      return;
    if ((i > 0) && ((this.column < 0) || (this.column >= i)))
      return;
    boolean bool = false;
    if ((getEditor() == null) || (getEditor().isDisposed()))
      return;
    if (getEditor().getVisible())
      bool = getEditor().isFocusControl();
    getEditor().setBounds(computeBounds2());
    if (bool)
    {
      if ((getEditor() == null) || (getEditor().isDisposed()))
        return;
      getEditor().setFocus();
    }
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridEditor
 * JD-Core Version:    0.6.2
 */