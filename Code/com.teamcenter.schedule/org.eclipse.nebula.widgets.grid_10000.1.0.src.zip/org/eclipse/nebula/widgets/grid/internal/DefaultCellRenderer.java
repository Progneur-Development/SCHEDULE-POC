package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridCellRenderer;
import org.eclipse.nebula.widgets.grid.GridItem;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.graphics.TextLayout;
import org.eclipse.swt.widgets.Display;

public class DefaultCellRenderer extends GridCellRenderer
{
  int leftMargin = 4;
  int rightMargin = 4;
  int topMargin = 0;
  int bottomMargin = 0;
  int textTopMargin = 1;
  int textBottomMargin = 2;
  private int insideMargin = 3;
  int treeIndent = 20;
  private ToggleRenderer toggleRenderer;
  private BranchRenderer branchRenderer;
  private CheckBoxRenderer checkRenderer;
  private TextLayout textLayout;

  public void paint(GC paramGC, Object paramObject)
  {
    GridItem localGridItem = (GridItem)paramObject;
    paramGC.setFont(localGridItem.getFont(getColumn()));
    boolean bool1 = isSelected();
    int i = 1;
    if (isCellSelected())
      bool1 = true;
    if (bool1)
    {
      paramGC.setBackground(getDisplay().getSystemColor(26));
      paramGC.setForeground(getDisplay().getSystemColor(27));
    }
    else
    {
      if (localGridItem.getParent().isEnabled())
      {
        Color localColor = localGridItem.getBackground(getColumn());
        if (localColor != null)
          paramGC.setBackground(localColor);
        else
          i = 0;
      }
      else
      {
        paramGC.setBackground(getDisplay().getSystemColor(22));
      }
      paramGC.setForeground(localGridItem.getForeground(getColumn()));
    }
    if (i != 0)
      paramGC.fillRectangle(getBounds().x, getBounds().y, getBounds().width, getBounds().height);
    int j = this.leftMargin;
    if (isTree())
    {
      boolean bool2 = localGridItem.getParent().getTreeLinesVisible();
      if (bool2)
      {
        this.branchRenderer.setBranches(getBranches(localGridItem));
        this.branchRenderer.setIndent(this.treeIndent);
        this.branchRenderer.setBounds(getBounds().x + j, getBounds().y, getToggleIndent(localGridItem), getBounds().height + 1);
      }
      j += getToggleIndent(localGridItem);
      this.toggleRenderer.setExpanded(localGridItem.isExpanded());
      this.toggleRenderer.setHover(getHoverDetail().equals("toggle"));
      this.toggleRenderer.setLocation(getBounds().x + j, (getBounds().height - this.toggleRenderer.getBounds().height) / 2 + getBounds().y);
      if (localGridItem.hasChildren())
        this.toggleRenderer.paint(paramGC, null);
      if (bool2)
      {
        this.branchRenderer.setToggleBounds(this.toggleRenderer.getBounds());
        this.branchRenderer.paint(paramGC, null);
      }
      j += this.toggleRenderer.getBounds().width + this.insideMargin;
    }
    if (isCheck())
    {
      this.checkRenderer.setChecked(localGridItem.getChecked(getColumn()));
      this.checkRenderer.setGrayed(localGridItem.getGrayed(getColumn()));
      if (!localGridItem.getParent().isEnabled())
        this.checkRenderer.setGrayed(true);
      this.checkRenderer.setHover(getHoverDetail().equals("check"));
      if (isCenteredCheckBoxOnly(localGridItem))
      {
        this.checkRenderer.setBounds(getBounds().x + (getBounds().width - this.checkRenderer.getBounds().width) / 2, (getBounds().height - this.checkRenderer.getBounds().height) / 2 + getBounds().y, this.checkRenderer.getBounds().width, this.checkRenderer.getBounds().height);
      }
      else
      {
        this.checkRenderer.setBounds(getBounds().x + j, (getBounds().height - this.checkRenderer.getBounds().height) / 2 + getBounds().y, this.checkRenderer.getBounds().width, this.checkRenderer.getBounds().height);
        j += this.checkRenderer.getBounds().width + this.insideMargin;
      }
      this.checkRenderer.paint(paramGC, null);
    }
    Image localImage = localGridItem.getImage(getColumn());
    if (localImage != null)
    {
      k = getBounds().y;
      k += (getBounds().height - localImage.getBounds().height) / 2;
      paramGC.drawImage(localImage, getBounds().x + j, k);
      j += localImage.getBounds().width + this.insideMargin;
    }
    int k = getBounds().width - j - this.rightMargin;
    if (bool1)
      paramGC.setForeground(getDisplay().getSystemColor(27));
    else
      paramGC.setForeground(localGridItem.getForeground(getColumn()));
    Object localObject;
    if (!isWordWrap())
    {
      localObject = TextUtils.getShortString(paramGC, localGridItem.getText(getColumn()), k);
      int m;
      if (getAlignment() == 131072)
      {
        m = paramGC.stringExtent((String)localObject).x;
        if (m < k)
          j += k - m;
      }
      else if (getAlignment() == 16777216)
      {
        m = paramGC.stringExtent((String)localObject).x;
        if (m < k)
          j += (k - m) / 2;
      }
      paramGC.drawString((String)localObject, getBounds().x + j, getBounds().y + this.textTopMargin + this.topMargin, true);
    }
    else
    {
      if (this.textLayout == null)
      {
        this.textLayout = new TextLayout(paramGC.getDevice());
        localGridItem.getParent().addDisposeListener(new DisposeListener()
        {
          public void widgetDisposed(DisposeEvent paramAnonymousDisposeEvent)
          {
            DefaultCellRenderer.this.textLayout.dispose();
          }
        });
      }
      this.textLayout.setFont(paramGC.getFont());
      this.textLayout.setText(localGridItem.getText(getColumn()));
      this.textLayout.setAlignment(getAlignment());
      this.textLayout.setWidth(k < 1 ? 1 : k);
      this.textLayout.draw(paramGC, getBounds().x + j, getBounds().y + this.textTopMargin + this.topMargin);
    }
    if (localGridItem.getParent().getLinesVisible())
    {
      if (isCellSelected())
        paramGC.setForeground(getDisplay().getSystemColor(17));
      else
        paramGC.setForeground(localGridItem.getParent().getLineColor());
      paramGC.drawLine(getBounds().x, getBounds().y + getBounds().height, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height);
      paramGC.drawLine(getBounds().x + getBounds().width - 1, getBounds().y, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height);
    }
    if (isCellFocus())
    {
      localObject = new Rectangle(getBounds().x - 1, getBounds().y - 1, getBounds().width, getBounds().height + 1);
      paramGC.setForeground(getDisplay().getSystemColor(24));
      paramGC.drawRectangle((Rectangle)localObject);
      if (isFocus())
      {
        localObject.x += 1;
        localObject.width -= 2;
        localObject.y += 1;
        localObject.height -= 2;
        paramGC.drawRectangle((Rectangle)localObject);
      }
    }
  }

  private int[] getBranches(GridItem paramGridItem)
  {
    int[] arrayOfInt = new int[paramGridItem.getLevel() + 1];
    GridItem[] arrayOfGridItem = paramGridItem.getParent().getRootItems();
    if (paramGridItem.getParentItem() == null)
    {
      if ((!paramGridItem.isExpanded()) && (arrayOfGridItem[(arrayOfGridItem.length - 1)].equals(paramGridItem)))
      {
        if (paramGridItem.hasChildren())
          arrayOfInt[paramGridItem.getLevel()] = 128;
        else
          arrayOfInt[paramGridItem.getLevel()] = 36;
      }
      else if (paramGridItem.hasChildren())
        arrayOfInt[paramGridItem.getLevel()] = 192;
      else
        arrayOfInt[paramGridItem.getLevel()] = 20;
    }
    else if (paramGridItem.hasChildren())
    {
      if (paramGridItem.isExpanded())
        arrayOfInt[paramGridItem.getLevel()] = 64;
      else
        arrayOfInt[paramGridItem.getLevel()] = 0;
    }
    else
      arrayOfInt[paramGridItem.getLevel()] = 8;
    GridItem localGridItem = paramGridItem.getParentItem();
    if (localGridItem == null)
      return arrayOfInt;
    if (localGridItem.indexOf(paramGridItem) < localGridItem.getItemCount() - 1)
      arrayOfInt[(paramGridItem.getLevel() - 1)] = 18;
    else if ((localGridItem.getParentItem() == null) && (!localGridItem.equals(arrayOfGridItem[(arrayOfGridItem.length - 1)])))
      arrayOfInt[(paramGridItem.getLevel() - 1)] = 18;
    else
      arrayOfInt[(paramGridItem.getLevel() - 1)] = 34;
    Grid localGrid = paramGridItem.getParent();
    paramGridItem = localGridItem;
    for (localGridItem = paramGridItem.getParentItem(); paramGridItem.getLevel() > 0; localGridItem = paramGridItem.getParentItem())
    {
      if (localGridItem.indexOf(paramGridItem) == localGridItem.getItemCount() - 1)
      {
        if ((localGridItem.getParentItem() == null) && (!localGrid.getRootItem(localGrid.getRootItemCount() - 1).equals(localGridItem)))
          arrayOfInt[(paramGridItem.getLevel() - 1)] = 16;
        else
          arrayOfInt[(paramGridItem.getLevel() - 1)] = 0;
      }
      else
        arrayOfInt[(paramGridItem.getLevel() - 1)] = 16;
      paramGridItem = localGridItem;
    }
    return arrayOfInt;
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    GridItem localGridItem = (GridItem)paramObject;
    paramGC.setFont(localGridItem.getFont(getColumn()));
    int i = 0;
    i += this.leftMargin;
    if (isTree())
    {
      i += getToggleIndent(localGridItem);
      i += this.toggleRenderer.getBounds().width + this.insideMargin;
    }
    if (isCheck())
      i += this.checkRenderer.getBounds().width + this.insideMargin;
    int j = 0;
    Image localImage = localGridItem.getImage(getColumn());
    if (localImage != null)
    {
      j = this.topMargin + localImage.getBounds().height + this.bottomMargin;
      i += localImage.getBounds().width + this.insideMargin;
    }
    int k = 0;
    if (!isWordWrap())
    {
      i += paramGC.textExtent(localGridItem.getText(getColumn())).x + this.rightMargin;
      k = this.topMargin + this.textTopMargin + paramGC.getFontMetrics().getHeight() + this.textBottomMargin + this.bottomMargin;
    }
    else
    {
      int m;
      if (paramInt1 == -1)
        m = paramGC.textExtent(localGridItem.getText(getColumn())).x;
      else
        m = paramInt1 - i - this.rightMargin;
      TextLayout localTextLayout = new TextLayout(paramGC.getDevice());
      localTextLayout.setFont(paramGC.getFont());
      localTextLayout.setText(localGridItem.getText(getColumn()));
      localTextLayout.setAlignment(getAlignment());
      localTextLayout.setWidth(m < 1 ? 1 : m);
      i += m + this.rightMargin;
      k += this.topMargin + this.textTopMargin;
      for (int n = 0; n < localTextLayout.getLineCount(); n++)
        k += localTextLayout.getLineBounds(n).height;
      k += this.textBottomMargin + this.bottomMargin;
      localTextLayout.dispose();
    }
    j = Math.max(j, k);
    return new Point(i, j);
  }

  public boolean notify(int paramInt, Point paramPoint, Object paramObject)
  {
    GridItem localGridItem = (GridItem)paramObject;
    if (isCheck())
    {
      if ((paramInt == 5) && (overCheck(localGridItem, paramPoint)))
      {
        setHoverDetail("check");
        return true;
      }
      if ((paramInt == 3) && (overCheck(localGridItem, paramPoint)))
      {
        if (!localGridItem.getCheckable(getColumn()))
          return false;
        localGridItem.setChecked(getColumn(), !localGridItem.getChecked(getColumn()));
        localGridItem.getParent().redraw();
        localGridItem.fireCheckEvent(getColumn());
        return true;
      }
    }
    if ((isTree()) && (localGridItem.hasChildren()))
    {
      if ((paramInt == 5) && (overToggle(localGridItem, paramPoint)))
      {
        setHoverDetail("toggle");
        return true;
      }
      if ((paramInt == 3) && (overToggle(localGridItem, paramPoint)))
      {
        localGridItem.setExpanded(!localGridItem.isExpanded());
        localGridItem.getParent().redraw();
        if (localGridItem.isExpanded())
          localGridItem.fireEvent(17);
        else
          localGridItem.fireEvent(18);
        return true;
      }
    }
    return false;
  }

  private boolean overCheck(GridItem paramGridItem, Point paramPoint)
  {
    if (isCenteredCheckBoxOnly(paramGridItem))
    {
      paramPoint = new Point(paramPoint.x, paramPoint.y);
      paramPoint.x -= getBounds().x;
      paramPoint.y -= getBounds().y;
      Rectangle localRectangle = new Rectangle(0, 0, 0, 0);
      localRectangle.x = ((getBounds().width - this.checkRenderer.getBounds().width) / 2);
      localRectangle.y = ((getBounds().height - this.checkRenderer.getBounds().height) / 2);
      localRectangle.width = this.checkRenderer.getBounds().width;
      localRectangle.height = this.checkRenderer.getBounds().height;
      return localRectangle.contains(paramPoint);
    }
    paramPoint = new Point(paramPoint.x, paramPoint.y);
    paramPoint.x -= getBounds().x;
    paramPoint.y -= getBounds().y;
    int i = this.leftMargin;
    if (isTree())
    {
      i += getToggleIndent(paramGridItem);
      i += this.toggleRenderer.getSize().x + this.insideMargin;
    }
    if ((paramPoint.x >= i) && (paramPoint.x < i + this.checkRenderer.getSize().x))
    {
      int j = (getBounds().height - this.checkRenderer.getBounds().height) / 2;
      if ((paramPoint.y >= j) && (paramPoint.y < j + this.checkRenderer.getSize().y))
        return true;
    }
    return false;
  }

  private int getToggleIndent(GridItem paramGridItem)
  {
    return paramGridItem.getLevel() * this.treeIndent;
  }

  private boolean overToggle(GridItem paramGridItem, Point paramPoint)
  {
    paramPoint = new Point(paramPoint.x, paramPoint.y);
    paramPoint.x -= getBounds().x - 1;
    paramPoint.y -= getBounds().y - 1;
    int i = this.leftMargin;
    i += getToggleIndent(paramGridItem);
    if ((paramPoint.x >= i) && (paramPoint.x < i + this.toggleRenderer.getSize().x))
    {
      int j = (getBounds().height - this.toggleRenderer.getBounds().height) / 2;
      if ((paramPoint.y >= j) && (paramPoint.y < j + this.toggleRenderer.getSize().y))
        return true;
    }
    return false;
  }

  public void setTree(boolean paramBoolean)
  {
    super.setTree(paramBoolean);
    if (paramBoolean)
    {
      this.toggleRenderer = new ToggleRenderer();
      this.toggleRenderer.setDisplay(getDisplay());
      this.branchRenderer = new BranchRenderer();
      this.branchRenderer.setDisplay(getDisplay());
    }
  }

  public void setCheck(boolean paramBoolean)
  {
    super.setCheck(paramBoolean);
    if (paramBoolean)
    {
      this.checkRenderer = new CheckBoxRenderer();
      this.checkRenderer.setDisplay(getDisplay());
    }
    else
    {
      this.checkRenderer = null;
    }
  }

  public Rectangle getTextBounds(GridItem paramGridItem, boolean paramBoolean)
  {
    int i = this.leftMargin;
    if (isTree())
    {
      i += getToggleIndent(paramGridItem);
      i += this.toggleRenderer.getBounds().width + this.insideMargin;
    }
    if (isCheck())
      i += this.checkRenderer.getBounds().width + this.insideMargin;
    Image localImage = paramGridItem.getImage(getColumn());
    if (localImage != null)
      i += localImage.getBounds().width + this.insideMargin;
    Rectangle localRectangle = new Rectangle(i, this.topMargin + this.textTopMargin, 0, 0);
    GC localGC = new GC(paramGridItem.getParent());
    localGC.setFont(paramGridItem.getFont(getColumn()));
    Point localPoint = localGC.stringExtent(paramGridItem.getText(getColumn()));
    localRectangle.height = localPoint.y;
    if (paramBoolean)
      localRectangle.width = (localPoint.x - 1);
    else
      localRectangle.width = (getBounds().width - i - this.rightMargin);
    localGC.dispose();
    return localRectangle;
  }

  private boolean isCenteredCheckBoxOnly(GridItem paramGridItem)
  {
    return (!isTree()) && (paramGridItem.getImage(getColumn()) == null) && (paramGridItem.getText(getColumn()).equals("")) && (getAlignment() == 16777216);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.DefaultCellRenderer
 * JD-Core Version:    0.6.2
 */