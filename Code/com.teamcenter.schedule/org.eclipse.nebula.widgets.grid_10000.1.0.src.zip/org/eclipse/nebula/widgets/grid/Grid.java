package org.eclipse.nebula.widgets.grid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import org.eclipse.nebula.widgets.grid.internal.DefaultBottomLeftRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultColumnGroupHeaderRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultDropPointRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultEmptyCellRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultEmptyColumnFooterRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultEmptyColumnHeaderRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultEmptyRowHeaderRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultFocusRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultInsertMarkRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultRowHeaderRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultTopLeftRenderer;
import org.eclipse.nebula.widgets.grid.internal.GridToolTip;
import org.eclipse.nebula.widgets.grid.internal.IScrollBarProxy;
import org.eclipse.nebula.widgets.grid.internal.NullScrollBarProxy;
import org.eclipse.nebula.widgets.grid.internal.ScrollBarProxyAdapter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.accessibility.Accessible;
import org.eclipse.swt.accessibility.AccessibleAdapter;
import org.eclipse.swt.accessibility.AccessibleControlAdapter;
import org.eclipse.swt.accessibility.AccessibleControlEvent;
import org.eclipse.swt.accessibility.AccessibleEvent;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.MouseTrackListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.events.TreeEvent;
import org.eclipse.swt.events.TreeListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.TypedListener;
import org.eclipse.swt.widgets.Widget;

public class Grid extends Canvas
{
  private static final String ACC_COLUMN_DEFAULT_ACTION = "Click";
  private static final String ACC_ITEM_DEFAULT_ACTION = "Double Click";
  private static final String ACC_ITEM_ACTION_EXPAND = "Expand";
  private static final String ACC_ITEM_ACTION_COLLAPSE = "Collapse";
  private static final String ACC_TOGGLE_BUTTON_NAME = "Toggle Button";
  private static final int COLUMN_DRAG_ALPHA = 128;
  private static final int DROP_POINT_LOWER_OFFSET = 3;
  private static final int HORZ_SCROLL_INCREMENT = 5;
  private static final int COLUMN_RESIZER_THRESHOLD = 4;
  private static final int ROW_RESIZER_THRESHOLD = 3;
  private static final int MIN_COLUMN_HEADER_WIDTH = 20;
  private static final int MIN_ROW_HEADER_HEIGHT = 10;
  private boolean scrollValuesObsolete = false;
  private List items = new ArrayList();
  private List rootItems = new ArrayList();
  private List selectedItems = new ArrayList();
  private GridItem focusItem;
  private boolean cellSelectionEnabled = false;
  private List selectedCells = new ArrayList();
  private List selectedCellsBeforeRangeSelect = new ArrayList();
  private boolean cellDragSelectionOccuring = false;
  private boolean cellRowDragSelectionOccuring = false;
  private boolean cellColumnDragSelectionOccuring = false;
  private boolean cellDragCTRL = false;
  private boolean followupCellSelectionEventOwed = false;
  private boolean cellSelectedOnLastMouseDown;
  private boolean cellRowSelectedOnLastMouseDown;
  private boolean cellColumnSelectedOnLastMouseDown;
  private GridColumn shiftSelectionAnchorColumn;
  private GridColumn focusColumn;
  private GridColumn sortColumn;
  private int sortDirection;
  private List selectedColumns = new ArrayList();
  private GridColumn intendedFocusColumn;
  private List columns = new ArrayList();
  private List displayOrderedColumns = new ArrayList();
  private GridColumnGroup[] columnGroups = new GridColumnGroup[0];
  private IRenderer topLeftRenderer = new DefaultTopLeftRenderer();
  private IRenderer bottomLeftRenderer = new DefaultBottomLeftRenderer();
  private IRenderer rowHeaderRenderer = new DefaultRowHeaderRenderer();
  private IRenderer emptyColumnHeaderRenderer = new DefaultEmptyColumnHeaderRenderer();
  private IRenderer emptyColumnFooterRenderer = new DefaultEmptyColumnFooterRenderer();
  private GridCellRenderer emptyCellRenderer = new DefaultEmptyCellRenderer();
  private IRenderer emptyRowHeaderRenderer = new DefaultEmptyRowHeaderRenderer();
  private IRenderer dropPointRenderer = new DefaultDropPointRenderer();
  private IRenderer focusRenderer = new DefaultFocusRenderer();
  private boolean rowHeaderVisible = false;
  private boolean columnHeadersVisible = false;
  private boolean columnFootersVisible = false;
  private int selectionType = 4;
  private boolean selectionEnabled = true;
  private int itemHeight = 1;
  private boolean userModifiedItemHeight = false;
  private int rowHeaderWidth = 0;
  private int headerHeight = 0;
  private int footerHeight = 0;
  boolean hoveringOnColumnResizer = false;
  private GridColumn columnBeingResized;
  private boolean rowsResizeable = false;
  private boolean resizingColumn = false;
  private int resizingStartX = 0;
  private int resizingColumnStartWidth = 0;
  private boolean hoveringOnRowResizer = false;
  private GridItem rowBeingResized;
  private boolean resizingRow = false;
  private int resizingStartY;
  private int resizingRowStartHeight;
  private GridColumn columnBeingPushed;
  private boolean pushingColumn = false;
  private boolean pushingAndHovering = false;
  private int startHeaderPushX = 0;
  private int startHeaderDragX = 0;
  private int currentHeaderDragX = 0;
  private boolean draggingColumn = false;
  private GridColumn dragDropBeforeColumn = null;
  private GridColumn dragDropAfterColumn = null;
  private boolean dragDropPointValid = true;
  private GridItem hoveringItem;
  private GridColumn hoveringColumn;
  private GridColumn hoveringColumnHeader;
  private GridColumnGroup hoverColumnGroupHeader;
  private String hoveringDetail = "";
  private boolean hoveringOverText = false;
  private boolean linesVisible = true;
  private boolean treeLinesVisible = true;
  private Color lineColor;
  private IScrollBarProxy vScroll;
  private IScrollBarProxy hScroll;
  private int currentVisibleItems = 0;
  private GridItem shiftSelectionAnchorItem;
  private boolean columnScrolling = false;
  private int groupHeaderHeight;
  private Color cellHeaderSelectionBackground;
  private Listener disposeListener;
  private GridToolTip inplaceToolTip;
  private GC sizingGC;
  private Color backgroundColor;
  private boolean disposing = false;
  private boolean isTree = false;
  boolean hasDifferingHeights = false;
  private boolean hasSpanning = false;
  int topIndex = -1;
  int bottomIndex = -1;
  int startColumnIndex = -1;
  int endColumnIndex = -1;
  private boolean bottomIndexShownCompletely = false;
  private String toolTipText = null;
  private boolean firstImageSet = false;
  private boolean inplaceTooltipCapture;
  private String displayedToolTipText;
  private static final int DRAG_SCROLL_AREA_HEIGHT = 12;
  private static final int SELECTION_DRAG_BORDER_THRESHOLD = 2;
  private boolean hoveringOnSelectionDragArea = false;
  private GridItem insertMarkItem = null;
  private GridColumn insertMarkColumn = null;
  private boolean insertMarkBefore = false;
  private IRenderer insertMarkRenderer = new DefaultInsertMarkRenderer();
  private boolean sizeOnEveryItemImageChange;
  private static int size100 = -1;
  private static int font100 = -1;

  private static int checkStyle(int paramInt)
  {
    int i = 369625894;
    int j = paramInt & i;
    j |= 536870912;
    return j;
  }

  public Grid(Composite paramComposite, int paramInt)
  {
    super(paramComposite, checkStyle(paramInt));
    setData("DEFAULT_DRAG_SOURCE_EFFECT", new GridDragSourceEffect(this));
    setData("DEFAULT_DROP_TARGET_EFFECT", new GridDropTargetEffect(this));
    this.sizingGC = new GC(this);
    this.topLeftRenderer.setDisplay(getDisplay());
    this.bottomLeftRenderer.setDisplay(getDisplay());
    this.rowHeaderRenderer.setDisplay(getDisplay());
    this.emptyColumnHeaderRenderer.setDisplay(getDisplay());
    this.emptyColumnFooterRenderer.setDisplay(getDisplay());
    this.emptyCellRenderer.setDisplay(getDisplay());
    this.dropPointRenderer.setDisplay(getDisplay());
    this.focusRenderer.setDisplay(getDisplay());
    this.emptyRowHeaderRenderer.setDisplay(getDisplay());
    this.insertMarkRenderer.setDisplay(getDisplay());
    setForeground(getDisplay().getSystemColor(24));
    setLineColor(getDisplay().getSystemColor(22));
    if ((paramInt & 0x2) != 0)
      this.selectionType = 2;
    if (getVerticalBar() != null)
    {
      getVerticalBar().setVisible(false);
      this.vScroll = new ScrollBarProxyAdapter(getVerticalBar());
    }
    else
    {
      this.vScroll = new NullScrollBarProxy();
    }
    if (getHorizontalBar() != null)
    {
      getHorizontalBar().setVisible(false);
      this.hScroll = new ScrollBarProxyAdapter(getHorizontalBar());
    }
    else
    {
      this.hScroll = new NullScrollBarProxy();
    }
    this.scrollValuesObsolete = true;
    initListeners();
    initAccessible();
    this.itemHeight = (this.sizingGC.getFontMetrics().getHeight() + 2);
    RGB localRGB1 = getDisplay().getSystemColor(26).getRGB();
    RGB localRGB2 = getDisplay().getSystemColor(1).getRGB();
    RGB localRGB3 = blend(localRGB1, localRGB2, 50);
    this.cellHeaderSelectionBackground = new Color(getDisplay(), localRGB3);
    setDragDetect(false);
  }

  public Color getBackground()
  {
    checkWidget();
    if (this.backgroundColor == null)
      return getDisplay().getSystemColor(25);
    return this.backgroundColor;
  }

  public void setBackground(Color paramColor)
  {
    checkWidget();
    this.backgroundColor = paramColor;
    redraw();
  }

  public Color getCellHeaderSelectionBackground()
  {
    checkWidget();
    return this.cellHeaderSelectionBackground;
  }

  public void setCellHeaderSelectionBackground(Color paramColor)
  {
    checkWidget();
    this.cellHeaderSelectionBackground = paramColor;
  }

  public void addSelectionListener(SelectionListener paramSelectionListener)
  {
    checkWidget();
    if (paramSelectionListener == null)
      SWT.error(4);
    addListener(13, new TypedListener(paramSelectionListener));
    addListener(14, new TypedListener(paramSelectionListener));
  }

  public void addTreeListener(TreeListener paramTreeListener)
  {
    checkWidget();
    if (paramTreeListener == null)
      SWT.error(4);
    addListener(17, new TypedListener(paramTreeListener));
    addListener(18, new TypedListener(paramTreeListener));
  }

  public Point computeSize(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    checkWidget();
    Point localPoint = null;
    if ((paramInt1 == -1) || (paramInt2 == -1))
    {
      localPoint = getTableSize();
      localPoint.x += 2 * getBorderWidth();
      localPoint.y += 2 * getBorderWidth();
    }
    int i = 0;
    int j = 0;
    if (paramInt1 == -1)
    {
      i += localPoint.x;
      if (getVerticalBar() != null)
        i += getVerticalBar().getSize().x;
    }
    else
    {
      i = paramInt1;
    }
    if (paramInt2 == -1)
    {
      j += localPoint.y;
      if (getHorizontalBar() != null)
        j += getHorizontalBar().getSize().y;
    }
    else
    {
      j = paramInt2;
    }
    return new Point(i, j);
  }

  public void deselect(int paramInt)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt > this.items.size() - 1))
      return;
    GridItem localGridItem = (GridItem)this.items.get(paramInt);
    if (!this.cellSelectionEnabled)
    {
      if (this.selectedItems.contains(localGridItem))
        this.selectedItems.remove(localGridItem);
    }
    else
      deselectCells(getCells(localGridItem));
    redraw();
  }

  public void deselect(int paramInt1, int paramInt2)
  {
    checkWidget();
    for (int i = paramInt1; i <= paramInt2; i++)
      if (i >= 0)
      {
        if (i > this.items.size() - 1)
          break;
        GridItem localGridItem = (GridItem)this.items.get(i);
        if (!this.cellSelectionEnabled)
        {
          if (this.selectedItems.contains(localGridItem))
            this.selectedItems.remove(localGridItem);
        }
        else
          deselectCells(getCells(localGridItem));
      }
    redraw();
  }

  public void deselect(int[] paramArrayOfInt)
  {
    checkWidget();
    if (paramArrayOfInt == null)
      SWT.error(4);
    for (int i : paramArrayOfInt)
      if ((i >= 0) && (i < this.items.size()))
      {
        GridItem localGridItem = (GridItem)this.items.get(i);
        if (!this.cellSelectionEnabled)
        {
          if (this.selectedItems.contains(localGridItem))
            this.selectedItems.remove(localGridItem);
        }
        else
          deselectCells(getCells(localGridItem));
      }
    redraw();
  }

  public void deselectAll()
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
    {
      this.selectedItems.clear();
      redraw();
    }
    else
    {
      deselectAllCells();
    }
  }

  public GridColumn getColumn(int paramInt)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt > getColumnCount() - 1))
      SWT.error(6);
    return (GridColumn)this.columns.get(paramInt);
  }

  public GridColumn getColumn(Point paramPoint)
  {
    checkWidget();
    if (paramPoint == null)
      SWT.error(4);
    Object localObject1 = null;
    int i = 0;
    if (this.rowHeaderVisible)
    {
      if (paramPoint.x <= this.rowHeaderWidth)
        return null;
      i += this.rowHeaderWidth;
    }
    i -= getHScrollSelectionInPixels();
    Object localObject2 = this.displayOrderedColumns.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      GridColumn localGridColumn = (GridColumn)((Iterator)localObject2).next();
      if (localGridColumn.isVisible())
      {
        if ((paramPoint.x >= i) && (paramPoint.x < i + localGridColumn.getWidth()))
        {
          localObject1 = localGridColumn;
          break;
        }
        i += localGridColumn.getWidth();
      }
    }
    if (localObject1 == null)
      return null;
    if (this.hasSpanning)
    {
      localObject2 = getItem(paramPoint);
      if (localObject2 != null)
      {
        int j = this.displayOrderedColumns.indexOf(localObject1);
        for (int k = 0; k < j; k++)
          if (((GridColumn)this.displayOrderedColumns.get(k)).isVisible())
          {
            int m = indexOf((GridColumn)this.displayOrderedColumns.get(k));
            int n = ((GridItem)localObject2).getColumnSpan(m);
            if (k + n >= j)
            {
              localObject1 = (GridColumn)this.displayOrderedColumns.get(k);
              break;
            }
          }
      }
    }
    return localObject1;
  }

  public int getColumnCount()
  {
    checkWidget();
    return this.columns.size();
  }

  public int[] getColumnOrder()
  {
    checkWidget();
    int[] arrayOfInt = new int[this.columns.size()];
    int i = 0;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      arrayOfInt[i] = this.columns.indexOf(localGridColumn);
      i++;
    }
    return arrayOfInt;
  }

  public int getColumnGroupCount()
  {
    checkWidget();
    return this.columnGroups.length;
  }

  public GridColumnGroup[] getColumnGroups()
  {
    checkWidget();
    GridColumnGroup[] arrayOfGridColumnGroup = new GridColumnGroup[this.columnGroups.length];
    System.arraycopy(this.columnGroups, 0, arrayOfGridColumnGroup, 0, this.columnGroups.length);
    return arrayOfGridColumnGroup;
  }

  public GridColumnGroup getColumnGroup(int paramInt)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt >= this.columnGroups.length))
      SWT.error(6);
    return this.columnGroups[paramInt];
  }

  public void setColumnOrder(int[] paramArrayOfInt)
  {
    checkWidget();
    if (paramArrayOfInt == null)
      SWT.error(4);
    if (paramArrayOfInt.length != this.displayOrderedColumns.size())
      SWT.error(5);
    boolean[] arrayOfBoolean = new boolean[this.displayOrderedColumns.size()];
    for (int i = 0; i < paramArrayOfInt.length; i++)
    {
      if ((paramArrayOfInt[i] < 0) || (paramArrayOfInt[i] >= this.displayOrderedColumns.size()))
        SWT.error(5);
      if (arrayOfBoolean[paramArrayOfInt[i]] != 0)
        SWT.error(5);
      arrayOfBoolean[paramArrayOfInt[i]] = true;
    }
    int j;
    int k;
    if (this.columnGroups.length != 0)
    {
      localObject = null;
      j = 0;
      for (k : paramArrayOfInt)
      {
        GridColumn localGridColumn = getColumn(k);
        if (localObject != null)
        {
          if (localGridColumn.getColumnGroup() != localObject)
          {
            SWT.error(5);
          }
          else
          {
            j--;
            if (j == 0)
              localObject = null;
          }
        }
        else if (localGridColumn.getColumnGroup() != null)
        {
          localObject = localGridColumn.getColumnGroup();
          j = ((GridColumnGroup)localObject).getColumns().length - 1;
        }
      }
    }
    Object localObject = getColumns();
    this.displayOrderedColumns.clear();
    for (j : paramArrayOfInt)
      this.displayOrderedColumns.add(localObject[j]);
  }

  public GridColumn[] getColumns()
  {
    checkWidget();
    return (GridColumn[])this.columns.toArray(new GridColumn[this.columns.size()]);
  }

  public GridColumn getSortColumn()
  {
    return this.sortColumn;
  }

  public void setSortColumn(GridColumn paramGridColumn)
  {
    this.sortColumn = paramGridColumn;
  }

  public int getSortDirection()
  {
    return this.sortDirection;
  }

  public void setSortDirection(int paramInt)
  {
    this.sortDirection = paramInt;
  }

  public GridCellRenderer getEmptyCellRenderer()
  {
    checkWidget();
    return this.emptyCellRenderer;
  }

  public IRenderer getEmptyColumnHeaderRenderer()
  {
    checkWidget();
    return this.emptyColumnHeaderRenderer;
  }

  public IRenderer getEmptyColumnFooterRenderer()
  {
    checkWidget();
    return this.emptyColumnFooterRenderer;
  }

  public IRenderer getEmptyRowHeaderRenderer()
  {
    checkWidget();
    return this.emptyRowHeaderRenderer;
  }

  protected IScrollBarProxy getHorizontalScrollBarProxy()
  {
    checkWidget();
    return this.hScroll;
  }

  protected IScrollBarProxy getVerticalScrollBarProxy()
  {
    checkWidget();
    return this.vScroll;
  }

  public IRenderer getFocusRenderer()
  {
    checkWidget();
    return this.focusRenderer;
  }

  public int getHeaderHeight()
  {
    checkWidget();
    return this.headerHeight;
  }

  public int getFooterHeight()
  {
    checkWidget();
    return this.footerHeight;
  }

  public int getGroupHeaderHeight()
  {
    checkWidget();
    return this.groupHeaderHeight;
  }

  public boolean getHeaderVisible()
  {
    checkWidget();
    return this.columnHeadersVisible;
  }

  public boolean getFooterVisible()
  {
    checkWidget();
    return this.columnFootersVisible;
  }

  public GridItem getItem(int paramInt)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt >= this.items.size()))
      SWT.error(6);
    return (GridItem)this.items.get(paramInt);
  }

  public GridItem getItem(Point paramPoint)
  {
    checkWidget();
    if (paramPoint == null)
      SWT.error(4);
    if ((paramPoint.x < 0) || (paramPoint.x > getClientArea().width))
      return null;
    Point localPoint = new Point(paramPoint.x, paramPoint.y);
    int i = 0;
    if (this.columnHeadersVisible)
    {
      if (localPoint.y <= this.headerHeight)
        return null;
      i += this.headerHeight;
    }
    for (int j = getTopIndex(); (j < this.items.size()) && (i <= getClientArea().height); j++)
    {
      GridItem localGridItem = (GridItem)this.items.get(j);
      if (localGridItem.isVisible())
      {
        int k = localGridItem.getHeight();
        if ((localPoint.y >= i) && (localPoint.y < i + k + 1))
          return localGridItem;
        i += k + 1;
      }
    }
    return null;
  }

  public int getItemCount()
  {
    checkWidget();
    return getItems().length;
  }

  public int getItemHeight()
  {
    checkWidget();
    return this.itemHeight;
  }

  public void setItemHeight(int paramInt)
  {
    checkWidget();
    if (paramInt < 1)
      SWT.error(5);
    this.itemHeight = paramInt;
    this.userModifiedItemHeight = true;
    for (int i = 0; i < this.items.size(); i++)
      ((GridItem)this.items.get(i)).setHeight(paramInt);
    this.hasDifferingHeights = false;
    setScrollValuesObsolete();
    redraw();
  }

  public boolean getRowsResizeable()
  {
    checkWidget();
    return this.rowsResizeable;
  }

  public void setRowsResizeable(boolean paramBoolean)
  {
    checkWidget();
    this.rowsResizeable = paramBoolean;
  }

  public GridItem[] getItems()
  {
    checkWidget();
    return (GridItem[])this.items.toArray(new GridItem[this.items.size()]);
  }

  public Color getLineColor()
  {
    checkWidget();
    return this.lineColor;
  }

  public boolean getLinesVisible()
  {
    checkWidget();
    return this.linesVisible;
  }

  public boolean getTreeLinesVisible()
  {
    checkWidget();
    return this.treeLinesVisible;
  }

  public GridItem getNextVisibleItem(GridItem paramGridItem)
  {
    checkWidget();
    int i = this.items.indexOf(paramGridItem);
    if (this.items.size() == i + 1)
      return null;
    for (GridItem localGridItem = (GridItem)this.items.get(i + 1); !localGridItem.isVisible(); localGridItem = (GridItem)this.items.get(i + 1))
    {
      i++;
      if (this.items.size() == i + 1)
        return null;
    }
    return localGridItem;
  }

  public GridItem getPreviousVisibleItem(GridItem paramGridItem)
  {
    checkWidget();
    int i = 0;
    if (paramGridItem == null)
    {
      i = this.items.size();
    }
    else
    {
      i = this.items.indexOf(paramGridItem);
      if (i == 0)
        return null;
    }
    for (GridItem localGridItem = (GridItem)this.items.get(i - 1); !localGridItem.isVisible(); localGridItem = (GridItem)this.items.get(i - 1))
    {
      i--;
      if (i == 0)
        return null;
    }
    return localGridItem;
  }

  public GridColumn getPreviousVisibleColumn(GridColumn paramGridColumn)
  {
    checkWidget();
    int i = this.displayOrderedColumns.indexOf(paramGridColumn);
    if (i == 0)
      return null;
    i--;
    for (GridColumn localGridColumn = (GridColumn)this.displayOrderedColumns.get(i); !localGridColumn.isVisible(); localGridColumn = (GridColumn)this.displayOrderedColumns.get(i))
    {
      if (i == 0)
        return null;
      i--;
    }
    return localGridColumn;
  }

  public GridColumn getNextVisibleColumn(GridColumn paramGridColumn)
  {
    checkWidget();
    int i = this.displayOrderedColumns.indexOf(paramGridColumn);
    if (i == this.displayOrderedColumns.size() - 1)
      return null;
    i++;
    for (GridColumn localGridColumn = (GridColumn)this.displayOrderedColumns.get(i); !localGridColumn.isVisible(); localGridColumn = (GridColumn)this.displayOrderedColumns.get(i))
    {
      if (i == this.displayOrderedColumns.size() - 1)
        return null;
      i++;
    }
    return localGridColumn;
  }

  public int getRootItemCount()
  {
    checkWidget();
    return this.rootItems.size();
  }

  public GridItem[] getRootItems()
  {
    checkWidget();
    return (GridItem[])this.rootItems.toArray(new GridItem[this.rootItems.size()]);
  }

  public GridItem getRootItem(int paramInt)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt >= this.rootItems.size()))
      SWT.error(6);
    return (GridItem)this.rootItems.get(paramInt);
  }

  public IRenderer getRowHeaderRenderer()
  {
    checkWidget();
    return this.rowHeaderRenderer;
  }

  public GridItem[] getSelection()
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
      return (GridItem[])this.selectedItems.toArray(new GridItem[this.selectedItems.size()]);
    Vector localVector = new Vector();
    Iterator localIterator = this.selectedCells.iterator();
    while (localIterator.hasNext())
    {
      Point localPoint = (Point)localIterator.next();
      GridItem localGridItem = getItem(localPoint.y);
      if (!localVector.contains(localGridItem))
        localVector.add(localGridItem);
    }
    return (GridItem[])localVector.toArray(new GridItem[0]);
  }

  public int getSelectionCount()
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
      return this.selectedItems.size();
    Vector localVector = new Vector();
    Iterator localIterator = this.selectedCells.iterator();
    while (localIterator.hasNext())
    {
      Point localPoint = (Point)localIterator.next();
      GridItem localGridItem = getItem(localPoint.y);
      if (!localVector.contains(localGridItem))
        localVector.add(localGridItem);
    }
    return localVector.size();
  }

  public int getCellSelectionCount()
  {
    checkWidget();
    return this.selectedCells.size();
  }

  public int getSelectionIndex()
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
    {
      if (this.selectedItems.size() == 0)
        return -1;
      return this.items.indexOf(this.selectedItems.get(0));
    }
    if (this.selectedCells.size() == 0)
      return -1;
    return ((Point)this.selectedCells.get(0)).y;
  }

  public int[] getSelectionIndices()
  {
    checkWidget();
    Object localObject3;
    if (!this.cellSelectionEnabled)
    {
      localObject1 = new int[this.selectedItems.size()];
      int i = 0;
      localObject3 = this.selectedItems.iterator();
      while (((Iterator)localObject3).hasNext())
      {
        localObject4 = (GridItem)((Iterator)localObject3).next();
        localObject1[i] = this.items.indexOf(localObject4);
        i++;
      }
      return localObject1;
    }
    Object localObject1 = new Vector();
    Object localObject2 = this.selectedCells.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (Point)((Iterator)localObject2).next();
      localObject4 = getItem(((Point)localObject3).y);
      if (!((Vector)localObject1).contains(localObject4))
        ((Vector)localObject1).add(localObject4);
    }
    localObject2 = new int[((Vector)localObject1).size()];
    int j = 0;
    Object localObject4 = ((Vector)localObject1).iterator();
    while (((Iterator)localObject4).hasNext())
    {
      GridItem localGridItem = (GridItem)((Iterator)localObject4).next();
      localObject2[j] = this.items.indexOf(localGridItem);
      j++;
    }
    return localObject2;
  }

  public int getTopIndex()
  {
    checkWidget();
    if (this.topIndex != -1)
      return this.topIndex;
    if (!this.vScroll.getVisible())
    {
      this.topIndex = 0;
    }
    else
    {
      int i = this.vScroll.getSelection();
      if (this.isTree)
      {
        Iterator localIterator = this.items.iterator();
        int j = i + 1;
        while ((j > 0) && (localIterator.hasNext()))
        {
          GridItem localGridItem = (GridItem)localIterator.next();
          if (localGridItem.isVisible())
          {
            j--;
            if (j == 0)
              i = this.items.indexOf(localGridItem);
          }
        }
      }
      this.topIndex = i;
    }
    return this.topIndex;
  }

  int getBottomIndex()
  {
    checkWidget();
    if (this.bottomIndex != -1)
      return this.bottomIndex;
    if (this.items.size() == 0)
    {
      this.bottomIndex = 0;
    }
    else if (getVisibleGridHeight() < 1)
    {
      this.bottomIndex = getTopIndex();
    }
    else
    {
      RowRange localRowRange = getRowRange(getTopIndex(), getVisibleGridHeight(), false, false);
      this.bottomIndex = localRowRange.endIndex;
      this.bottomIndexShownCompletely = (localRowRange.height <= getVisibleGridHeight());
    }
    return this.bottomIndex;
  }

  private RowRange getRowRange(int paramInt1, int paramInt2)
  {
    if (paramInt1 == -1)
    {
      do
        paramInt1++;
      while ((paramInt1 < this.items.size()) && (!((GridItem)this.items.get(paramInt1)).isVisible()));
      if (paramInt1 == this.items.size())
        return null;
    }
    if (paramInt2 == -1)
    {
      paramInt2 = this.items.size();
      do
        paramInt2--;
      while ((paramInt2 >= 0) && (!((GridItem)this.items.get(paramInt2)).isVisible()));
      if (paramInt2 == -1)
        return null;
    }
    if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 >= this.items.size()) || (paramInt2 >= this.items.size()) || (paramInt2 < paramInt1) || (!((GridItem)this.items.get(paramInt1)).isVisible()) || (!((GridItem)this.items.get(paramInt2)).isVisible()))
      SWT.error(5);
    RowRange localRowRange = new RowRange(null);
    localRowRange.startIndex = paramInt1;
    localRowRange.endIndex = paramInt2;
    if ((this.isTree) || (this.hasDifferingHeights))
    {
      for (int i = paramInt1; i <= paramInt2; i++)
      {
        GridItem localGridItem = (GridItem)this.items.get(i);
        if (localGridItem.isVisible())
        {
          if (localRowRange.rows > 0)
            localRowRange.height += 1;
          localRowRange.height += localGridItem.getHeight();
          localRowRange.rows += 1;
        }
      }
    }
    else
    {
      localRowRange.rows = (localRowRange.endIndex - localRowRange.startIndex + 1);
      localRowRange.height = ((getItemHeight() + 1) * localRowRange.rows - 1);
    }
    return localRowRange;
  }

  private RowRange getRowRange(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramInt1 == -1)
      if (!paramBoolean2)
      {
        do
          paramInt1++;
        while ((paramInt1 < this.items.size()) && (!((GridItem)this.items.get(paramInt1)).isVisible()));
        if (paramInt1 == this.items.size())
          return null;
      }
      else
      {
        paramInt1 = this.items.size();
        do
          paramInt1--;
        while ((paramInt1 >= 0) && (!((GridItem)this.items.get(paramInt1)).isVisible()));
        if (paramInt1 == -1)
          return null;
      }
    if ((paramInt1 < 0) || (paramInt1 >= this.items.size()) || (!((GridItem)this.items.get(paramInt1)).isVisible()))
      SWT.error(5);
    RowRange localRowRange = new RowRange(null);
    if (paramInt2 <= 0)
    {
      localRowRange.startIndex = paramInt1;
      localRowRange.endIndex = paramInt1;
      localRowRange.rows = 0;
      localRowRange.height = 0;
      return localRowRange;
    }
    int i;
    int j;
    if ((this.isTree) || (this.hasDifferingHeights))
    {
      i = paramInt1;
      j = 0;
      int k = 0;
      j++;
      k += ((GridItem)this.items.get(i)).getHeight();
      while (k + 2 <= paramInt2)
      {
        int m = i;
        GridItem localGridItem;
        do
        {
          if (!paramBoolean2)
            m++;
          else
            m--;
          if ((m >= 0) && (m < this.items.size()))
            localGridItem = (GridItem)this.items.get(m);
          else
            localGridItem = null;
        }
        while ((localGridItem != null) && (!localGridItem.isVisible()));
        if ((localGridItem == null) || ((paramBoolean1) && (k + 1 + localGridItem.getHeight() > paramInt2)))
          break;
        j++;
        k++;
        k += localGridItem.getHeight();
        i = m;
      }
      localRowRange.startIndex = (!paramBoolean2 ? paramInt1 : i);
      localRowRange.endIndex = (!paramBoolean2 ? i : paramInt1);
      localRowRange.rows = j;
      localRowRange.height = k;
    }
    else
    {
      i = (paramInt2 + 1) / (getItemHeight() + 1);
      if (((getItemHeight() + 1) * localRowRange.rows - 1 + 1 < paramInt2) && (!paramBoolean1))
        i++;
      j = paramInt1 + (i - 1) * (!paramBoolean2 ? 1 : -1);
      if (j < 0)
        j = 0;
      if (j >= this.items.size())
        j = this.items.size() - 1;
      localRowRange.startIndex = (!paramBoolean2 ? paramInt1 : j);
      localRowRange.endIndex = (!paramBoolean2 ? j : paramInt1);
      localRowRange.rows = (localRowRange.endIndex - localRowRange.startIndex + 1);
      localRowRange.height = ((getItemHeight() + 1) * localRowRange.rows - 1);
    }
    return localRowRange;
  }

  int getGridHeight()
  {
    RowRange localRowRange = getRowRange(-1, -1);
    return localRowRange != null ? localRowRange.height : 0;
  }

  int getVisibleGridHeight()
  {
    return getClientArea().height - (this.columnHeadersVisible ? this.headerHeight : 0) - (this.columnFootersVisible ? this.footerHeight : 0);
  }

  int getVisibleGridWidth()
  {
    return getClientArea().width - (this.rowHeaderVisible ? this.rowHeaderWidth : 0);
  }

  public IRenderer getTopLeftRenderer()
  {
    checkWidget();
    return this.topLeftRenderer;
  }

  public IRenderer getBottomLeftRenderer()
  {
    checkWidget();
    return this.bottomLeftRenderer;
  }

  public int indexOf(GridColumn paramGridColumn)
  {
    checkWidget();
    if (paramGridColumn == null)
      SWT.error(4);
    if (paramGridColumn.getParent() != this)
      return -1;
    return this.columns.indexOf(paramGridColumn);
  }

  public int indexOf(GridItem paramGridItem)
  {
    checkWidget();
    if (paramGridItem == null)
      SWT.error(4);
    if (paramGridItem.getParent() != this)
      return -1;
    return this.items.indexOf(paramGridItem);
  }

  public boolean isRowHeaderVisible()
  {
    checkWidget();
    return this.rowHeaderVisible;
  }

  public boolean isSelected(int paramInt)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt >= this.items.size()))
      return false;
    if (!this.cellSelectionEnabled)
      return isSelected((GridItem)this.items.get(paramInt));
    Iterator localIterator = this.selectedCells.iterator();
    while (localIterator.hasNext())
    {
      Point localPoint = (Point)localIterator.next();
      if (localPoint.y == paramInt)
        return true;
    }
    return false;
  }

  public boolean isSelected(GridItem paramGridItem)
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
      return this.selectedItems.contains(paramGridItem);
    int i = indexOf(paramGridItem);
    if (i == -1)
      return false;
    Iterator localIterator = this.selectedCells.iterator();
    while (localIterator.hasNext())
    {
      Point localPoint = (Point)localIterator.next();
      if (localPoint.y == i)
        return true;
    }
    return false;
  }

  public boolean isCellSelected(Point paramPoint)
  {
    checkWidget();
    if (paramPoint == null)
      SWT.error(4);
    return this.selectedCells.contains(paramPoint);
  }

  public void remove(int paramInt)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt > this.items.size() - 1))
      SWT.error(6);
    GridItem localGridItem = (GridItem)this.items.get(paramInt);
    localGridItem.dispose();
    redraw();
  }

  public void remove(int paramInt1, int paramInt2)
  {
    checkWidget();
    for (int i = paramInt2; i >= paramInt1; i--)
    {
      if ((i < 0) || (i > this.items.size() - 1))
        SWT.error(6);
      GridItem localGridItem = (GridItem)this.items.get(i);
      localGridItem.dispose();
    }
    redraw();
  }

  public void remove(int[] paramArrayOfInt)
  {
    checkWidget();
    if (paramArrayOfInt == null)
      SWT.error(4);
    GridItem[] arrayOfGridItem1 = new GridItem[paramArrayOfInt.length];
    int j;
    for (int i = 0; i < paramArrayOfInt.length; i++)
    {
      j = paramArrayOfInt[i];
      if ((j < this.items.size()) && (j >= 0))
        arrayOfGridItem1[i] = ((GridItem)this.items.get(j));
      else
        SWT.error(6);
    }
    for (Object localObject : arrayOfGridItem1)
      localObject.dispose();
    redraw();
  }

  public void removeAll()
  {
    checkWidget();
    while (this.items.size() > 0)
      ((GridItem)this.items.get(0)).dispose();
    redraw();
  }

  public void removeSelectionListener(SelectionListener paramSelectionListener)
  {
    checkWidget();
    removeListener(13, paramSelectionListener);
    removeListener(14, paramSelectionListener);
  }

  public void removeTreeListener(TreeListener paramTreeListener)
  {
    checkWidget();
    removeListener(17, paramTreeListener);
    removeListener(18, paramTreeListener);
  }

  public void select(int paramInt)
  {
    checkWidget();
    if (!this.selectionEnabled)
      return;
    if ((paramInt < 0) || (paramInt >= this.items.size()))
      return;
    GridItem localGridItem = (GridItem)this.items.get(paramInt);
    if (!this.cellSelectionEnabled)
    {
      if ((this.selectionType == 2) && (this.selectedItems.contains(localGridItem)))
        return;
      if (this.selectionType == 4)
        this.selectedItems.clear();
      this.selectedItems.add(localGridItem);
    }
    else
    {
      selectCells(getCells(localGridItem));
    }
    redraw();
  }

  public void select(int paramInt1, int paramInt2)
  {
    checkWidget();
    if (!this.selectionEnabled)
      return;
    if ((this.selectionType == 4) && (paramInt1 != paramInt2))
      return;
    if ((!this.cellSelectionEnabled) && (this.selectionType == 4))
      this.selectedItems.clear();
    for (int i = paramInt1; i <= paramInt2; i++)
      if (i >= 0)
      {
        if (i > this.items.size() - 1)
          break;
        GridItem localGridItem = (GridItem)this.items.get(i);
        if (!this.cellSelectionEnabled)
        {
          if (!this.selectedItems.contains(localGridItem))
            this.selectedItems.add(localGridItem);
        }
        else
          selectCells(getCells(localGridItem));
      }
    redraw();
  }

  public void select(int[] paramArrayOfInt)
  {
    checkWidget();
    if (paramArrayOfInt == null)
      SWT.error(4);
    if (!this.selectionEnabled)
      return;
    if ((this.selectionType == 4) && (paramArrayOfInt.length > 1))
      return;
    if ((!this.cellSelectionEnabled) && (this.selectionType == 4))
      this.selectedItems.clear();
    for (int i : paramArrayOfInt)
      if ((i >= 0) && (i < this.items.size()))
      {
        GridItem localGridItem = (GridItem)this.items.get(i);
        if (!this.cellSelectionEnabled)
        {
          if (!this.selectedItems.contains(localGridItem))
            this.selectedItems.add(localGridItem);
        }
        else
          selectCells(getCells(localGridItem));
      }
    redraw();
  }

  public void selectAll()
  {
    checkWidget();
    if (!this.selectionEnabled)
      return;
    if (this.selectionType == 4)
      return;
    if (this.cellSelectionEnabled)
    {
      selectAllCells();
      return;
    }
    this.selectedItems.clear();
    this.selectedItems.addAll(this.items);
    redraw();
  }

  public void setEmptyCellRenderer(GridCellRenderer paramGridCellRenderer)
  {
    checkWidget();
    paramGridCellRenderer.setDisplay(getDisplay());
    this.emptyCellRenderer = paramGridCellRenderer;
  }

  public void setEmptyColumnHeaderRenderer(IRenderer paramIRenderer)
  {
    checkWidget();
    paramIRenderer.setDisplay(getDisplay());
    this.emptyColumnHeaderRenderer = paramIRenderer;
  }

  public void setEmptyColumnFooterRenderer(IRenderer paramIRenderer)
  {
    checkWidget();
    paramIRenderer.setDisplay(getDisplay());
    this.emptyColumnFooterRenderer = paramIRenderer;
  }

  public void setEmptyRowHeaderRenderer(IRenderer paramIRenderer)
  {
    checkWidget();
    paramIRenderer.setDisplay(getDisplay());
    this.emptyRowHeaderRenderer = paramIRenderer;
  }

  protected void setHorizontalScrollBarProxy(IScrollBarProxy paramIScrollBarProxy)
  {
    checkWidget();
    if (getHorizontalBar() != null)
      return;
    this.hScroll = paramIScrollBarProxy;
    this.hScroll.addSelectionListener(new SelectionListener()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        Grid.this.onScrollSelection();
      }

      public void widgetDefaultSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
      }
    });
  }

  protected void setlVerticalScrollBarProxy(IScrollBarProxy paramIScrollBarProxy)
  {
    checkWidget();
    if (getVerticalBar() != null)
      return;
    this.vScroll = paramIScrollBarProxy;
    this.vScroll.addSelectionListener(new SelectionListener()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        Grid.this.onScrollSelection();
      }

      public void widgetDefaultSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
      }
    });
  }

  public void setFocusRenderer(IRenderer paramIRenderer)
  {
    checkWidget();
    this.focusRenderer = paramIRenderer;
  }

  public void setHeaderVisible(boolean paramBoolean)
  {
    checkWidget();
    this.columnHeadersVisible = paramBoolean;
    redraw();
  }

  public void setFooterVisible(boolean paramBoolean)
  {
    checkWidget();
    this.columnFootersVisible = paramBoolean;
    redraw();
  }

  public void setLineColor(Color paramColor)
  {
    checkWidget();
    this.lineColor = paramColor;
  }

  public void setLinesVisible(boolean paramBoolean)
  {
    checkWidget();
    this.linesVisible = paramBoolean;
    redraw();
  }

  public void setTreeLinesVisible(boolean paramBoolean)
  {
    checkWidget();
    this.treeLinesVisible = paramBoolean;
    redraw();
  }

  public void setRowHeaderRenderer(IRenderer paramIRenderer)
  {
    checkWidget();
    paramIRenderer.setDisplay(getDisplay());
    this.rowHeaderRenderer = paramIRenderer;
  }

  public void setRowHeaderVisible(boolean paramBoolean)
  {
    checkWidget();
    this.rowHeaderVisible = paramBoolean;
    setColumnScrolling(true);
    if (paramBoolean)
    {
      this.rowHeaderWidth = 1;
      Iterator localIterator = this.items.iterator();
      while (localIterator.hasNext())
      {
        GridItem localGridItem = (GridItem)localIterator.next();
        this.rowHeaderWidth = Math.max(this.rowHeaderWidth, this.rowHeaderRenderer.computeSize(this.sizingGC, -1, -1, localGridItem).x);
      }
    }
    redraw();
  }

  public void setSelection(int paramInt)
  {
    checkWidget();
    if (!this.selectionEnabled)
      return;
    if ((paramInt >= 0) && (paramInt < this.items.size()))
      if (!this.cellSelectionEnabled)
      {
        this.selectedItems.clear();
        this.selectedItems.add(this.items.get(paramInt));
        redraw();
      }
      else
      {
        this.selectedCells.clear();
        selectCells(getCells((GridItem)this.items.get(paramInt)));
      }
  }

  public void setSelection(int paramInt1, int paramInt2)
  {
    checkWidget();
    if (!this.selectionEnabled)
      return;
    if ((this.selectionType == 4) && (paramInt1 != paramInt2))
      return;
    if (!this.cellSelectionEnabled)
      this.selectedItems.clear();
    else
      this.selectedCells.clear();
    for (int i = paramInt1; i <= paramInt2; i++)
      if (i >= 0)
      {
        if (i > this.items.size() - 1)
          break;
        GridItem localGridItem = (GridItem)this.items.get(i);
        if (!this.cellSelectionEnabled)
          this.selectedItems.add(localGridItem);
        else
          selectCells(getCells(localGridItem));
      }
    redraw();
  }

  public void setSelection(int[] paramArrayOfInt)
  {
    checkWidget();
    if (!this.selectionEnabled)
      return;
    if ((this.selectionType == 4) && (paramArrayOfInt.length > 1))
      return;
    if (!this.cellSelectionEnabled)
      this.selectedItems.clear();
    else
      this.selectedCells.clear();
    for (int i : paramArrayOfInt)
      if (i >= 0)
      {
        if (i > this.items.size() - 1)
          break;
        GridItem localGridItem = (GridItem)this.items.get(i);
        if (!this.cellSelectionEnabled)
          this.selectedItems.add(localGridItem);
        else
          selectCells(getCells(localGridItem));
      }
    redraw();
  }

  public void setSelection(GridItem[] paramArrayOfGridItem)
  {
    checkWidget();
    if (!this.selectionEnabled)
      return;
    if (paramArrayOfGridItem == null)
      SWT.error(4);
    if ((this.selectionType == 4) && (paramArrayOfGridItem.length > 1))
      return;
    if (!this.cellSelectionEnabled)
      this.selectedItems.clear();
    else
      this.selectedCells.clear();
    for (GridItem localGridItem : paramArrayOfGridItem)
      if (localGridItem != null)
      {
        if (localGridItem.isDisposed())
          SWT.error(5);
        if (localGridItem.getParent() == this)
          if (!this.cellSelectionEnabled)
            this.selectedItems.add(localGridItem);
          else
            selectCells(getCells(localGridItem));
      }
    redraw();
  }

  public void setTopIndex(int paramInt)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt >= this.items.size()))
      return;
    GridItem localGridItem = (GridItem)this.items.get(paramInt);
    if (!localGridItem.isVisible())
      return;
    if (!this.vScroll.getVisible())
      return;
    int i = 0;
    for (int j = 0; j < paramInt; j++)
      if (((GridItem)this.items.get(j)).isVisible())
        i++;
    this.vScroll.setSelection(i);
    this.topIndex = -1;
    this.bottomIndex = -1;
    redraw();
  }

  public void setTopLeftRenderer(IRenderer paramIRenderer)
  {
    checkWidget();
    paramIRenderer.setDisplay(getDisplay());
    this.topLeftRenderer = paramIRenderer;
  }

  public void setBottomLeftRenderer(IRenderer paramIRenderer)
  {
    checkWidget();
    paramIRenderer.setDisplay(getDisplay());
    this.bottomLeftRenderer = paramIRenderer;
  }

  public void showColumn(GridColumn paramGridColumn)
  {
    checkWidget();
    if (!paramGridColumn.isVisible())
    {
      GridColumnGroup localGridColumnGroup = paramGridColumn.getColumnGroup();
      localGridColumnGroup.setExpanded(!localGridColumnGroup.getExpanded());
      if (localGridColumnGroup.getExpanded())
        localGridColumnGroup.notifyListeners(17, new Event());
      else
        localGridColumnGroup.notifyListeners(18, new Event());
    }
    if (!this.hScroll.getVisible())
      return;
    int i = getColumnHeaderXPosition(paramGridColumn);
    int j = 0;
    if (this.rowHeaderVisible)
      j = this.rowHeaderWidth;
    if ((i >= j) && (i + paramGridColumn.getWidth() <= j + getClientArea().width - j))
      return;
    if (!getColumnScrolling())
    {
      if (i < j)
      {
        this.hScroll.setSelection(getHScrollSelectionInPixels() - (j - i));
      }
      else if (paramGridColumn.getWidth() > getClientArea().width - j)
      {
        this.hScroll.setSelection(getHScrollSelectionInPixels() + i - j);
      }
      else
      {
        i -= getClientArea().width - j - paramGridColumn.getWidth();
        this.hScroll.setSelection(getHScrollSelectionInPixels() + i - j);
      }
    }
    else
    {
      int k;
      if ((i < j) || (paramGridColumn.getWidth() > getClientArea().width - j))
      {
        k = this.displayOrderedColumns.indexOf(paramGridColumn);
        this.hScroll.setSelection(k);
      }
      else
      {
        k = getClientArea().width - j - paramGridColumn.getWidth();
        GridColumn localGridColumn1 = getPreviousVisibleColumn(paramGridColumn);
        GridColumn localGridColumn2 = paramGridColumn;
        while (true)
        {
          if ((localGridColumn1 == null) || (localGridColumn1.getWidth() > k))
          {
            int m = this.displayOrderedColumns.indexOf(localGridColumn2);
            this.hScroll.setSelection(m);
            break;
          }
          k -= localGridColumn1.getWidth();
          localGridColumn2 = localGridColumn1;
          localGridColumn1 = getPreviousVisibleColumn(localGridColumn1);
        }
      }
    }
    redraw();
  }

  boolean isShown(GridItem paramGridItem)
  {
    checkWidget();
    if (!paramGridItem.isVisible())
      return false;
    int i = this.items.indexOf(paramGridItem);
    if (i == -1)
      SWT.error(5);
    int j = getTopIndex();
    int k = getBottomIndex();
    return ((i >= j) && (i < k)) || ((i == k) && (this.bottomIndexShownCompletely));
  }

  public void showItem(GridItem paramGridItem)
  {
    checkWidget();
    updateScrollbars();
    if (getVisibleGridHeight() < 1)
      return;
    if (isShown(paramGridItem))
      return;
    if (!paramGridItem.isVisible())
    {
      GridItem localGridItem = paramGridItem.getParentItem();
      do
      {
        if (!localGridItem.isExpanded())
        {
          localGridItem.setExpanded(true);
          localGridItem.fireEvent(17);
        }
        localGridItem = localGridItem.getParentItem();
      }
      while (localGridItem != null);
    }
    int i = this.items.indexOf(paramGridItem);
    if (i >= getBottomIndex())
    {
      RowRange localRowRange = getRowRange(i, getVisibleGridHeight(), true, true);
      i = localRowRange.startIndex;
    }
    setTopIndex(i);
  }

  public void showSelection()
  {
    checkWidget();
    if (this.scrollValuesObsolete)
      updateScrollbars();
    GridItem localGridItem = null;
    if (!this.cellSelectionEnabled)
    {
      if (this.selectedItems.size() == 0)
        return;
      localGridItem = (GridItem)this.selectedItems.get(0);
      showItem(localGridItem);
    }
    else
    {
      if (this.selectedCells.size() == 0)
        return;
      Point localPoint = (Point)this.selectedCells.get(0);
      localGridItem = getItem(localPoint.y);
      showItem(localGridItem);
      GridColumn localGridColumn = getColumn(localPoint.x);
      showColumn(localGridColumn);
    }
  }

  public void setSelectionEnabled(boolean paramBoolean)
  {
    checkWidget();
    if (!paramBoolean)
    {
      this.selectedItems.clear();
      redraw();
    }
    this.selectionEnabled = paramBoolean;
  }

  public boolean getSelectionEnabled()
  {
    checkWidget();
    return this.selectionEnabled;
  }

  private void computeHeaderHeight(GC paramGC)
  {
    int i = 0;
    Iterator localIterator = this.columns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      i = Math.max(localGridColumn.getHeaderRenderer().computeSize(paramGC, localGridColumn.getWidth(), -1, localGridColumn).y, i);
    }
    int j = 0;
    int k = 0;
    for (GridColumnGroup localGridColumnGroup1 : this.columnGroups)
    {
      GridColumnGroup localGridColumnGroup2 = localGridColumnGroup1;
      j = Math.max(localGridColumnGroup2.getHeaderRenderer().computeSize(paramGC, -1, -1, localGridColumnGroup2).y, j);
      int i1 = localGridColumnGroup2.getHeaderGroupCount();
      k = Math.max(k, i1);
    }
    j *= k;
    this.headerHeight = (i + j);
    this.groupHeaderHeight = j;
  }

  private void computeFooterHeight(GC paramGC)
  {
    int i = 0;
    Iterator localIterator = this.columns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      i = Math.max(localGridColumn.getFooterRenderer().computeSize(paramGC, localGridColumn.getWidth(), -1, localGridColumn).y, i);
    }
    this.footerHeight = i;
  }

  private int computeItemHeight(GridItem paramGridItem, GC paramGC)
  {
    int i = 1;
    if ((this.columns.size() == 0) || (this.items.size() == 0))
      return i;
    Iterator localIterator = this.columns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      i = Math.max(i, localGridColumn.getCellRenderer().computeSize(paramGC, -1, -1, paramGridItem).y);
    }
    if ((this.rowHeaderVisible) && (this.rowHeaderRenderer != null))
      i = Math.max(i, this.rowHeaderRenderer.computeSize(paramGC, -1, -1, paramGridItem).y);
    return i <= 0 ? 16 : i;
  }

  private int getColumnHeaderXPosition(GridColumn paramGridColumn)
  {
    if (!paramGridColumn.isVisible())
      return -1;
    int i = 0;
    i -= getHScrollSelectionInPixels();
    if (this.rowHeaderVisible)
      i += this.rowHeaderWidth;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      if (localGridColumn.isVisible())
      {
        if (localGridColumn == paramGridColumn)
          break;
        i += localGridColumn.getWidth();
      }
    }
    return i;
  }

  private int getHScrollSelectionInPixels()
  {
    int i = this.hScroll.getSelection();
    if (this.columnScrolling)
    {
      int j = 0;
      for (int k = 0; k < i; k++)
        j += ((GridColumn)this.displayOrderedColumns.get(k)).getWidth();
      i = j;
    }
    return i;
  }

  private Point getTableSize()
  {
    int i = 0;
    int j = 0;
    if (this.columnHeadersVisible)
      j += this.headerHeight;
    if (this.columnFootersVisible)
      j += this.footerHeight;
    j += getGridHeight();
    if (this.rowHeaderVisible)
      i += this.rowHeaderWidth;
    Iterator localIterator = this.columns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      if (localGridColumn.isVisible())
        i += localGridColumn.getWidth();
    }
    return new Point(i, j);
  }

  private boolean handleColumnDragging(int paramInt)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    int i = 1;
    if (this.rowHeaderVisible)
      i += this.rowHeaderWidth + 1;
    i -= getHScrollSelectionInPixels();
    Object localObject3 = null;
    int j = 0;
    Object localObject4 = null;
    Object localObject5 = null;
    GridColumn localGridColumn;
    if (paramInt < i)
    {
      localObject6 = this.displayOrderedColumns.iterator();
      while (((Iterator)localObject6).hasNext())
      {
        localGridColumn = (GridColumn)((Iterator)localObject6).next();
        if (localGridColumn.isVisible())
        {
          localObject1 = localGridColumn;
          break;
        }
      }
      localObject2 = null;
    }
    else
    {
      localObject6 = this.displayOrderedColumns.iterator();
      while (((Iterator)localObject6).hasNext())
      {
        localGridColumn = (GridColumn)((Iterator)localObject6).next();
        if (localGridColumn.isVisible())
        {
          if (localObject4 == null)
            localObject4 = localGridColumn;
          localObject5 = localGridColumn;
          if (j != 0)
          {
            localObject1 = localGridColumn;
            j = 0;
          }
          if ((paramInt >= i) && (paramInt <= i + localGridColumn.getWidth()))
            if (paramInt <= i + localGridColumn.getWidth() / 2)
            {
              localObject1 = localGridColumn;
              localObject2 = localObject3;
            }
            else
            {
              localObject2 = localGridColumn;
              j = 1;
            }
          i += localGridColumn.getWidth();
          localObject3 = localGridColumn;
        }
      }
      if (localObject1 == null)
        localObject2 = localObject5;
    }
    this.currentHeaderDragX = paramInt;
    if ((localObject1 != this.dragDropBeforeColumn) || ((this.dragDropBeforeColumn == null) && (this.dragDropAfterColumn == null)))
    {
      this.dragDropPointValid = true;
      if (this.columnGroups.length != 0)
      {
        if (this.columnBeingPushed.getColumnGroup() == null)
        {
          if ((localObject1 != null) && (localObject2 != null) && (localObject1.getColumnGroup() != null) && (localObject1.getColumnGroup() == localObject2.getColumnGroup()))
            this.dragDropPointValid = false;
        }
        else if (((localObject1 == null) || (localObject1.getColumnGroup() != this.columnBeingPushed.getColumnGroup())) && ((localObject2 == null) || (localObject2.getColumnGroup() != this.columnBeingPushed.getColumnGroup())))
          this.dragDropPointValid = false;
      }
      else
        this.dragDropPointValid = true;
    }
    this.dragDropBeforeColumn = localObject1;
    this.dragDropAfterColumn = localObject2;
    Object localObject6 = getClientArea();
    redraw(((Rectangle)localObject6).x, ((Rectangle)localObject6).y, ((Rectangle)localObject6).width, ((Rectangle)localObject6).height, false);
    return true;
  }

  private void handleColumnDrop()
  {
    this.draggingColumn = false;
    if ((this.dragDropBeforeColumn != this.columnBeingPushed) && (this.dragDropAfterColumn != this.columnBeingPushed) && ((this.columnGroups.length == 0) || (this.dragDropPointValid)))
    {
      int i = this.displayOrderedColumns.indexOf(this.columnBeingPushed);
      int j = i;
      this.displayOrderedColumns.remove(this.columnBeingPushed);
      if (this.dragDropBeforeColumn == null)
      {
        j = this.displayOrderedColumns.size();
        this.displayOrderedColumns.add(this.columnBeingPushed);
      }
      else if (this.dragDropAfterColumn == null)
      {
        this.displayOrderedColumns.add(0, this.columnBeingPushed);
        i = 0;
      }
      else
      {
        k = 0;
        if (this.columnGroups.length != 0)
        {
          if (this.dragDropBeforeColumn.getColumnGroup() == this.columnBeingPushed.getColumnGroup())
          {
            k = this.displayOrderedColumns.indexOf(this.dragDropBeforeColumn);
          }
          else if (this.dragDropAfterColumn.getColumnGroup() == this.columnBeingPushed.getColumnGroup())
          {
            k = this.displayOrderedColumns.indexOf(this.dragDropAfterColumn) + 1;
          }
          else if (this.dragDropBeforeColumn.getColumnGroup() == null)
          {
            k = this.displayOrderedColumns.indexOf(this.dragDropBeforeColumn);
          }
          else
          {
            GridColumnGroup localGridColumnGroup = this.dragDropBeforeColumn.getColumnGroup();
            k = this.displayOrderedColumns.indexOf(this.dragDropBeforeColumn);
            do
            {
              k--;
              if (k <= 0)
                break;
            }
            while (((GridColumn)this.displayOrderedColumns.get(k - 1)).getColumnGroup() == localGridColumnGroup);
          }
        }
        else
          k = this.displayOrderedColumns.indexOf(this.dragDropBeforeColumn);
        this.displayOrderedColumns.add(k, this.columnBeingPushed);
        i = Math.min(i, k);
        j = Math.max(j, k);
      }
      for (int k = i; k <= j; k++)
        ((GridColumn)this.displayOrderedColumns.get(k)).fireMoved();
    }
    redraw();
  }

  private boolean handleColumnHeaderHoverWhilePushing(int paramInt1, int paramInt2)
  {
    GridColumn localGridColumn = overColumnHeader(paramInt1, paramInt2);
    if ((localGridColumn == this.columnBeingPushed) != this.pushingAndHovering)
    {
      this.pushingAndHovering = (localGridColumn == this.columnBeingPushed);
      redraw();
    }
    if ((this.columnBeingPushed.getMoveable()) && (this.pushingAndHovering) && (Math.abs(this.startHeaderPushX - paramInt1) > 3))
    {
      this.pushingColumn = false;
      this.columnBeingPushed.getHeaderRenderer().setMouseDown(false);
      this.columnBeingPushed.getHeaderRenderer().setHover(false);
      this.draggingColumn = true;
      this.columnBeingPushed.getHeaderRenderer().setMouseDown(false);
      this.startHeaderDragX = paramInt1;
      this.dragDropAfterColumn = null;
      this.dragDropBeforeColumn = null;
      this.dragDropPointValid = true;
      handleColumnDragging(paramInt1);
    }
    return true;
  }

  private boolean handleColumnGroupHeaderClick(int paramInt1, int paramInt2)
  {
    if (!this.columnHeadersVisible)
      return false;
    GridColumnGroup localGridColumnGroup = overColumnGroupHeader(paramInt1, paramInt2);
    if (localGridColumnGroup == null)
      return false;
    int i = 0;
    if (this.rowHeaderVisible)
      i += this.rowHeaderWidth;
    int j = 0;
    int k = 0;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      if ((localGridColumn.getColumnGroup() == localGridColumnGroup) && (localGridColumn.isVisible()))
      {
        k = 1;
        j += localGridColumn.getWidth();
      }
      if ((k == 0) && (localGridColumn.isVisible()))
        i += localGridColumn.getWidth();
    }
    localGridColumnGroup.getHeaderRenderer().setBounds(i - getHScrollSelectionInPixels(), 0, j, this.groupHeaderHeight);
    return localGridColumnGroup.getHeaderRenderer().notify(3, new Point(paramInt1, paramInt2), localGridColumnGroup);
  }

  private boolean handleColumnHeaderPush(int paramInt1, int paramInt2)
  {
    if (!this.columnHeadersVisible)
      return false;
    GridColumn localGridColumn = overColumnHeader(paramInt1, paramInt2);
    if (localGridColumn == null)
      return false;
    if ((this.cellSelectionEnabled) && (!localGridColumn.getMoveable()))
      return false;
    this.columnBeingPushed = localGridColumn;
    this.columnBeingPushed.getHeaderRenderer().setMouseDown(true);
    this.columnBeingPushed.getHeaderRenderer().setHover(true);
    this.pushingAndHovering = true;
    redraw();
    this.startHeaderPushX = paramInt1;
    this.pushingColumn = true;
    setCapture(true);
    return true;
  }

  private boolean handleColumnFooterPush(int paramInt1, int paramInt2)
  {
    if (!this.columnFootersVisible)
      return false;
    GridColumn localGridColumn = overColumnFooter(paramInt1, paramInt2);
    return localGridColumn != null;
  }

  private void handleColumnResizerDragging(int paramInt)
  {
    int i = this.resizingColumnStartWidth + paramInt - this.resizingStartX;
    if (i < 20)
      i = 20;
    if (this.columnScrolling)
    {
      int j = getClientArea().width;
      if (this.rowHeaderVisible)
        j -= this.rowHeaderWidth;
      if (i > j)
        i = j;
    }
    if (i == this.columnBeingResized.getWidth())
      return;
    this.columnBeingResized.setWidth(i, false);
    this.scrollValuesObsolete = true;
    Rectangle localRectangle = getClientArea();
    redraw(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, false);
    this.columnBeingResized.fireResized();
    for (int k = this.displayOrderedColumns.indexOf(this.columnBeingResized) + 1; k < this.displayOrderedColumns.size(); k++)
    {
      GridColumn localGridColumn = (GridColumn)this.displayOrderedColumns.get(k);
      if (localGridColumn.isVisible())
        localGridColumn.fireMoved();
    }
  }

  private void handleRowResizerDragging(int paramInt)
  {
    int i = this.resizingRowStartHeight + paramInt - this.resizingStartY;
    if (i < 10)
      i = 10;
    if (i > getClientArea().height)
      i = getClientArea().height;
    if (i == this.rowBeingResized.getHeight())
      return;
    Event localEvent = new Event();
    localEvent.item = this.rowBeingResized;
    localEvent.widget = this;
    localEvent.detail = i;
    this.rowBeingResized.notifyListeners(11, localEvent);
    if (!localEvent.doit)
      return;
    i = localEvent.detail;
    if (i < 10)
      i = 10;
    if (i > getClientArea().height)
      i = getClientArea().height;
    this.rowBeingResized.setHeight(i);
    this.scrollValuesObsolete = true;
    Rectangle localRectangle = getClientArea();
    redraw(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, false);
  }

  private boolean handleHoverOnColumnResizer(int paramInt1, int paramInt2)
  {
    boolean bool = false;
    if (paramInt2 <= this.headerHeight)
    {
      int i = 0;
      if (this.rowHeaderVisible)
        i += this.rowHeaderWidth;
      i -= getHScrollSelectionInPixels();
      Iterator localIterator = this.displayOrderedColumns.iterator();
      while (localIterator.hasNext())
      {
        GridColumn localGridColumn = (GridColumn)localIterator.next();
        if (localGridColumn.isVisible())
        {
          i += localGridColumn.getWidth();
          if ((i >= paramInt1 - 4) && (i <= paramInt1 + 4))
          {
            if ((!localGridColumn.getResizeable()) || ((localGridColumn.getColumnGroup() != null) && (paramInt2 <= this.groupHeaderHeight) && (localGridColumn != localGridColumn.getColumnGroup().getLastVisibleColumn())))
              break;
            bool = true;
            this.columnBeingResized = localGridColumn;
            break;
          }
        }
      }
    }
    if (bool != this.hoveringOnColumnResizer)
    {
      if (bool)
      {
        setCursor(getDisplay().getSystemCursor(9));
      }
      else
      {
        this.columnBeingResized = null;
        setCursor(null);
      }
      this.hoveringOnColumnResizer = bool;
    }
    return bool;
  }

  private boolean handleHoverOnRowResizer(int paramInt1, int paramInt2)
  {
    this.rowBeingResized = null;
    boolean bool = false;
    if (paramInt1 <= this.rowHeaderWidth)
    {
      int i = 0;
      if (this.columnHeadersVisible)
        i += this.headerHeight;
      for (int j = getTopIndex(); (j < this.items.size()) && (i <= getClientArea().height); j++)
      {
        GridItem localGridItem = (GridItem)this.items.get(j);
        if (localGridItem.isVisible())
        {
          i += localGridItem.getHeight() + 1;
          if ((i >= paramInt2 - 3) && (i <= paramInt2 + 3))
          {
            bool = true;
            this.rowBeingResized = localGridItem;
          }
          else
          {
            if (this.rowBeingResized != null)
              break;
          }
        }
      }
    }
    if (bool != this.hoveringOnRowResizer)
    {
      if (bool)
      {
        setCursor(getDisplay().getSystemCursor(7));
      }
      else
      {
        this.rowBeingResized = null;
        setCursor(null);
      }
      this.hoveringOnRowResizer = bool;
    }
    return bool;
  }

  public Point getCell(Point paramPoint)
  {
    checkWidget();
    if (paramPoint == null)
      SWT.error(4);
    if ((paramPoint.x < 0) || (paramPoint.x > getClientArea().width))
      return null;
    GridItem localGridItem = getItem(paramPoint);
    GridColumn localGridColumn = getColumn(paramPoint);
    if ((localGridItem != null) && (localGridColumn != null))
      return new Point(this.columns.indexOf(localGridColumn), this.items.indexOf(localGridItem));
    return null;
  }

  private void onPaint(PaintEvent paramPaintEvent)
  {
    int i = -1;
    int j = -1;
    int k = -1;
    int m = 0;
    paramPaintEvent.gc.setBackground(getBackground());
    drawBackground(paramPaintEvent.gc, 0, 0, getSize().x, getSize().y);
    if (this.scrollValuesObsolete)
    {
      updateScrollbars();
      this.scrollValuesObsolete = false;
    }
    int n = 0;
    int i1 = 0;
    if (this.columnHeadersVisible)
    {
      paintHeader(paramPaintEvent.gc);
      i1 += this.headerHeight;
    }
    RowRange localRowRange1 = 0;
    int i2 = getClientArea().height - i1;
    int i3 = i2 / getItemHeight() + 1;
    if ((this.items.size() > 0) && (i2 > 0))
    {
      localRowRange2 = getRowRange(getTopIndex(), i2, false, false);
      if (localRowRange2.height >= i2)
        i3 = localRowRange2.rows;
      else
        i3 = localRowRange2.rows + (i2 - localRowRange2.height) / getItemHeight() + 1;
    }
    localRowRange1 = getTopIndex();
    RowRange localRowRange2 = localRowRange1;
    for (int i4 = 0; i4 < i3; i4++)
    {
      n = 0;
      int i5 = getFrozenColumnWidth();
      if (i5 == 0)
        n -= getHScrollSelectionInPixels();
      GridItem localGridItem = null;
      if (localRowRange2 < this.items.size())
        for (localGridItem = (GridItem)this.items.get(localRowRange2); (!localGridItem.isVisible()) && (localRowRange2 < this.items.size() - 1); localGridItem = (GridItem)this.items.get(localRowRange2))
          localRowRange2++;
      if ((localGridItem != null) && (!localGridItem.isVisible()))
        localGridItem = null;
      if (localGridItem != null)
      {
        boolean bool = false;
        if (this.rowHeaderVisible)
          n += this.rowHeaderWidth;
        int i6 = i1;
        int i7 = 0;
        int i8 = 0;
        Iterator localIterator2 = this.displayOrderedColumns.iterator();
        while (localIterator2.hasNext())
        {
          GridColumn localGridColumn2 = (GridColumn)localIterator2.next();
          if (!localGridColumn2.isVisible())
          {
            i8++;
            if (i7 > 0)
              i7--;
          }
          else
          {
            if (i7 == 0)
            {
              i7 = localGridItem.getColumnSpan(indexOf(localGridColumn2));
              int i10 = localGridColumn2.getWidth();
              if (i7 > 0)
                for (int i11 = 0; i11 < i7; i11++)
                {
                  if (getColumnCount() <= i8 + i11 + 1)
                    break;
                  if (((GridColumn)this.displayOrderedColumns.get(i8 + i11 + 1)).isVisible())
                    i10 += ((GridColumn)this.displayOrderedColumns.get(i8 + i11 + 1)).getWidth();
                }
              if ((n + i10 >= 0) && (n < getClientArea().width))
              {
                localGridColumn2.getCellRenderer().setBounds(n, i1, i10, localGridItem.getHeight());
                paramPaintEvent.gc.setClipping(new Rectangle(n - 1, i1 - 1, i10 + 1, localGridItem.getHeight() + 2));
                localGridColumn2.getCellRenderer().setRow(i4 + 1);
                localGridColumn2.getCellRenderer().setSelected(this.selectedItems.contains(localGridItem));
                localGridColumn2.getCellRenderer().setFocus(isFocusControl());
                localGridColumn2.getCellRenderer().setRowFocus(this.focusItem == localGridItem);
                localGridColumn2.getCellRenderer().setCellFocus((this.cellSelectionEnabled) && (this.focusItem == localGridItem) && (this.focusColumn == localGridColumn2));
                localGridColumn2.getCellRenderer().setRowHover(this.hoveringItem == localGridItem);
                localGridColumn2.getCellRenderer().setColumnHover(this.hoveringColumn == localGridColumn2);
                if (this.selectedCells.contains(new Point(indexOf(localGridColumn2), localRowRange2)))
                {
                  localGridColumn2.getCellRenderer().setCellSelected(true);
                  bool = true;
                }
                else
                {
                  localGridColumn2.getCellRenderer().setCellSelected(false);
                }
                if ((this.hoveringItem == localGridItem) && (this.hoveringColumn == localGridColumn2))
                  localGridColumn2.getCellRenderer().setHoverDetail(this.hoveringDetail);
                else
                  localGridColumn2.getCellRenderer().setHoverDetail("");
                localGridColumn2.getCellRenderer().paint(paramPaintEvent.gc, localGridItem);
                paramPaintEvent.gc.setClipping(null);
                if ((m == 0) && (this.insertMarkItem == localGridItem) && ((this.insertMarkColumn == null) || (this.insertMarkColumn == localGridColumn2)))
                {
                  k = i1 - 1;
                  if (!this.insertMarkBefore)
                    k += localGridItem.getHeight() + 1;
                  i = n;
                  if (localGridColumn2.isTree())
                    i += Math.min(i10, localGridColumn2.getCellRenderer().getTextBounds(localGridItem, false).x);
                  if (this.insertMarkColumn == null)
                    j = getClientArea().x + getClientArea().width;
                  else
                    j = n + i10;
                  m = 1;
                }
              }
              n += i10;
            }
            else
            {
              i7--;
            }
            i8++;
          }
        }
        if (n < getClientArea().width)
        {
          if ((m != 0) && (this.insertMarkColumn == null))
            j = n;
          this.emptyCellRenderer.setSelected(this.selectedItems.contains(localGridItem));
          this.emptyCellRenderer.setFocus(isFocusControl());
          this.emptyCellRenderer.setRow(i4 + 1);
          this.emptyCellRenderer.setBounds(n, i1, getClientArea().width - n + 1, localGridItem.getHeight());
          this.emptyCellRenderer.setColumn(getColumnCount());
          this.emptyCellRenderer.paint(paramPaintEvent.gc, localGridItem);
        }
        n = 0;
        if (this.rowHeaderVisible)
        {
          if (!this.cellSelectionEnabled)
            this.rowHeaderRenderer.setSelected(this.selectedItems.contains(localGridItem));
          else
            this.rowHeaderRenderer.setSelected(bool);
          this.rowHeaderRenderer.setBounds(0, i1, this.rowHeaderWidth, localGridItem.getHeight() + 1);
          this.rowHeaderRenderer.paint(paramPaintEvent.gc, localGridItem);
          n += this.rowHeaderWidth;
        }
        if ((isFocusControl()) && (!this.cellSelectionEnabled) && (localGridItem == this.focusItem) && (this.focusRenderer != null))
        {
          int i9 = 0;
          if (this.rowHeaderVisible)
            i9 = this.rowHeaderWidth;
          this.focusRenderer.setBounds(i9, i6 - 1, getClientArea().width - i9 - 1, localGridItem.getHeight() + 1);
          this.focusRenderer.paint(paramPaintEvent.gc, localGridItem);
        }
        i1 += localGridItem.getHeight() + 1;
      }
      else
      {
        if (this.rowHeaderVisible)
          n += this.rowHeaderWidth;
        this.emptyCellRenderer.setBounds(n, i1, getClientArea().width - n, getItemHeight());
        this.emptyCellRenderer.setFocus(false);
        this.emptyCellRenderer.setSelected(false);
        this.emptyCellRenderer.setRow(i4 + 1);
        Iterator localIterator1 = this.displayOrderedColumns.iterator();
        while (localIterator1.hasNext())
        {
          GridColumn localGridColumn1 = (GridColumn)localIterator1.next();
          if (localGridColumn1.isVisible())
          {
            this.emptyCellRenderer.setBounds(n, i1, localGridColumn1.getWidth(), getItemHeight());
            this.emptyCellRenderer.setColumn(indexOf(localGridColumn1));
            this.emptyCellRenderer.paint(paramPaintEvent.gc, this);
            n += localGridColumn1.getWidth();
          }
        }
        if (n < getClientArea().width)
        {
          this.emptyCellRenderer.setBounds(n, i1, getClientArea().width - n + 1, getItemHeight());
          this.emptyCellRenderer.setColumn(getColumnCount());
          this.emptyCellRenderer.paint(paramPaintEvent.gc, this);
        }
        n = 0;
        if (this.rowHeaderVisible)
        {
          this.emptyRowHeaderRenderer.setBounds(n, i1, this.rowHeaderWidth, getItemHeight() + 1);
          this.emptyRowHeaderRenderer.paint(paramPaintEvent.gc, this);
          n += this.rowHeaderWidth;
        }
        i1 += getItemHeight() + 1;
      }
      localRowRange2++;
    }
    if ((this.draggingColumn) && ((this.dragDropAfterColumn != null) || (this.dragDropBeforeColumn != null)) && (this.dragDropAfterColumn != this.columnBeingPushed) && (this.dragDropBeforeColumn != this.columnBeingPushed) && (this.dragDropPointValid))
    {
      if (this.dragDropBeforeColumn != null)
        n = getColumnHeaderXPosition(this.dragDropBeforeColumn);
      else
        n = getColumnHeaderXPosition(this.dragDropAfterColumn) + this.dragDropAfterColumn.getWidth();
      Point localPoint = this.dropPointRenderer.computeSize(paramPaintEvent.gc, -1, -1, null);
      n -= localPoint.x / 2;
      if (n < 0)
        n = 0;
      this.dropPointRenderer.setBounds(n - 1, this.headerHeight + 3, localPoint.x, localPoint.y);
      this.dropPointRenderer.paint(paramPaintEvent.gc, null);
    }
    if (m != 0)
    {
      paramPaintEvent.gc.setClipping(this.rowHeaderVisible ? this.rowHeaderWidth : 0, this.columnHeadersVisible ? this.headerHeight : 0, getClientArea().width, getClientArea().height);
      this.insertMarkRenderer.paint(paramPaintEvent.gc, new Rectangle(i, k, j - i, 0));
    }
    if (this.columnFootersVisible)
      paintFooter(paramPaintEvent.gc);
  }

  private GridColumn overColumnHeader(int paramInt1, int paramInt2)
  {
    GridColumn localGridColumn = null;
    if ((paramInt2 <= this.headerHeight) && (paramInt2 > 0))
    {
      localGridColumn = getColumn(new Point(paramInt1, paramInt2));
      if ((localGridColumn != null) && (localGridColumn.getColumnGroup() != null) && (paramInt2 <= this.groupHeaderHeight))
        return null;
    }
    return localGridColumn;
  }

  private GridColumn overColumnFooter(int paramInt1, int paramInt2)
  {
    GridColumn localGridColumn = null;
    if (paramInt2 >= getClientArea().height - this.footerHeight)
      localGridColumn = getColumn(new Point(paramInt1, paramInt2));
    return localGridColumn;
  }

  private GridColumnGroup overColumnGroupHeader(int paramInt1, int paramInt2)
  {
    GridColumnGroup localGridColumnGroup = null;
    if ((paramInt2 <= this.groupHeaderHeight) && (paramInt2 > 0))
    {
      GridColumn localGridColumn = getColumn(new Point(paramInt1, paramInt2));
      if (localGridColumn != null)
        localGridColumnGroup = localGridColumn.getColumnGroup();
    }
    return localGridColumnGroup;
  }

  private void paintHeader(GC paramGC)
  {
    int i = 0;
    int j = 0;
    if (getFrozenColumnWidth() == 0)
      i -= getHScrollSelectionInPixels();
    if (this.rowHeaderVisible)
      i += this.rowHeaderWidth;
    GridColumnGroup localGridColumnGroup = null;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      if (i > getClientArea().width)
        break;
      GridColumn localGridColumn1 = (GridColumn)localIterator.next();
      int m = 0;
      if (localGridColumn1.isVisible())
      {
        if (localGridColumn1.getColumnGroup() != null)
        {
          if (localGridColumn1.getColumnGroup() != localGridColumnGroup)
          {
            int n = localGridColumn1.getWidth();
            GridColumn localGridColumn2 = null;
            if (this.displayOrderedColumns.indexOf(localGridColumn1) + 1 < this.displayOrderedColumns.size())
              localGridColumn2 = (GridColumn)this.displayOrderedColumns.get(this.displayOrderedColumns.indexOf(localGridColumn1) + 1);
            while ((localGridColumn2 != null) && (localGridColumn2.getColumnGroup() == localGridColumn1.getColumnGroup()))
            {
              if (((!localGridColumn2.getColumnGroup().getExpanded()) || (localGridColumn2.isDetail())) && ((localGridColumn2.getColumnGroup().getExpanded()) || (localGridColumn2.isSummary())))
                n += localGridColumn2.getWidth();
              if (this.displayOrderedColumns.indexOf(localGridColumn2) + 1 < this.displayOrderedColumns.size())
                localGridColumn2 = (GridColumn)this.displayOrderedColumns.get(this.displayOrderedColumns.indexOf(localGridColumn2) + 1);
              else
                localGridColumn2 = null;
            }
            boolean bool = true;
            for (int i1 = 0; i1 < localGridColumn1.getColumnGroup().getColumns().length; i1++)
            {
              GridColumn localGridColumn3 = localGridColumn1.getColumnGroup().getColumns()[i1];
              if ((localGridColumn3.isVisible()) && ((localGridColumn1.getMoveable()) || (!this.selectedColumns.contains(localGridColumn3))))
              {
                bool = false;
                break;
              }
            }
            localGridColumn1.getColumnGroup().getHeaderRenderer().setSelected(bool);
            localGridColumn1.getColumnGroup().getHeaderRenderer().setHover(this.hoverColumnGroupHeader == localGridColumn1.getColumnGroup());
            localGridColumn1.getColumnGroup().getHeaderRenderer().setHoverDetail(this.hoveringDetail);
            localGridColumn1.getColumnGroup().getHeaderRenderer().setBounds(i, 0, n, this.groupHeaderHeight);
            localGridColumn1.getColumnGroup().getHeaderRenderer().paint(paramGC, localGridColumn1.getColumnGroup());
            localGridColumnGroup = localGridColumn1.getColumnGroup();
          }
          m = this.headerHeight - this.groupHeaderHeight;
          j = this.groupHeaderHeight;
        }
        else
        {
          m = this.headerHeight;
          j = 0;
        }
        if (this.pushingColumn)
          localGridColumn1.getHeaderRenderer().setHover((this.columnBeingPushed == localGridColumn1) && (this.pushingAndHovering));
        else
          localGridColumn1.getHeaderRenderer().setHover(this.hoveringColumnHeader == localGridColumn1);
        localGridColumn1.getHeaderRenderer().setHoverDetail(this.hoveringDetail);
        localGridColumn1.getHeaderRenderer().setBounds(i, j, localGridColumn1.getWidth(), m);
        if (this.cellSelectionEnabled)
          localGridColumn1.getHeaderRenderer().setSelected(this.selectedColumns.contains(localGridColumn1));
        if (i >= 0)
          localGridColumn1.getHeaderRenderer().paint(paramGC, localGridColumn1);
        i += localGridColumn1.getWidth();
      }
    }
    if (i < getClientArea().width)
    {
      this.emptyColumnHeaderRenderer.setBounds(i, 0, getClientArea().width - i, this.headerHeight);
      this.emptyColumnHeaderRenderer.paint(paramGC, null);
    }
    i = 0;
    if (this.rowHeaderVisible)
    {
      this.topLeftRenderer.setBounds(0, 0, this.rowHeaderWidth, this.headerHeight);
      this.topLeftRenderer.paint(paramGC, this);
      i += this.rowHeaderWidth;
    }
    if (this.draggingColumn)
    {
      paramGC.setAlpha(128);
      this.columnBeingPushed.getHeaderRenderer().setSelected(false);
      int k = 0;
      if (this.columnBeingPushed.getColumnGroup() != null)
      {
        k = this.headerHeight - this.groupHeaderHeight;
        j = this.groupHeaderHeight;
      }
      else
      {
        k = this.headerHeight;
        j = 0;
      }
      this.columnBeingPushed.getHeaderRenderer().setBounds(getColumnHeaderXPosition(this.columnBeingPushed) + this.currentHeaderDragX - this.startHeaderDragX, j, this.columnBeingPushed.getWidth(), k);
      this.columnBeingPushed.getHeaderRenderer().paint(paramGC, this.columnBeingPushed);
      this.columnBeingPushed.getHeaderRenderer().setSelected(false);
      paramGC.setAlpha(-1);
      paramGC.setAdvanced(false);
    }
  }

  private void paintFooter(GC paramGC)
  {
    int i = 0;
    int j = 0;
    i -= getHScrollSelectionInPixels();
    if (this.rowHeaderVisible)
      i += this.rowHeaderWidth;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      if (i > getClientArea().width)
        break;
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      int k = 0;
      if (localGridColumn.isVisible())
      {
        k = this.footerHeight;
        j = getClientArea().height - k;
        localGridColumn.getFooterRenderer().setBounds(i, j, localGridColumn.getWidth(), k);
        if (i + localGridColumn.getWidth() >= 0)
          localGridColumn.getFooterRenderer().paint(paramGC, localGridColumn);
        i += localGridColumn.getWidth();
      }
    }
    if (i < getClientArea().width)
    {
      this.emptyColumnFooterRenderer.setBounds(i, getClientArea().height - this.footerHeight, getClientArea().width - i, this.footerHeight);
      this.emptyColumnFooterRenderer.paint(paramGC, null);
    }
    if (this.rowHeaderVisible)
    {
      this.bottomLeftRenderer.setBounds(0, getClientArea().height - this.footerHeight, this.rowHeaderWidth, this.footerHeight);
      this.bottomLeftRenderer.paint(paramGC, this);
      i += this.rowHeaderWidth;
    }
  }

  private void updateScrollbars()
  {
    Point localPoint = getTableSize();
    Rectangle localRectangle = getClientArea();
    for (int i = 1; i <= 2; i++)
    {
      if (localPoint.y > localRectangle.height)
      {
        this.vScroll.setVisible(true);
      }
      else
      {
        this.vScroll.setVisible(false);
        this.vScroll.setValues(0, 0, 1, 1, 1, 1);
      }
      if (localPoint.x > localRectangle.width)
      {
        this.hScroll.setVisible(true);
      }
      else
      {
        this.hScroll.setVisible(false);
        this.hScroll.setValues(0, 0, 1, 1, 1, 1);
      }
      localRectangle = getClientArea();
    }
    int j;
    int k;
    if (this.vScroll.getVisible())
    {
      i = this.currentVisibleItems;
      j = 1;
      if (!this.hasDifferingHeights)
      {
        j = (getVisibleGridHeight() + 1) / (getItemHeight() + 1);
      }
      else if (getVisibleGridHeight() >= 1)
      {
        RowRange localRowRange = getRowRange(-1, getVisibleGridHeight(), true, true);
        i -= localRowRange.rows - 1;
      }
      k = Math.min(this.vScroll.getSelection(), i);
      this.vScroll.setValues(k, 0, i, j, 1, j);
    }
    if (this.hScroll.getVisible())
      if (!this.columnScrolling)
      {
        i = localPoint.x - localRectangle.width + 1;
        j = Math.min(this.hScroll.getSelection(), i - 1);
        this.hScroll.setValues(j, 0, i + localRectangle.width - 1, localRectangle.width, 5, localRectangle.width);
      }
      else
      {
        i = localPoint.x - localRectangle.width + 1;
        j = 0;
        k = 0;
        while ((i > 0) && (k < getColumnCount()))
        {
          GridColumn localGridColumn1 = (GridColumn)this.displayOrderedColumns.get(k);
          k++;
          if (localGridColumn1.isVisible())
          {
            i -= localGridColumn1.getWidth();
            j++;
          }
        }
        j++;
        int m = 0;
        Iterator localIterator = this.columns.iterator();
        while (localIterator.hasNext())
        {
          GridColumn localGridColumn2 = (GridColumn)localIterator.next();
          if (localGridColumn2.isVisible())
            m++;
        }
        j = Math.min(m, j);
        int n = Math.min(this.hScroll.getSelection(), j);
        this.hScroll.setValues(n, 0, j, 1, 1, 1);
      }
  }

  private Event updateSelection(GridItem paramGridItem, int paramInt)
  {
    if (!this.selectionEnabled)
      return null;
    Event localEvent = null;
    if (this.selectionType == 4)
    {
      if (this.selectedItems.contains(paramGridItem))
        return null;
      this.selectedItems.clear();
      this.selectedItems.add(paramGridItem);
      Rectangle localRectangle1 = getClientArea();
      redraw(localRectangle1.x, localRectangle1.y, localRectangle1.width, localRectangle1.height, false);
      localEvent = new Event();
      localEvent.item = paramGridItem;
    }
    else if (this.selectionType == 2)
    {
      int i = 0;
      int j = 0;
      if ((paramInt & 0x20000) == 131072)
        i = 1;
      if ((paramInt & 0x40000) == 262144)
        j = 1;
      if ((i == 0) && (j == 0))
      {
        if ((this.selectedItems.size() == 1) && (this.selectedItems.contains(paramGridItem)))
          return null;
        this.selectedItems.clear();
        this.selectedItems.add(paramGridItem);
        Rectangle localRectangle3 = getClientArea();
        redraw(localRectangle3.x, localRectangle3.y, localRectangle3.width, localRectangle3.height, false);
        this.shiftSelectionAnchorItem = null;
        localEvent = new Event();
        localEvent.item = paramGridItem;
      }
      else if (i != 0)
      {
        if (this.shiftSelectionAnchorItem == null)
          this.shiftSelectionAnchorItem = this.focusItem;
        int k = 0;
        if (j == 0)
        {
          if (this.selectedItems.contains(this.shiftSelectionAnchorItem))
            k = 1;
          this.selectedItems.clear();
        }
        int m = this.items.indexOf(this.shiftSelectionAnchorItem);
        int n = this.items.indexOf(paramGridItem);
        int i1 = 0;
        int i2 = 0;
        if (m < n)
        {
          if (k != 0)
            i1 = m;
          else
            i1 = m + 1;
          i2 = n;
        }
        else
        {
          if (k != 0)
            i2 = m;
          else
            i2 = m - 1;
          i1 = n;
        }
        for (int i3 = i1; i3 <= i2; i3++)
          if ((!this.selectedItems.contains(this.items.get(i3))) && (((GridItem)this.items.get(i3)).isVisible()))
            this.selectedItems.add(this.items.get(i3));
        Rectangle localRectangle5 = getClientArea();
        redraw(localRectangle5.x, localRectangle5.y, localRectangle5.width, localRectangle5.height, false);
        localEvent = new Event();
      }
      else if (j != 0)
      {
        if (this.selectedItems.contains(paramGridItem))
          this.selectedItems.remove(paramGridItem);
        else
          this.selectedItems.add(paramGridItem);
        Rectangle localRectangle4 = getClientArea();
        redraw(localRectangle4.x, localRectangle4.y, localRectangle4.width, localRectangle4.height, false);
        this.shiftSelectionAnchorItem = null;
        localEvent = new Event();
        localEvent.item = paramGridItem;
      }
    }
    Rectangle localRectangle2 = getClientArea();
    redraw(localRectangle2.x, localRectangle2.y, localRectangle2.width, localRectangle2.height, false);
    return localEvent;
  }

  private Event updateCellSelection(Point paramPoint, int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    Vector localVector = new Vector();
    localVector.add(paramPoint);
    return updateCellSelection(localVector, paramInt, paramBoolean1, paramBoolean2);
  }

  private Event updateCellSelection(Vector paramVector, int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    int i = 0;
    int j = 0;
    if ((paramInt & 0x20000) == 131072)
    {
      i = 1;
    }
    else
    {
      this.shiftSelectionAnchorColumn = null;
      this.shiftSelectionAnchorItem = null;
    }
    if ((paramInt & 0x40000) == 262144)
      j = 1;
    if ((i == 0) && (j == 0))
    {
      if (paramVector.equals(this.selectedCells))
        return null;
      this.selectedCells.clear();
      for (int k = 0; k < paramVector.size(); k++)
        addToCellSelection((Point)paramVector.get(k));
    }
    else if (i != 0)
    {
      Point localPoint1 = (Point)paramVector.get(0);
      if ((this.focusColumn == null) || (this.focusItem == null))
        return null;
      this.shiftSelectionAnchorColumn = getColumn(localPoint1.x);
      this.shiftSelectionAnchorItem = getItem(localPoint1.y);
      if (j != 0)
      {
        this.selectedCells.clear();
        this.selectedCells.addAll(this.selectedCellsBeforeRangeSelect);
      }
      else
      {
        this.selectedCells.clear();
      }
      Object localObject1 = this.focusColumn;
      Object localObject2 = this.focusItem;
      GridColumn localGridColumn = getColumn(localPoint1.x);
      Object localObject3 = getItem(localPoint1.y);
      Point localPoint2 = getSelectionRange((GridItem)localObject2, (GridColumn)localObject1, (GridItem)localObject3, localGridColumn);
      localObject1 = getColumn(localPoint2.x);
      localGridColumn = getColumn(localPoint2.y);
      Object localObject4 = localObject1;
      if (indexOf((GridItem)localObject2) > indexOf((GridItem)localObject3))
      {
        Object localObject5 = localObject2;
        localObject2 = localObject3;
        localObject3 = localObject5;
      }
      int n = 1;
      do
      {
        if (n == 0)
          localObject2 = getNextVisibleItem((GridItem)localObject2);
        n = 0;
        int i1 = 1;
        localObject1 = localObject4;
        do
        {
          if (i1 == 0)
          {
            int i2 = this.displayOrderedColumns.indexOf(localObject1) + 1;
            if (i2 < this.displayOrderedColumns.size())
              localObject1 = getVisibleColumn_DegradeRight((GridItem)localObject2, (GridColumn)this.displayOrderedColumns.get(i2));
            else
              localObject1 = null;
            if ((localObject1 != null) && (this.displayOrderedColumns.indexOf(localObject1) > this.displayOrderedColumns.indexOf(localGridColumn)))
              localObject1 = null;
          }
          i1 = 0;
          if (localObject1 != null)
          {
            Point localPoint3 = new Point(indexOf((GridColumn)localObject1), indexOf((GridItem)localObject2));
            addToCellSelection(localPoint3);
          }
        }
        while ((localObject1 != localGridColumn) && (localObject1 != null));
      }
      while (localObject2 != localObject3);
    }
    else if (j != 0)
    {
      boolean bool = paramBoolean2;
      if (!this.selectedCells.containsAll(paramVector))
        bool = false;
      if (paramBoolean1)
      {
        this.selectedCells.clear();
        this.selectedCells.addAll(this.selectedCellsBeforeRangeSelect);
      }
      if (bool)
        this.selectedCells.removeAll(paramVector);
      else
        for (int m = 0; m < paramVector.size(); m++)
          addToCellSelection((Point)paramVector.get(m));
    }
    updateColumnSelection();
    Event localEvent = new Event();
    if (paramBoolean1)
    {
      localEvent.detail = 1;
      this.followupCellSelectionEventOwed = true;
    }
    Rectangle localRectangle = getClientArea();
    redraw(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, false);
    return localEvent;
  }

  private void addToCellSelection(Point paramPoint)
  {
    if ((paramPoint.x < 0) || (paramPoint.x >= this.columns.size()))
      return;
    if ((paramPoint.y < 0) || (paramPoint.y >= this.items.size()))
      return;
    if (getColumn(paramPoint.x).getCellSelectionEnabled())
      this.selectedCells.add(paramPoint);
  }

  void updateColumnSelection()
  {
    this.selectedColumns.clear();
    Iterator localIterator = this.selectedCells.iterator();
    while (localIterator.hasNext())
    {
      Point localPoint = (Point)localIterator.next();
      GridColumn localGridColumn = getColumn(localPoint.x);
      this.selectedColumns.add(localGridColumn);
    }
  }

  private void initListeners()
  {
    this.disposeListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        Grid.this.onDispose(paramAnonymousEvent);
      }
    };
    addListener(12, this.disposeListener);
    addPaintListener(new PaintListener()
    {
      public void paintControl(PaintEvent paramAnonymousPaintEvent)
      {
        Grid.this.onPaint(paramAnonymousPaintEvent);
      }
    });
    addListener(11, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        Grid.this.onResize();
      }
    });
    if (getVerticalBar() != null)
      getVerticalBar().addListener(13, new Listener()
      {
        public void handleEvent(Event paramAnonymousEvent)
        {
          Grid.this.onScrollSelection();
        }
      });
    if (getHorizontalBar() != null)
      getHorizontalBar().addListener(13, new Listener()
      {
        public void handleEvent(Event paramAnonymousEvent)
        {
          Grid.this.onScrollSelection();
        }
      });
    addListener(1, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        Grid.this.onKeyDown(paramAnonymousEvent);
      }
    });
    addTraverseListener(new TraverseListener()
    {
      public void keyTraversed(TraverseEvent paramAnonymousTraverseEvent)
      {
        paramAnonymousTraverseEvent.doit = true;
      }
    });
    addMouseListener(new MouseListener()
    {
      public void mouseDoubleClick(MouseEvent paramAnonymousMouseEvent)
      {
        Grid.this.onMouseDoubleClick(paramAnonymousMouseEvent);
      }

      public void mouseDown(MouseEvent paramAnonymousMouseEvent)
      {
        Grid.this.onMouseDown(paramAnonymousMouseEvent);
      }

      public void mouseUp(MouseEvent paramAnonymousMouseEvent)
      {
        Grid.this.onMouseUp(paramAnonymousMouseEvent);
      }
    });
    addMouseMoveListener(new MouseMoveListener()
    {
      public void mouseMove(MouseEvent paramAnonymousMouseEvent)
      {
        Grid.this.onMouseMove(paramAnonymousMouseEvent);
      }
    });
    addMouseTrackListener(new MouseTrackListener()
    {
      public void mouseEnter(MouseEvent paramAnonymousMouseEvent)
      {
      }

      public void mouseExit(MouseEvent paramAnonymousMouseEvent)
      {
        Grid.this.onMouseExit(paramAnonymousMouseEvent);
      }

      public void mouseHover(MouseEvent paramAnonymousMouseEvent)
      {
      }
    });
    addFocusListener(new FocusListener()
    {
      public void focusGained(FocusEvent paramAnonymousFocusEvent)
      {
        Grid.this.onFocusIn();
        Grid.this.redraw();
      }

      public void focusLost(FocusEvent paramAnonymousFocusEvent)
      {
        Grid.this.redraw();
      }
    });
    addListener(37, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        Grid.this.onMouseWheel(paramAnonymousEvent);
      }
    });
  }

  private void onFocusIn()
  {
    if ((!this.items.isEmpty()) && (this.focusItem == null))
      this.focusItem = ((GridItem)this.items.get(0));
  }

  private void onDispose(Event paramEvent)
  {
    removeListener(12, this.disposeListener);
    notifyListeners(12, paramEvent);
    paramEvent.type = 0;
    this.disposing = true;
    this.cellHeaderSelectionBackground.dispose();
    Iterator localIterator = this.items.iterator();
    while (localIterator.hasNext())
    {
      GridItem localGridItem = (GridItem)localIterator.next();
      localGridItem.dispose();
    }
    for (localIterator : this.columnGroups)
      localIterator.dispose();
    localIterator = this.columns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      localGridColumn.dispose();
    }
    this.sizingGC.dispose();
  }

  private void onMouseWheel(Event paramEvent)
  {
    if (this.vScroll.getVisible())
    {
      this.vScroll.handleMouseWheel(paramEvent);
      if (getVerticalBar() == null)
        paramEvent.doit = false;
    }
    else if (this.hScroll.getVisible())
    {
      this.hScroll.handleMouseWheel(paramEvent);
      if (getHorizontalBar() == null)
        paramEvent.doit = false;
    }
  }

  private void onMouseDown(MouseEvent paramMouseEvent)
  {
    if ((getStyle() & 0x80000) != 524288)
      forceFocus();
    hideToolTip();
    Event localEvent = null;
    this.cellSelectedOnLastMouseDown = false;
    this.cellRowSelectedOnLastMouseDown = false;
    this.cellColumnSelectedOnLastMouseDown = false;
    if (this.hoveringOnColumnResizer)
    {
      if (paramMouseEvent.button == 1)
      {
        this.resizingColumn = true;
        this.resizingStartX = paramMouseEvent.x;
        this.resizingColumnStartWidth = this.columnBeingResized.getWidth();
      }
      return;
    }
    if ((this.rowsResizeable) && (this.hoveringOnRowResizer))
    {
      if (paramMouseEvent.button == 1)
      {
        this.resizingRow = true;
        this.resizingStartY = paramMouseEvent.y;
        this.resizingRowStartHeight = this.rowBeingResized.getHeight();
      }
      return;
    }
    if ((paramMouseEvent.button == 1) && (handleColumnHeaderPush(paramMouseEvent.x, paramMouseEvent.y)))
      return;
    if ((paramMouseEvent.button == 1) && (handleColumnGroupHeaderClick(paramMouseEvent.x, paramMouseEvent.y)))
      return;
    if ((paramMouseEvent.button == 1) && (handleColumnFooterPush(paramMouseEvent.x, paramMouseEvent.y)))
      return;
    GridItem localGridItem1 = getItem(new Point(paramMouseEvent.x, paramMouseEvent.y));
    if ((paramMouseEvent.button == 1) && (localGridItem1 != null) && (handleCellClick(localGridItem1, paramMouseEvent.x, paramMouseEvent.y)))
      return;
    if ((isListening(29)) && (((this.cellSelectionEnabled) && (this.hoveringOnSelectionDragArea)) || ((!this.cellSelectionEnabled) && (localGridItem1 != null) && (this.selectedItems.contains(localGridItem1)) && (dragDetect(paramMouseEvent)))))
      return;
    GridColumn localGridColumn;
    if (localGridItem1 != null)
    {
      if (this.cellSelectionEnabled)
      {
        localGridColumn = getColumn(new Point(paramMouseEvent.x, paramMouseEvent.y));
        boolean bool1 = false;
        if (localGridColumn != null)
          bool1 = this.selectedCells.contains(new Point(indexOf(localGridColumn), indexOf(localGridItem1)));
        if ((paramMouseEvent.button == 1) || ((paramMouseEvent.button == 3) && (localGridColumn != null) && (!bool1)))
        {
          if (localGridColumn != null)
          {
            localEvent = updateCellSelection(new Point(indexOf(localGridColumn), indexOf(localGridItem1)), paramMouseEvent.stateMask, false, true);
            this.cellSelectedOnLastMouseDown = (getCellSelectionCount() > 0);
            if (paramMouseEvent.stateMask != 131072)
            {
              this.focusColumn = localGridColumn;
              this.focusItem = localGridItem1;
            }
            showItem(localGridItem1);
            redraw();
          }
          else if ((this.rowHeaderVisible) && (paramMouseEvent.x <= this.rowHeaderWidth))
          {
            boolean bool2 = (paramMouseEvent.stateMask & 0x20000) != 0;
            boolean bool3 = false;
            if (!bool2)
              bool3 = (paramMouseEvent.stateMask & 0x40000) != 0;
            Vector localVector2 = new Vector();
            if (bool2)
              getCells(localGridItem1, this.focusItem, localVector2);
            else
              getCells(localGridItem1, localVector2);
            int i = 0;
            if (bool3)
              i = 262144;
            localEvent = updateCellSelection(localVector2, i, bool2, bool3);
            this.cellRowSelectedOnLastMouseDown = (getCellSelectionCount() > 0);
            if (!bool2)
            {
              this.focusColumn = getColumn(new Point(this.rowHeaderWidth + 1, paramMouseEvent.y));
              this.focusItem = localGridItem1;
            }
            showItem(localGridItem1);
            redraw();
          }
          this.intendedFocusColumn = this.focusColumn;
        }
      }
      else
      {
        if ((paramMouseEvent.button == 2) || (paramMouseEvent.button > 3))
          return;
        if ((paramMouseEvent.button == 3) && (this.selectionType == 2))
        {
          if ((paramMouseEvent.stateMask & 0x20000) == 131072)
            return;
          if ((paramMouseEvent.stateMask & 0x40000) == 262144)
            return;
          if (this.selectedItems.contains(localGridItem1))
            return;
        }
        localEvent = updateSelection(localGridItem1, paramMouseEvent.stateMask);
        this.focusItem = localGridItem1;
        showItem(localGridItem1);
        redraw();
      }
    }
    else if ((this.cellSelectionEnabled) && (paramMouseEvent.button == 1) && (this.rowHeaderVisible) && (paramMouseEvent.x <= this.rowHeaderWidth) && (paramMouseEvent.y < this.headerHeight))
    {
      selectAllCells();
      this.focusColumn = getColumn(new Point(this.rowHeaderWidth + 1, 1));
      this.focusItem = getItem(getTopIndex());
    }
    else if ((this.cellSelectionEnabled) && (paramMouseEvent.button == 1) && (this.columnHeadersVisible) && (paramMouseEvent.y <= this.headerHeight))
    {
      localGridColumn = getColumn(new Point(paramMouseEvent.x, paramMouseEvent.y));
      if (localGridColumn == null)
        return;
      if ((localGridColumn.getColumnGroup() != null) && (paramMouseEvent.y < this.groupHeaderHeight))
        return;
      if (getItemCount() == 0)
        return;
      Vector localVector1 = new Vector();
      getCells(localGridColumn, localVector1);
      localEvent = updateCellSelection(localVector1, paramMouseEvent.stateMask, false, true);
      this.cellColumnSelectedOnLastMouseDown = (getCellSelectionCount() > 0);
      for (GridItem localGridItem2 = getItem(0); (localGridItem2 != null) && (getSpanningColumn(localGridItem2, localGridColumn) != null); localGridItem2 = getNextVisibleItem(localGridItem2));
      if (localGridItem2 != null)
      {
        this.focusColumn = localGridColumn;
        this.focusItem = localGridItem2;
      }
      showColumn(localGridColumn);
      redraw();
    }
    if (localEvent != null)
    {
      localEvent.stateMask = paramMouseEvent.stateMask;
      localEvent.button = paramMouseEvent.button;
      localEvent.x = paramMouseEvent.x;
      localEvent.y = paramMouseEvent.y;
      notifyListeners(13, localEvent);
      if ((!this.cellSelectionEnabled) && (isListening(29)))
        dragDetect(paramMouseEvent);
    }
  }

  private void onMouseDoubleClick(MouseEvent paramMouseEvent)
  {
    if (paramMouseEvent.button == 1)
    {
      if (this.hoveringOnColumnResizer)
      {
        this.columnBeingResized.pack();
        this.columnBeingResized.fireResized();
        for (int i = this.displayOrderedColumns.indexOf(this.columnBeingResized) + 1; i < this.displayOrderedColumns.size(); i++)
        {
          GridColumn localGridColumn = (GridColumn)this.displayOrderedColumns.get(i);
          if (localGridColumn.isVisible())
            localGridColumn.fireMoved();
        }
        this.resizingColumn = false;
        handleHoverOnColumnResizer(paramMouseEvent.x, paramMouseEvent.y);
        return;
      }
      if ((this.rowsResizeable) && (this.hoveringOnRowResizer))
      {
        localObject = Arrays.asList(getSelection());
        if (((List)localObject).contains(this.rowBeingResized))
        {
          for (int j = 0; j < ((List)localObject).size(); j++)
            ((GridItem)((List)localObject).get(j)).pack();
          redraw();
        }
        else
        {
          this.rowBeingResized.pack();
        }
        this.resizingRow = false;
        handleHoverOnRowResizer(paramMouseEvent.x, paramMouseEvent.y);
        return;
      }
      Object localObject = getItem(new Point(paramMouseEvent.x, paramMouseEvent.y));
      if (localObject != null)
        if (isListening(14))
        {
          Event localEvent = new Event();
          localEvent.item = ((Widget)localObject);
          notifyListeners(14, localEvent);
        }
        else if (((GridItem)localObject).getItemCount() > 0)
        {
          ((GridItem)localObject).setExpanded(!((GridItem)localObject).isExpanded());
          if (((GridItem)localObject).isExpanded())
            ((GridItem)localObject).fireEvent(17);
          else
            ((GridItem)localObject).fireEvent(18);
        }
    }
  }

  private void onMouseUp(MouseEvent paramMouseEvent)
  {
    this.cellSelectedOnLastMouseDown = false;
    if (this.resizingColumn)
    {
      this.resizingColumn = false;
      handleHoverOnColumnResizer(paramMouseEvent.x, paramMouseEvent.y);
      return;
    }
    if (this.resizingRow)
    {
      this.resizingRow = false;
      handleHoverOnRowResizer(paramMouseEvent.x, paramMouseEvent.y);
      return;
    }
    if (this.pushingColumn)
    {
      this.pushingColumn = false;
      this.columnBeingPushed.getHeaderRenderer().setMouseDown(false);
      this.columnBeingPushed.getHeaderRenderer().setHover(false);
      redraw();
      if (this.pushingAndHovering)
        this.columnBeingPushed.fireListeners();
      setCapture(false);
      return;
    }
    if (this.draggingColumn)
    {
      handleColumnDrop();
      return;
    }
    if ((this.cellDragSelectionOccuring) || (this.cellRowDragSelectionOccuring) || (this.cellColumnDragSelectionOccuring))
    {
      this.cellDragSelectionOccuring = false;
      this.cellRowDragSelectionOccuring = false;
      this.cellColumnDragSelectionOccuring = false;
      setCursor(null);
      if (this.followupCellSelectionEventOwed)
      {
        Event localEvent = new Event();
        localEvent.button = paramMouseEvent.button;
        localEvent.stateMask = paramMouseEvent.stateMask;
        localEvent.x = paramMouseEvent.x;
        localEvent.y = paramMouseEvent.y;
        notifyListeners(13, localEvent);
        this.followupCellSelectionEventOwed = false;
      }
    }
  }

  private void onMouseMove(MouseEvent paramMouseEvent)
  {
    if ((this.inplaceTooltipCapture) && ((paramMouseEvent.x < 0) || (paramMouseEvent.y < 0) || (paramMouseEvent.x >= getBounds().width) || (paramMouseEvent.y >= getBounds().height)))
    {
      setCapture(false);
      this.inplaceTooltipCapture = false;
      return;
    }
    Event localEvent = null;
    if ((paramMouseEvent.stateMask & 0x80000) == 0)
    {
      handleHovering(paramMouseEvent.x, paramMouseEvent.y);
    }
    else
    {
      if (this.draggingColumn)
      {
        handleColumnDragging(paramMouseEvent.x);
        return;
      }
      if (this.resizingColumn)
      {
        handleColumnResizerDragging(paramMouseEvent.x);
        return;
      }
      if (this.resizingRow)
      {
        handleRowResizerDragging(paramMouseEvent.y);
        return;
      }
      if (this.pushingColumn)
      {
        handleColumnHeaderHoverWhilePushing(paramMouseEvent.x, paramMouseEvent.y);
        return;
      }
      if (this.cellSelectionEnabled)
      {
        if ((!this.cellDragSelectionOccuring) && (this.cellSelectedOnLastMouseDown))
        {
          this.cellDragSelectionOccuring = true;
          setCursor(getDisplay().getSystemCursor(2));
          this.cellDragCTRL = ((paramMouseEvent.stateMask & 0x40000) != 0);
          if (this.cellDragCTRL)
          {
            this.selectedCellsBeforeRangeSelect.clear();
            this.selectedCellsBeforeRangeSelect.addAll(this.selectedCells);
          }
        }
        if ((!this.cellRowDragSelectionOccuring) && (this.cellRowSelectedOnLastMouseDown))
        {
          this.cellRowDragSelectionOccuring = true;
          setCursor(getDisplay().getSystemCursor(2));
          this.cellDragCTRL = ((paramMouseEvent.stateMask & 0x40000) != 0);
          if (this.cellDragCTRL)
          {
            this.selectedCellsBeforeRangeSelect.clear();
            this.selectedCellsBeforeRangeSelect.addAll(this.selectedCells);
          }
        }
        if ((!this.cellColumnDragSelectionOccuring) && (this.cellColumnSelectedOnLastMouseDown))
        {
          this.cellColumnDragSelectionOccuring = true;
          setCursor(getDisplay().getSystemCursor(2));
          this.cellDragCTRL = ((paramMouseEvent.stateMask & 0x40000) != 0);
          if (this.cellDragCTRL)
          {
            this.selectedCellsBeforeRangeSelect.clear();
            this.selectedCellsBeforeRangeSelect.addAll(this.selectedCells);
          }
        }
        int i = this.cellDragCTRL ? 262144 : 0;
        Object localObject1;
        Object localObject2;
        Object localObject3;
        if ((this.cellDragSelectionOccuring) && (handleCellHover(paramMouseEvent.x, paramMouseEvent.y)))
        {
          localObject1 = this.hoveringColumn;
          localObject2 = this.hoveringItem;
          if (this.hoveringItem == null)
            if (paramMouseEvent.y > this.headerHeight)
              localObject2 = getPreviousVisibleItem(null);
            else
              localObject2 = (GridItem)this.items.get(0);
          if (this.hoveringColumn == null)
            if (paramMouseEvent.x > this.rowHeaderWidth)
            {
              localObject1 = getVisibleColumn_DegradeLeft((GridItem)localObject2, (GridColumn)this.displayOrderedColumns.get(this.displayOrderedColumns.size() - 1));
            }
            else
            {
              localObject3 = (GridColumn)this.displayOrderedColumns.get(0);
              if (!((GridColumn)localObject3).isVisible())
                localObject3 = getNextVisibleColumn((GridColumn)localObject3);
              localObject1 = localObject3;
            }
          showColumn((GridColumn)localObject1);
          showItem((GridItem)localObject2);
          localEvent = updateCellSelection(new Point(indexOf((GridColumn)localObject1), indexOf((GridItem)localObject2)), i | 0x20000, true, false);
        }
        if ((this.cellRowDragSelectionOccuring) && (handleCellHover(paramMouseEvent.x, paramMouseEvent.y)))
        {
          localObject1 = this.hoveringItem;
          if (this.hoveringItem == null)
            if (paramMouseEvent.y > this.headerHeight)
              localObject1 = getPreviousVisibleItem(null);
            else if (getTopIndex() > 0)
              localObject1 = getPreviousVisibleItem((GridItem)this.items.get(getTopIndex()));
            else
              localObject1 = (GridItem)this.items.get(0);
          localObject2 = new Vector();
          getCells((GridItem)localObject1, this.focusItem, (Vector)localObject2);
          showItem((GridItem)localObject1);
          localEvent = updateCellSelection((Vector)localObject2, i, true, false);
        }
        if ((this.cellColumnDragSelectionOccuring) && (handleCellHover(paramMouseEvent.x, paramMouseEvent.y)))
        {
          localObject1 = this.hoveringColumn;
          if ((localObject1 != null) || (localObject1 == null))
            return;
          localObject2 = localObject1;
          localObject3 = new Vector();
          int j = this.displayOrderedColumns.indexOf(localObject2) > this.displayOrderedColumns.indexOf(this.focusColumn) ? 1 : 0;
          while (true)
          {
            getCells((GridColumn)localObject2, (Vector)localObject3);
            if (localObject2 == this.focusColumn)
              break;
            if (j != 0)
              localObject2 = getPreviousVisibleColumn((GridColumn)localObject2);
            else
              localObject2 = getNextVisibleColumn((GridColumn)localObject2);
          }
          localEvent = updateCellSelection((Vector)localObject3, i, true, false);
        }
      }
    }
    if (localEvent != null)
    {
      localEvent.stateMask = paramMouseEvent.stateMask;
      localEvent.button = paramMouseEvent.button;
      localEvent.x = paramMouseEvent.x;
      localEvent.y = paramMouseEvent.y;
      notifyListeners(13, localEvent);
    }
  }

  private void handleHovering(int paramInt1, int paramInt2)
  {
    handleCellHover(paramInt1, paramInt2);
    if ((this.cellSelectionEnabled) && (getData("DragSource") != null) && (handleHoverOnSelectionDragArea(paramInt1, paramInt2)))
      return;
    if ((this.columnHeadersVisible) && (handleHoverOnColumnResizer(paramInt1, paramInt2)))
      return;
    if ((this.rowsResizeable) && (this.rowHeaderVisible) && (handleHoverOnRowResizer(paramInt1, paramInt2)));
  }

  protected void refreshHoverState()
  {
    Point localPoint = getDisplay().map(null, this, getDisplay().getCursorLocation());
    handleHovering(localPoint.x, localPoint.y);
  }

  private void onMouseExit(MouseEvent paramMouseEvent)
  {
    this.hoveringItem = null;
    this.hoveringDetail = "";
    this.hoveringColumn = null;
    this.hoveringOverText = false;
    hideToolTip();
    redraw();
  }

  private void onKeyDown(Event paramEvent)
  {
    if (this.focusColumn == null)
    {
      if (this.columns.size() == 0)
        return;
      this.focusColumn = getColumn(0);
      this.intendedFocusColumn = this.focusColumn;
    }
    if ((paramEvent.character == '\r') && (this.focusItem != null))
    {
      Event localEvent1 = new Event();
      localEvent1.item = this.focusItem;
      notifyListeners(14, localEvent1);
      return;
    }
    int i = 0;
    if (((paramEvent.character == '-') || ((!this.cellSelectionEnabled) && (paramEvent.keyCode == 16777219))) && (this.focusItem != null) && (this.focusItem.isExpanded()))
      i = 18;
    else if (((paramEvent.character == '+') || ((!this.cellSelectionEnabled) && (paramEvent.keyCode == 16777220))) && (this.focusItem != null) && (!this.focusItem.isExpanded()))
      i = 17;
    if ((i != 0) && (this.focusItem != null) && (this.focusItem.hasChildren()))
    {
      int j = 0;
      if ((this.cellSelectionEnabled) && (this.focusColumn != null) && (this.focusColumn.isTree()))
        j = i;
      else if (!this.cellSelectionEnabled)
        j = i;
      if (j == 17)
      {
        this.focusItem.setExpanded(true);
        this.focusItem.fireEvent(17);
        return;
      }
      if (j == 18)
      {
        this.focusItem.setExpanded(false);
        this.focusItem.fireEvent(18);
        return;
      }
    }
    if (paramEvent.character == ' ')
      handleSpaceBarDown(paramEvent);
    Object localObject1 = null;
    Object localObject2 = null;
    GridItem localGridItem = this.focusItem;
    GridColumn localGridColumn = this.focusColumn;
    if ((this.cellSelectionEnabled) && (paramEvent.stateMask == 131072) && (this.shiftSelectionAnchorColumn != null))
    {
      localGridItem = this.shiftSelectionAnchorItem;
      localGridColumn = this.shiftSelectionAnchorColumn;
    }
    int k;
    switch (paramEvent.keyCode)
    {
    case 16777220:
      if (this.cellSelectionEnabled)
      {
        if ((localGridItem != null) && (localGridColumn != null))
        {
          localObject1 = localGridItem;
          k = this.displayOrderedColumns.indexOf(localGridColumn);
          int m = localGridItem.getColumnSpan(indexOf(localGridColumn));
          m++;
          while (m > 0)
          {
            k++;
            if (k >= this.displayOrderedColumns.size())
              break;
            if (((GridColumn)this.displayOrderedColumns.get(k)).isVisible())
              m--;
          }
          if (k < this.displayOrderedColumns.size())
            localObject2 = (GridColumn)this.displayOrderedColumns.get(k);
          else
            localObject2 = localGridColumn;
        }
        this.intendedFocusColumn = ((GridColumn)localObject2);
      }
      else if ((localGridItem != null) && (localGridItem.hasChildren()))
      {
        localObject1 = localGridItem.getItem(0);
      }
      break;
    case 16777219:
      if (this.cellSelectionEnabled)
      {
        if ((localGridItem != null) && (localGridColumn != null))
        {
          localObject1 = localGridItem;
          k = this.displayOrderedColumns.indexOf(localGridColumn);
          if (k != 0)
          {
            localObject2 = (GridColumn)this.displayOrderedColumns.get(k - 1);
            localObject2 = getVisibleColumn_DegradeLeft(localGridItem, (GridColumn)localObject2);
          }
          else
          {
            localObject2 = localGridColumn;
          }
        }
        this.intendedFocusColumn = ((GridColumn)localObject2);
      }
      else if ((localGridItem != null) && (localGridItem.getParentItem() != null))
      {
        localObject1 = localGridItem.getParentItem();
      }
      break;
    case 16777217:
      if (localGridItem != null)
        localObject1 = getPreviousVisibleItem(localGridItem);
      if (localGridColumn != null)
        if (localObject1 != null)
          localObject2 = getVisibleColumn_DegradeLeft((GridItem)localObject1, this.intendedFocusColumn);
        else
          localObject2 = localGridColumn;
      break;
    case 16777218:
      if (localGridItem != null)
        localObject1 = getNextVisibleItem(localGridItem);
      else if (this.items.size() > 0)
        localObject1 = (GridItem)this.items.get(0);
      if (localGridColumn != null)
        if (localObject1 != null)
          localObject2 = getVisibleColumn_DegradeLeft((GridItem)localObject1, this.intendedFocusColumn);
        else
          localObject2 = localGridColumn;
      break;
    case 16777223:
      if (!this.cellSelectionEnabled)
      {
        if (this.items.size() > 0)
          localObject1 = (GridItem)this.items.get(0);
      }
      else
      {
        localObject1 = localGridItem;
        localObject2 = getVisibleColumn_DegradeRight((GridItem)localObject1, (GridColumn)this.displayOrderedColumns.get(0));
      }
      break;
    case 16777224:
      if (!this.cellSelectionEnabled)
      {
        if (this.items.size() > 0)
          localObject1 = getPreviousVisibleItem(null);
      }
      else
      {
        localObject1 = localGridItem;
        localObject2 = getVisibleColumn_DegradeLeft((GridItem)localObject1, (GridColumn)this.displayOrderedColumns.get(this.displayOrderedColumns.size() - 1));
      }
      break;
    case 16777221:
      k = getTopIndex();
      localObject1 = (GridItem)this.items.get(k);
      if (this.focusItem == localObject1)
      {
        RowRange localRowRange = getRowRange(getTopIndex(), getVisibleGridHeight(), false, true);
        localObject1 = (GridItem)this.items.get(localRowRange.startIndex);
      }
      localObject2 = this.focusColumn;
      break;
    case 16777222:
      int n = getBottomIndex();
      localObject1 = (GridItem)this.items.get(n);
      Object localObject3;
      if (!isShown((GridItem)localObject1))
      {
        localObject3 = getPreviousVisibleItem((GridItem)localObject1);
        if (localObject3 != null)
          localObject1 = localObject3;
      }
      if (this.focusItem == localObject1)
      {
        localObject3 = getRowRange(getBottomIndex(), getVisibleGridHeight(), true, false);
        localObject1 = (GridItem)this.items.get(((RowRange)localObject3).endIndex);
      }
      localObject2 = this.focusColumn;
      break;
    }
    if (localObject1 == null)
      return;
    Event localEvent2;
    if (this.cellSelectionEnabled)
    {
      if (paramEvent.stateMask != 131072)
        this.focusColumn = ((GridColumn)localObject2);
      showColumn((GridColumn)localObject2);
      if (paramEvent.stateMask != 131072)
        this.focusItem = ((GridItem)localObject1);
      showItem((GridItem)localObject1);
      if (paramEvent.stateMask != 262144)
      {
        localEvent2 = updateCellSelection(new Point(indexOf((GridColumn)localObject2), indexOf((GridItem)localObject1)), paramEvent.stateMask, false, false);
        if (localEvent2 != null)
        {
          localEvent2.stateMask = paramEvent.stateMask;
          localEvent2.character = paramEvent.character;
          localEvent2.keyCode = paramEvent.keyCode;
          notifyListeners(13, localEvent2);
        }
      }
      redraw();
    }
    else
    {
      localEvent2 = null;
      if ((this.selectionType == 4) || (paramEvent.stateMask != 262144))
      {
        localEvent2 = updateSelection((GridItem)localObject1, paramEvent.stateMask);
        if (localEvent2 != null)
        {
          localEvent2.stateMask = paramEvent.stateMask;
          localEvent2.character = paramEvent.character;
          localEvent2.keyCode = paramEvent.keyCode;
        }
      }
      this.focusItem = ((GridItem)localObject1);
      showItem((GridItem)localObject1);
      redraw();
      if (localEvent2 != null)
        notifyListeners(13, localEvent2);
    }
  }

  private void handleSpaceBarDown(Event paramEvent)
  {
    if (this.focusItem == null)
      return;
    if ((this.selectionEnabled) && (!this.cellSelectionEnabled) && (!this.selectedItems.contains(this.focusItem)))
    {
      this.selectedItems.add(this.focusItem);
      redraw();
      Event localEvent = new Event();
      localEvent.item = this.focusItem;
      localEvent.stateMask = paramEvent.stateMask;
      localEvent.character = paramEvent.character;
      localEvent.keyCode = paramEvent.keyCode;
      notifyListeners(13, localEvent);
    }
    if (!this.cellSelectionEnabled)
    {
      int i = 0;
      int j = 1;
      Iterator localIterator = this.columns.iterator();
      while (localIterator.hasNext())
      {
        GridColumn localGridColumn = (GridColumn)localIterator.next();
        if (j != 0)
        {
          if (!localGridColumn.isCheck())
            break;
          j = 0;
          i = 1;
        }
        else if (localGridColumn.isCheck())
        {
          i = 0;
          break;
        }
      }
      if (i != 0)
      {
        this.focusItem.setChecked(!this.focusItem.getChecked());
        redraw();
        this.focusItem.fireCheckEvent(0);
      }
    }
  }

  private void onResize()
  {
    this.scrollValuesObsolete = true;
    this.topIndex = -1;
    this.bottomIndex = -1;
  }

  private void onScrollSelection()
  {
    this.topIndex = -1;
    this.bottomIndex = -1;
    refreshHoverState();
    redraw(getClientArea().x, getClientArea().y, getClientArea().width, getClientArea().height, false);
  }

  Point getOrigin(GridColumn paramGridColumn, GridItem paramGridItem)
  {
    int i = 0;
    if (this.rowHeaderVisible)
      i += this.rowHeaderWidth;
    if (getFrozenColumnWidth() == 0)
      i -= getHScrollSelectionInPixels();
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      if (localGridColumn == paramGridColumn)
        break;
      if (localGridColumn.isVisible())
        i += localGridColumn.getWidth();
    }
    int j = 0;
    if (paramGridItem != null)
    {
      if (this.columnHeadersVisible)
        j += this.headerHeight;
      int k = getTopIndex();
      int m = this.items.indexOf(paramGridItem);
      if (m == -1)
        SWT.error(5);
      while (k != m)
      {
        GridItem localGridItem;
        if (k < m)
        {
          localGridItem = (GridItem)this.items.get(k);
          if (localGridItem.isVisible())
            j += localGridItem.getHeight() + 1;
          k++;
        }
        else if (k > m)
        {
          k--;
          localGridItem = (GridItem)this.items.get(k);
          if (localGridItem.isVisible())
            j -= localGridItem.getHeight() + 1;
        }
      }
    }
    else if (paramGridColumn.getColumnGroup() != null)
    {
      j += this.groupHeaderHeight;
    }
    return new Point(i, j);
  }

  private boolean handleCellClick(GridItem paramGridItem, int paramInt1, int paramInt2)
  {
    GridColumn localGridColumn = getColumn(new Point(paramInt1, paramInt2));
    if (localGridColumn == null)
      return false;
    localGridColumn.getCellRenderer().setBounds(paramGridItem.getBounds(indexOf(localGridColumn)));
    return localGridColumn.getCellRenderer().notify(3, new Point(paramInt1, paramInt2), paramGridItem);
  }

  private boolean handleCellHover(int paramInt1, int paramInt2)
  {
    String str = "";
    boolean bool1 = false;
    GridColumn localGridColumn1 = getColumn(new Point(paramInt1, paramInt2));
    GridItem localGridItem = getItem(new Point(paramInt1, paramInt2));
    GridColumnGroup localGridColumnGroup = null;
    GridColumn localGridColumn2 = null;
    Object localObject;
    if (localGridColumn1 != null)
    {
      Rectangle localRectangle1;
      if (localGridItem != null)
      {
        if (paramInt2 < getClientArea().height - this.footerHeight)
        {
          localGridColumn1.getCellRenderer().setBounds(localGridItem.getBounds(this.columns.indexOf(localGridColumn1)));
          if (localGridColumn1.getCellRenderer().notify(5, new Point(paramInt1, paramInt2), localGridItem))
            str = localGridColumn1.getCellRenderer().getHoverDetail();
          localRectangle1 = localGridColumn1.getCellRenderer().getTextBounds(localGridItem, false);
          if (localRectangle1 != null)
          {
            localObject = new Point(paramInt1 - localGridColumn1.getCellRenderer().getBounds().x, paramInt2 - localGridColumn1.getCellRenderer().getBounds().y);
            bool1 = localRectangle1.contains((Point)localObject);
          }
        }
      }
      else if (paramInt2 < this.headerHeight)
        if ((this.columnGroups.length != 0) && (paramInt2 < this.groupHeaderHeight) && (localGridColumn1.getColumnGroup() != null))
        {
          localGridColumnGroup = localGridColumn1.getColumnGroup();
          localGridColumnGroup.getHeaderRenderer().setBounds(localGridColumnGroup.getBounds());
          if (localGridColumnGroup.getHeaderRenderer().notify(5, new Point(paramInt1, paramInt2), localGridColumnGroup))
            str = localGridColumnGroup.getHeaderRenderer().getHoverDetail();
          localRectangle1 = localGridColumnGroup.getHeaderRenderer().getTextBounds(localGridColumnGroup, false);
          if (localRectangle1 != null)
          {
            localObject = new Point(paramInt1 - localGridColumnGroup.getHeaderRenderer().getBounds().x, paramInt2 - localGridColumnGroup.getHeaderRenderer().getBounds().y);
            bool1 = localRectangle1.contains((Point)localObject);
          }
        }
        else
        {
          localGridColumn2 = localGridColumn1;
          localGridColumn1.getHeaderRenderer().setBounds(localGridColumn1.getBounds());
          if (localGridColumn1.getHeaderRenderer().notify(5, new Point(paramInt1, paramInt2), localGridColumn1))
            str = localGridColumn1.getHeaderRenderer().getHoverDetail();
          localRectangle1 = localGridColumn1.getHeaderRenderer().getTextBounds(localGridColumn1, false);
          if (localRectangle1 != null)
          {
            localObject = new Point(paramInt1 - localGridColumn1.getHeaderRenderer().getBounds().x, paramInt2 - localGridColumn1.getHeaderRenderer().getBounds().y);
            bool1 = localRectangle1.contains((Point)localObject);
          }
        }
    }
    boolean bool2 = false;
    if ((this.hoveringItem != localGridItem) || (!this.hoveringDetail.equals(str)) || (this.hoveringColumn != localGridColumn1) || (localGridColumnGroup != this.hoverColumnGroupHeader) || (localGridColumn2 != this.hoveringColumnHeader))
    {
      this.hoveringItem = localGridItem;
      this.hoveringDetail = str;
      this.hoveringColumn = localGridColumn1;
      this.hoveringColumnHeader = localGridColumn2;
      this.hoverColumnGroupHeader = localGridColumnGroup;
      localObject = getClientArea();
      redraw(((Rectangle)localObject).x, ((Rectangle)localObject).y, ((Rectangle)localObject).width, ((Rectangle)localObject).height, false);
      bool2 = true;
    }
    if ((bool2) || (this.hoveringOverText != bool1))
    {
      this.hoveringOverText = bool1;
      if (bool1)
      {
        localObject = null;
        Rectangle localRectangle2 = null;
        Rectangle localRectangle3 = null;
        if ((this.hoveringItem != null) && (this.hoveringItem.getToolTipText(indexOf(localGridColumn1)) == null) && (!localGridColumn1.getWordWrap()))
        {
          localObject = localGridColumn1.getCellRenderer().getBounds();
          if (((Rectangle)localObject).x + ((Rectangle)localObject).width > getSize().x)
            ((Rectangle)localObject).width = (getSize().x - ((Rectangle)localObject).x);
          localRectangle2 = localGridColumn1.getCellRenderer().getTextBounds(localGridItem, false);
          localRectangle3 = localGridColumn1.getCellRenderer().getTextBounds(localGridItem, true);
        }
        else if (this.hoveringColumnHeader != null)
        {
          localObject = this.hoveringColumnHeader.getHeaderRenderer().getBounds();
          if (((Rectangle)localObject).x + ((Rectangle)localObject).width > getSize().x)
            ((Rectangle)localObject).width = (getSize().x - ((Rectangle)localObject).x);
          localRectangle2 = this.hoveringColumnHeader.getHeaderRenderer().getTextBounds(localGridColumn1, false);
          localRectangle3 = this.hoveringColumnHeader.getHeaderRenderer().getTextBounds(localGridColumn1, true);
        }
        else if (this.hoverColumnGroupHeader != null)
        {
          localObject = this.hoverColumnGroupHeader.getHeaderRenderer().getBounds();
          if (((Rectangle)localObject).x + ((Rectangle)localObject).width > getSize().x)
            ((Rectangle)localObject).width = (getSize().x - ((Rectangle)localObject).x);
          localRectangle2 = this.hoverColumnGroupHeader.getHeaderRenderer().getTextBounds(this.hoverColumnGroupHeader, false);
          localRectangle3 = this.hoverColumnGroupHeader.getHeaderRenderer().getTextBounds(this.hoverColumnGroupHeader, true);
        }
        if ((localRectangle2 != null) && (localRectangle2.width < localRectangle3.width))
        {
          showToolTip(localGridItem, localGridColumn1, this.hoverColumnGroupHeader, new Point(((Rectangle)localObject).x + localRectangle2.x, ((Rectangle)localObject).y + localRectangle2.y));
          setCapture(true);
          this.inplaceTooltipCapture = true;
        }
      }
      else
      {
        hideToolTip();
      }
    }
    if (bool2)
    {
      localObject = null;
      if ((this.hoveringItem == null) || (this.hoveringColumn == null))
      {
        localObject = getToolTipText();
      }
      else
      {
        localObject = this.hoveringItem.getToolTipText(indexOf(this.hoveringColumn));
        if (localObject == null)
          localObject = getToolTipText();
      }
      if ((localObject != null) && (!((String)localObject).equals(this.displayedToolTipText)))
        updateToolTipText((String)localObject);
      else if ((localObject == null) && (this.displayedToolTipText != null))
        updateToolTipText(null);
      this.displayedToolTipText = ((String)localObject);
    }
    return bool2;
  }

  protected void updateToolTipText(String paramString)
  {
    super.setToolTipText(paramString);
  }

  protected void setScrollValuesObsolete()
  {
    this.scrollValuesObsolete = true;
    redraw();
  }

  int newColumn(GridColumn paramGridColumn, int paramInt)
  {
    if (paramInt == -1)
    {
      this.columns.add(paramGridColumn);
      this.displayOrderedColumns.add(paramGridColumn);
    }
    else
    {
      this.columns.add(paramInt, paramGridColumn);
      this.displayOrderedColumns.add(paramInt, paramGridColumn);
      for (int i = 0; i < this.columns.size(); i++)
        ((GridColumn)this.columns.get(i)).setColumnIndex(i);
    }
    computeHeaderHeight(this.sizingGC);
    computeFooterHeight(this.sizingGC);
    updatePrimaryCheckColumn();
    Iterator localIterator = this.items.iterator();
    while (localIterator.hasNext())
    {
      GridItem localGridItem = (GridItem)localIterator.next();
      localGridItem.columnAdded(paramInt);
    }
    this.scrollValuesObsolete = true;
    redraw();
    return this.columns.size() - 1;
  }

  void removeColumn(GridColumn paramGridColumn)
  {
    int i = 0;
    int j = indexOf(paramGridColumn);
    Object localObject3;
    if (this.cellSelectionEnabled)
    {
      localObject1 = new Vector();
      localObject2 = this.selectedCells.iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (Point)((Iterator)localObject2).next();
        if (((Point)localObject3).x == j)
          ((Vector)localObject1).add(localObject3);
      }
      if (((Vector)localObject1).size() > 0)
      {
        this.selectedCells.removeAll((Collection)localObject1);
        i = 1;
      }
      localObject2 = this.selectedCells.iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (Point)((Iterator)localObject2).next();
        if (((Point)localObject3).x >= j)
        {
          localObject3.x -= 1;
          i = 1;
        }
      }
    }
    this.columns.remove(paramGridColumn);
    this.displayOrderedColumns.remove(paramGridColumn);
    updatePrimaryCheckColumn();
    this.scrollValuesObsolete = true;
    redraw();
    Object localObject1 = this.items.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (GridItem)((Iterator)localObject1).next();
      ((GridItem)localObject2).columnRemoved(j);
    }
    int k = 0;
    Object localObject2 = this.columns.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (GridColumn)((Iterator)localObject2).next();
      ((GridColumn)localObject3).setColumnIndex(k);
      k++;
    }
    if ((i != 0) && (!this.disposing))
      updateColumnSelection();
  }

  private void updatePrimaryCheckColumn()
  {
    if ((getStyle() & 0x20) == 32)
    {
      boolean bool = true;
      Iterator localIterator = this.columns.iterator();
      while (localIterator.hasNext())
      {
        GridColumn localGridColumn = (GridColumn)localIterator.next();
        localGridColumn.setTableCheck(bool);
        bool = false;
      }
    }
  }

  void newRootItem(GridItem paramGridItem, int paramInt)
  {
    if ((paramInt == -1) || (paramInt >= this.rootItems.size()))
      this.rootItems.add(paramGridItem);
    else
      this.rootItems.add(paramInt, paramGridItem);
  }

  void removeRootItem(GridItem paramGridItem)
  {
    this.rootItems.remove(paramGridItem);
  }

  int newItem(GridItem paramGridItem, int paramInt, boolean paramBoolean)
  {
    int i = 0;
    if ((!this.isTree) && (paramGridItem.getParentItem() != null))
      this.isTree = true;
    if ((paramBoolean) && (paramInt != -1))
    {
      if (paramInt >= this.rootItems.size())
        paramInt = -1;
      else
        paramInt = this.items.indexOf(this.rootItems.get(paramInt));
    }
    else if (!paramBoolean)
      if ((paramInt >= paramGridItem.getParentItem().getItems().length) || (paramInt == -1))
      {
        for (GridItem localGridItem = paramGridItem.getParentItem(); localGridItem.getItems().length > 0; localGridItem = localGridItem.getItems()[(localGridItem.getItems().length - 1)]);
        paramInt = indexOf(localGridItem) + 1;
      }
      else
      {
        paramInt = indexOf(paramGridItem.getParentItem().getItems()[paramInt]);
      }
    if (paramInt == -1)
    {
      this.items.add(paramGridItem);
      i = this.items.size() - 1;
    }
    else
    {
      this.items.add(paramInt, paramGridItem);
      i = paramInt;
    }
    if ((this.items.size() == 1) && (!this.userModifiedItemHeight))
      this.itemHeight = computeItemHeight(paramGridItem, this.sizingGC);
    paramGridItem.initializeHeight(this.itemHeight);
    if (isRowHeaderVisible())
      this.rowHeaderWidth = Math.max(this.rowHeaderWidth, this.rowHeaderRenderer.computeSize(this.sizingGC, -1, -1, paramGridItem).x);
    this.scrollValuesObsolete = true;
    this.topIndex = -1;
    this.bottomIndex = -1;
    this.currentVisibleItems += 1;
    redraw();
    return i;
  }

  void removeItem(GridItem paramGridItem)
  {
    Point[] arrayOfPoint1 = getCells(paramGridItem);
    int i = 0;
    this.items.remove(paramGridItem);
    if (this.disposing)
      return;
    if (this.selectedItems.remove(paramGridItem))
      i = 1;
    for (Point localPoint : arrayOfPoint1)
      if (this.selectedCells.remove(localPoint))
        i = 1;
    if (this.focusItem == paramGridItem)
      this.focusItem = null;
    this.scrollValuesObsolete = true;
    this.topIndex = -1;
    this.bottomIndex = -1;
    if (paramGridItem.isVisible())
      this.currentVisibleItems -= 1;
    if ((i != 0) && (!this.disposing))
      updateColumnSelection();
    redraw();
  }

  void newColumnGroup(GridColumnGroup paramGridColumnGroup)
  {
    GridColumnGroup[] arrayOfGridColumnGroup = new GridColumnGroup[this.columnGroups.length + 1];
    System.arraycopy(this.columnGroups, 0, arrayOfGridColumnGroup, 0, this.columnGroups.length);
    arrayOfGridColumnGroup[(arrayOfGridColumnGroup.length - 1)] = paramGridColumnGroup;
    this.columnGroups = arrayOfGridColumnGroup;
    if (this.columnGroups.length > 0)
      computeHeaderHeight(this.sizingGC);
    this.scrollValuesObsolete = true;
    redraw();
  }

  void removeColumnGroup(GridColumnGroup paramGridColumnGroup)
  {
    GridColumnGroup[] arrayOfGridColumnGroup1 = new GridColumnGroup[this.columnGroups.length - 1];
    int i = 0;
    for (GridColumnGroup localGridColumnGroup : this.columnGroups)
      if (localGridColumnGroup != paramGridColumnGroup)
      {
        arrayOfGridColumnGroup1[i] = localGridColumnGroup;
        i++;
      }
    this.columnGroups = arrayOfGridColumnGroup1;
    if (this.columnGroups.length == 0)
      computeHeaderHeight(this.sizingGC);
    this.scrollValuesObsolete = true;
    redraw();
  }

  void updateVisibleItems(int paramInt)
  {
    this.currentVisibleItems += paramInt;
  }

  public GridItem getFocusItem()
  {
    checkWidget();
    return this.focusItem;
  }

  public Point getFocusCell()
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
      return null;
    int i = -1;
    int j = -1;
    if (this.focusColumn != null)
      i = indexOf(this.focusColumn);
    if (this.focusItem != null)
      j = indexOf(this.focusItem);
    return new Point(i, j);
  }

  public void setFocusItem(GridItem paramGridItem)
  {
    checkWidget();
    if ((paramGridItem == null) || (paramGridItem.isDisposed()) || (paramGridItem.getParent() != this))
      SWT.error(5);
    this.focusItem = paramGridItem;
  }

  public void setFocusColumn(GridColumn paramGridColumn)
  {
    checkWidget();
    if ((paramGridColumn == null) || (paramGridColumn.isDisposed()) || (paramGridColumn.getParent() != this) || (!paramGridColumn.isVisible()))
      SWT.error(5);
    this.focusColumn = paramGridColumn;
    this.intendedFocusColumn = paramGridColumn;
  }

  GridColumn[] getColumnsInOrder()
  {
    checkWidget();
    return (GridColumn[])this.displayOrderedColumns.toArray(new GridColumn[this.columns.size()]);
  }

  public boolean getColumnScrolling()
  {
    checkWidget();
    return this.columnScrolling;
  }

  public void setColumnScrolling(boolean paramBoolean)
  {
    checkWidget();
    if ((this.rowHeaderVisible) && (!paramBoolean))
      return;
    this.columnScrolling = paramBoolean;
    this.scrollValuesObsolete = true;
    redraw();
  }

  private GridColumn getVisibleColumn_DegradeLeft(GridItem paramGridItem, GridColumn paramGridColumn)
  {
    int i = this.displayOrderedColumns.indexOf(paramGridColumn);
    Object localObject = paramGridColumn;
    int j = 0;
    while (!((GridColumn)localObject).isVisible())
    {
      j++;
      if (i - j < 0)
        return null;
      localObject = (GridColumn)this.displayOrderedColumns.get(i - j);
    }
    i = this.displayOrderedColumns.indexOf(localObject);
    for (int k = 0; k < i; k++)
    {
      GridColumn localGridColumn = (GridColumn)this.displayOrderedColumns.get(k);
      if ((localGridColumn.isVisible()) && (paramGridItem.getColumnSpan(indexOf(localGridColumn)) >= i - k))
      {
        localObject = localGridColumn;
        break;
      }
    }
    return localObject;
  }

  private GridColumn getVisibleColumn_DegradeRight(GridItem paramGridItem, GridColumn paramGridColumn)
  {
    int i = this.displayOrderedColumns.indexOf(paramGridColumn);
    int j = 0;
    for (GridColumn localGridColumn1 = paramGridColumn; !localGridColumn1.isVisible(); localGridColumn1 = (GridColumn)this.displayOrderedColumns.get(i + j))
    {
      j++;
      if (i + j == this.displayOrderedColumns.size())
        return null;
    }
    i = this.displayOrderedColumns.indexOf(localGridColumn1);
    int k = i;
    while (i > 0)
    {
      i--;
      GridColumn localGridColumn2 = (GridColumn)this.displayOrderedColumns.get(i);
      if (paramGridItem.getColumnSpan(indexOf(localGridColumn2)) >= k - i)
      {
        if (k == this.displayOrderedColumns.size() - 1)
          return null;
        return getVisibleColumn_DegradeRight(paramGridItem, (GridColumn)this.displayOrderedColumns.get(k + 1));
      }
    }
    return localGridColumn1;
  }

  public boolean getCellSelectionEnabled()
  {
    checkWidget();
    return this.cellSelectionEnabled;
  }

  public void setCellSelectionEnabled(boolean paramBoolean)
  {
    checkWidget();
    if (!paramBoolean)
    {
      this.selectedCells.clear();
      redraw();
    }
    else
    {
      this.selectedItems.clear();
      redraw();
    }
    this.cellSelectionEnabled = paramBoolean;
  }

  public boolean isCellSelectionEnabled()
  {
    return this.cellSelectionEnabled;
  }

  public void deselectCell(Point paramPoint)
  {
    checkWidget();
    if (paramPoint == null)
      SWT.error(4);
    this.selectedCells.remove(paramPoint);
    updateColumnSelection();
    redraw();
  }

  public void deselectCells(Point[] paramArrayOfPoint)
  {
    checkWidget();
    if (paramArrayOfPoint == null)
      SWT.error(4);
    Point localPoint;
    for (localPoint : paramArrayOfPoint)
      if (localPoint == null)
        SWT.error(4);
    for (localPoint : paramArrayOfPoint)
      this.selectedCells.remove(localPoint);
    updateColumnSelection();
    redraw();
  }

  public void deselectAllCells()
  {
    checkWidget();
    this.selectedCells.clear();
    updateColumnSelection();
    redraw();
  }

  public void selectCell(Point paramPoint)
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
      return;
    if (paramPoint == null)
      SWT.error(4);
    addToCellSelection(paramPoint);
    updateColumnSelection();
    redraw();
  }

  public void selectCells(Point[] paramArrayOfPoint)
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
      return;
    if (paramArrayOfPoint == null)
      SWT.error(4);
    Point localPoint;
    for (localPoint : paramArrayOfPoint)
      if (localPoint == null)
        SWT.error(4);
    for (localPoint : paramArrayOfPoint)
      addToCellSelection(localPoint);
    updateColumnSelection();
    redraw();
  }

  public void selectAllCells()
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
      return;
    if (this.columns.size() == 0)
      return;
    int i = 0;
    for (GridColumn localGridColumn1 = (GridColumn)this.displayOrderedColumns.get(i); !localGridColumn1.isVisible(); localGridColumn1 = (GridColumn)this.displayOrderedColumns.get(i))
    {
      i++;
      if (i >= this.columns.size())
        return;
    }
    GridColumn localGridColumn2 = this.focusColumn;
    GridItem localGridItem1 = this.focusItem;
    this.focusColumn = localGridColumn1;
    this.focusItem = ((GridItem)this.items.get(0));
    GridItem localGridItem2 = getPreviousVisibleItem(null);
    GridColumn localGridColumn3 = getVisibleColumn_DegradeLeft(localGridItem2, (GridColumn)this.displayOrderedColumns.get(this.displayOrderedColumns.size() - 1));
    updateCellSelection(new Point(indexOf(localGridColumn3), indexOf(localGridItem2)), 131072, true, false);
    this.focusColumn = localGridColumn2;
    this.focusItem = localGridItem1;
    updateColumnSelection();
    redraw();
  }

  public void setCellSelection(Point paramPoint)
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
      return;
    if (paramPoint == null)
      SWT.error(4);
    if (!isValidCell(paramPoint))
      SWT.error(5);
    this.selectedCells.clear();
    addToCellSelection(paramPoint);
    updateColumnSelection();
    redraw();
  }

  public void setCellSelection(Point[] paramArrayOfPoint)
  {
    checkWidget();
    if (!this.cellSelectionEnabled)
      return;
    if (paramArrayOfPoint == null)
      SWT.error(4);
    for (int i = 0; i < paramArrayOfPoint.length; i++)
    {
      if (paramArrayOfPoint[i] == null)
        SWT.error(4);
      if (!isValidCell(paramArrayOfPoint[i]))
        SWT.error(5);
    }
    this.selectedCells.clear();
    for (Point localPoint : paramArrayOfPoint)
      addToCellSelection(localPoint);
    updateColumnSelection();
    redraw();
  }

  public Point[] getCellSelection()
  {
    checkWidget();
    return (Point[])this.selectedCells.toArray(new Point[this.selectedCells.size()]);
  }

  GridColumn getFocusColumn()
  {
    return this.focusColumn;
  }

  void updateColumnFocus()
  {
    if (!this.focusColumn.isVisible())
    {
      int i = this.displayOrderedColumns.indexOf(this.focusColumn);
      if (i > 0)
      {
        GridColumn localGridColumn = (GridColumn)this.displayOrderedColumns.get(i - 1);
        localGridColumn = getVisibleColumn_DegradeLeft(this.focusItem, localGridColumn);
        if (localGridColumn == null)
          localGridColumn = getVisibleColumn_DegradeRight(this.focusItem, this.focusColumn);
        this.focusColumn = localGridColumn;
      }
      else
      {
        this.focusColumn = getVisibleColumn_DegradeRight(this.focusItem, this.focusColumn);
      }
    }
  }

  private void getCells(GridColumn paramGridColumn, Vector paramVector)
  {
    int i = indexOf(paramGridColumn);
    int j = 0;
    Object localObject = this.displayOrderedColumns.iterator();
    while (((Iterator)localObject).hasNext())
    {
      GridColumn localGridColumn1 = (GridColumn)((Iterator)localObject).next();
      if (localGridColumn1.isVisible())
      {
        if (localGridColumn1 == paramGridColumn)
          break;
        j++;
      }
    }
    localObject = null;
    if (getItemCount() > 0);
    for (localObject = getItem(0); localObject != null; localObject = getNextVisibleItem((GridItem)localObject))
    {
      int k = -1;
      int m = 0;
      Iterator localIterator = this.displayOrderedColumns.iterator();
      GridColumn localGridColumn2;
      while (localIterator.hasNext())
      {
        localGridColumn2 = (GridColumn)localIterator.next();
        if (localGridColumn2.isVisible())
        {
          if (localGridColumn2 == paramGridColumn)
            break;
          int n = ((GridItem)localObject).getColumnSpan(indexOf(localGridColumn2));
          if (k + n >= j)
          {
            m = 1;
            break;
          }
        }
      }
      if ((m == 0) && (((GridItem)localObject).getColumnSpan(i) == 0))
        paramVector.add(new Point(i, indexOf((GridItem)localObject)));
    }
  }

  private void getCells(GridItem paramGridItem, Vector paramVector)
  {
    int i = indexOf(paramGridItem);
    int j = 0;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      if (j > 0)
      {
        j--;
      }
      else if (localGridColumn.isVisible())
      {
        j = paramGridItem.getColumnSpan(indexOf(localGridColumn));
        paramVector.add(new Point(indexOf(localGridColumn), i));
      }
    }
  }

  private Point[] getCells(GridItem paramGridItem)
  {
    Vector localVector = new Vector();
    int i = indexOf(paramGridItem);
    int j = 0;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      if (j > 0)
      {
        j--;
      }
      else if (localGridColumn.isVisible())
      {
        j = paramGridItem.getColumnSpan(indexOf(localGridColumn));
        localVector.add(new Point(indexOf(localGridColumn), i));
      }
    }
    return (Point[])localVector.toArray(new Point[0]);
  }

  private void getCells(GridItem paramGridItem1, GridItem paramGridItem2, Vector paramVector)
  {
    int i = indexOf(paramGridItem1) < indexOf(paramGridItem2) ? 1 : 0;
    GridItem localGridItem = paramGridItem2;
    while (true)
    {
      getCells(localGridItem, paramVector);
      if (localGridItem == paramGridItem1)
        break;
      if (i != 0)
        localGridItem = getPreviousVisibleItem(localGridItem);
      else
        localGridItem = getNextVisibleItem(localGridItem);
    }
  }

  private int blend(int paramInt1, int paramInt2, int paramInt3)
  {
    return (paramInt3 * paramInt1 + (100 - paramInt3) * paramInt2) / 100;
  }

  private RGB blend(RGB paramRGB1, RGB paramRGB2, int paramInt)
  {
    int i = blend(paramRGB1.red, paramRGB2.red, paramInt);
    int j = blend(paramRGB1.green, paramRGB2.green, paramInt);
    int k = blend(paramRGB1.blue, paramRGB2.blue, paramInt);
    return new RGB(i, j, k);
  }

  private Point getSelectionRange(GridItem paramGridItem1, GridColumn paramGridColumn1, GridItem paramGridItem2, GridColumn paramGridColumn2)
  {
    Object localObject;
    if (this.displayOrderedColumns.indexOf(paramGridColumn1) > this.displayOrderedColumns.indexOf(paramGridColumn2))
    {
      localObject = paramGridColumn1;
      paramGridColumn1 = paramGridColumn2;
      paramGridColumn2 = (GridColumn)localObject;
    }
    if (indexOf(paramGridItem1) > indexOf(paramGridItem2))
    {
      localObject = paramGridItem1;
      paramGridItem1 = paramGridItem2;
      paramGridItem2 = (GridItem)localObject;
    }
    int i = 1;
    GridItem localGridItem = paramGridItem1;
    int j = indexOf(paramGridColumn1);
    int k = indexOf(paramGridColumn2);
    do
    {
      if (i == 0)
        localGridItem = getNextVisibleItem(localGridItem);
      else
        i = 0;
      Point localPoint = getRowSelectionRange(localGridItem, paramGridColumn1, paramGridColumn2);
      if ((localPoint.x != j) || (localPoint.y != k))
      {
        GridColumn localGridColumn1 = getColumn(localPoint.x);
        GridColumn localGridColumn2 = getColumn(localPoint.y);
        return getSelectionRange(paramGridItem1, localGridColumn1, paramGridItem2, localGridColumn2);
      }
    }
    while (localGridItem != paramGridItem2);
    return new Point(indexOf(paramGridColumn1), indexOf(paramGridColumn2));
  }

  private Point getRowSelectionRange(GridItem paramGridItem, GridColumn paramGridColumn1, GridColumn paramGridColumn2)
  {
    int i = indexOf(paramGridColumn1);
    int j = indexOf(paramGridColumn2);
    int k = 0;
    int m = -1;
    int n = 0;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      if (!localGridColumn.isVisible())
      {
        if (k > 0)
          k--;
      }
      else
      {
        if (k > 0)
        {
          if (localGridColumn == paramGridColumn1)
            i = m;
          else if ((localGridColumn == paramGridColumn2) && (k > 1))
            n = 1;
          k--;
          if ((n != 0) && (k == 0))
          {
            j = indexOf(localGridColumn);
            break;
          }
        }
        else
        {
          int i1 = indexOf(localGridColumn);
          k = paramGridItem.getColumnSpan(i1);
          if (k > 0)
            m = i1;
          if ((localGridColumn == paramGridColumn2) && (k > 0))
            n = 1;
        }
        if ((localGridColumn == paramGridColumn2) && (n == 0))
          break;
      }
    }
    return new Point(i, j);
  }

  private GridColumn getSpanningColumn(GridItem paramGridItem, GridColumn paramGridColumn)
  {
    int i = 0;
    Object localObject = null;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      if (localGridColumn == paramGridColumn)
        return localObject;
      if (i > 0)
      {
        i--;
        if (i == 0)
          localObject = null;
      }
      else
      {
        int j = indexOf(localGridColumn);
        i = paramGridItem.getColumnSpan(j);
        if (i > 0)
          localObject = localGridColumn;
      }
    }
    return localObject;
  }

  private boolean isValidCell(Point paramPoint)
  {
    if ((paramPoint.x < 0) || (paramPoint.x >= this.columns.size()))
      return false;
    return (paramPoint.y >= 0) && (paramPoint.y < this.items.size());
  }

  protected void showToolTip(GridItem paramGridItem, GridColumn paramGridColumn, GridColumnGroup paramGridColumnGroup, Point paramPoint)
  {
    if (this.inplaceToolTip == null)
      this.inplaceToolTip = new GridToolTip(this);
    if (paramGridColumnGroup != null)
    {
      this.inplaceToolTip.setFont(getFont());
      this.inplaceToolTip.setText(paramGridColumnGroup.getText());
    }
    else if (paramGridItem != null)
    {
      this.inplaceToolTip.setFont(paramGridItem.getFont(paramGridItem.getParent().indexOf(paramGridColumn)));
      this.inplaceToolTip.setText(paramGridItem.getText(paramGridItem.getParent().indexOf(paramGridColumn)));
    }
    else if (paramGridColumn != null)
    {
      this.inplaceToolTip.setFont(getFont());
      this.inplaceToolTip.setText(paramGridColumn.getText());
    }
    Point localPoint = getDisplay().map(this, null, paramPoint);
    this.inplaceToolTip.setLocation(localPoint);
    this.inplaceToolTip.setVisible(true);
  }

  protected void hideToolTip()
  {
    if (this.inplaceToolTip != null)
      this.inplaceToolTip.setVisible(false);
    if (this.inplaceTooltipCapture)
    {
      setCapture(false);
      this.inplaceTooltipCapture = false;
    }
  }

  void recalculateRowHeaderHeight(GridItem paramGridItem, int paramInt1, int paramInt2)
  {
    checkWidget();
    if (paramInt2 > this.itemHeight)
    {
      this.itemHeight = paramInt2;
      this.userModifiedItemHeight = false;
      this.hasDifferingHeights = false;
      this.itemHeight = computeItemHeight((GridItem)this.items.get(0), this.sizingGC);
      for (int i = 0; i < this.items.size(); i++)
        ((GridItem)this.items.get(i)).setHeight(this.itemHeight);
      setScrollValuesObsolete();
      redraw();
    }
  }

  void recalculateRowHeaderWidth(GridItem paramGridItem, int paramInt1, int paramInt2)
  {
    if (paramInt2 > this.rowHeaderWidth)
    {
      this.rowHeaderWidth = paramInt2;
    }
    else if ((paramInt2 < this.rowHeaderWidth) && (paramInt1 == this.rowHeaderWidth))
    {
      Iterator localIterator = this.items.iterator();
      while (localIterator.hasNext())
      {
        GridItem localGridItem = (GridItem)localIterator.next();
        paramInt2 = Math.max(paramInt2, this.rowHeaderRenderer.computeSize(this.sizingGC, -1, -1, localGridItem).x);
      }
      this.rowHeaderWidth = paramInt2;
    }
    redraw();
  }

  public void setFont(Font paramFont)
  {
    super.setFont(paramFont);
    this.sizingGC.setFont(paramFont);
  }

  public int getItemHeaderWidth()
  {
    checkWidget();
    if (!this.rowHeaderVisible)
      return 0;
    return this.rowHeaderWidth;
  }

  public void setItemCount(int paramInt)
  {
    checkWidget();
    setRedraw(false);
    if (paramInt < 0)
      paramInt = 0;
    this.items.size();
    while (paramInt > this.items.size())
      new GridItem(this, 0);
    setRedraw(true);
  }

  private void initAccessible()
  {
    final Accessible localAccessible = getAccessible();
    localAccessible.addAccessibleListener(new AccessibleAdapter()
    {
      public void getDescription(AccessibleEvent paramAnonymousAccessibleEvent)
      {
        int i = paramAnonymousAccessibleEvent.childID;
        if ((i >= 0) && (i < Grid.this.items.size()))
        {
          String str = "";
          for (int j = 0; j < Grid.this.columns.size(); j++)
            if (j != 0)
            {
              str = str + ((GridColumn)Grid.this.columns.get(j)).getText() + " : ";
              str = str + ((GridItem)Grid.this.items.get(i)).getText(j) + " ";
            }
          paramAnonymousAccessibleEvent.result = str;
        }
      }

      public void getName(AccessibleEvent paramAnonymousAccessibleEvent)
      {
        int i = paramAnonymousAccessibleEvent.childID;
        if ((i >= 0) && (i < Grid.this.items.size()))
          paramAnonymousAccessibleEvent.result = ((GridItem)Grid.this.items.get(i)).getText();
        else if ((i >= Grid.this.items.size()) && (i < Grid.this.items.size() + Grid.this.columns.size()))
          paramAnonymousAccessibleEvent.result = ((GridColumn)Grid.this.columns.get(i - Grid.this.items.size())).getText();
        else if ((i >= Grid.this.items.size() + Grid.this.columns.size()) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length))
          paramAnonymousAccessibleEvent.result = Grid.this.columnGroups[(i - Grid.this.items.size() - Grid.this.columns.size())].getText();
        else if ((i >= Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length + Grid.this.columnGroups.length))
          paramAnonymousAccessibleEvent.result = "Toggle Button";
      }
    });
    localAccessible.addAccessibleControlListener(new AccessibleControlAdapter()
    {
      public void getChildAtPoint(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        Point localPoint = Grid.this.toControl(paramAnonymousAccessibleControlEvent.x, paramAnonymousAccessibleControlEvent.y);
        paramAnonymousAccessibleControlEvent.childID = -1;
        GridItem localGridItem = Grid.this.getItem(localPoint);
        if (localGridItem != null)
        {
          for (int i = 0; i < Grid.this.getItems().length; i++)
            if (localGridItem.equals(Grid.this.getItem(i)))
            {
              paramAnonymousAccessibleControlEvent.childID = i;
              return;
            }
        }
        else
        {
          GridColumn localGridColumn = Grid.this.overColumnHeader(localPoint.x, localPoint.y);
          if (localGridColumn != null)
          {
            for (int j = 0; j < Grid.this.getColumns().length; j++)
              if (localGridColumn.equals(Grid.this.getColumn(j)))
              {
                paramAnonymousAccessibleControlEvent.childID = (Grid.this.getItems().length + j);
                return;
              }
          }
          else
          {
            GridColumnGroup localGridColumnGroup = Grid.this.overColumnGroupHeader(localPoint.x, localPoint.y);
            if (localGridColumnGroup != null)
              for (int k = 0; k < Grid.this.getColumnGroups().length; k++)
                if (localGridColumnGroup.equals(Grid.this.getColumnGroup(k)))
                {
                  Rectangle localRectangle = ((DefaultColumnGroupHeaderRenderer)localGridColumnGroup.getHeaderRenderer()).getToggleBounds();
                  if (localRectangle.contains(localPoint.x, localPoint.y))
                    paramAnonymousAccessibleControlEvent.childID = (Grid.this.getItems().length + Grid.this.getColumns().length + Grid.this.getColumnGroups().length + k);
                  else
                    paramAnonymousAccessibleControlEvent.childID = (Grid.this.getItems().length + Grid.this.getColumns().length + k);
                  return;
                }
          }
        }
      }

      public void getChildCount(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        if (paramAnonymousAccessibleControlEvent.childID == -1)
        {
          int i = Grid.this.items.size();
          if (Grid.this.isTree)
            for (int j = 0; j < Grid.this.items.size(); j++)
              if (((GridItem)Grid.this.items.get(j)).getParentItem() != null)
                i--;
          paramAnonymousAccessibleControlEvent.detail = i;
        }
      }

      public void getChildren(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        if (paramAnonymousAccessibleControlEvent.childID == -1)
        {
          int i = Grid.this.items.size();
          Object[] arrayOfObject;
          int k;
          if (Grid.this.isTree)
          {
            for (int j = 0; j < Grid.this.items.size(); j++)
              if (((GridItem)Grid.this.items.get(j)).getParentItem() != null)
                i--;
            arrayOfObject = new Object[i];
            k = 0;
            for (int m = 0; m < Grid.this.items.size(); m++)
              if (((GridItem)Grid.this.items.get(m)).getParentItem() == null)
              {
                arrayOfObject[k] = Integer.valueOf(m);
                k++;
              }
            paramAnonymousAccessibleControlEvent.children = arrayOfObject;
          }
          else
          {
            arrayOfObject = new Object[i];
            for (k = 0; k < Grid.this.items.size(); k++)
              arrayOfObject[k] = Integer.valueOf(k);
            paramAnonymousAccessibleControlEvent.children = arrayOfObject;
          }
        }
      }

      public void getDefaultAction(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = paramAnonymousAccessibleControlEvent.childID;
        if ((i >= 0) && (i < Grid.this.items.size()))
        {
          if (Grid.this.getItem(i).hasChildren())
          {
            if (Grid.this.getItem(i).isExpanded())
              paramAnonymousAccessibleControlEvent.result = "Collapse";
            else
              paramAnonymousAccessibleControlEvent.result = "Expand";
          }
          else
            paramAnonymousAccessibleControlEvent.result = "Double Click";
        }
        else if ((i >= Grid.this.items.size()) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length))
          paramAnonymousAccessibleControlEvent.result = "Click";
        else if ((i >= Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length + Grid.this.columnGroups.length))
          paramAnonymousAccessibleControlEvent.result = SWT.getMessage("SWT_Press");
      }

      public void getLocation(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        Rectangle localRectangle = Grid.this.getBounds();
        localRectangle.x = 0;
        localRectangle.y = 0;
        int i = paramAnonymousAccessibleControlEvent.childID;
        Object localObject;
        if ((i >= 0) && (i < Grid.this.items.size()))
        {
          localObject = Grid.this.getItem(i);
          if (localObject != null)
          {
            Point localPoint = Grid.this.getOrigin((GridColumn)Grid.this.columns.get(0), (GridItem)localObject);
            localRectangle.y = localPoint.y;
            localRectangle.height = ((GridItem)localObject).getHeight();
          }
        }
        else if ((i >= Grid.this.items.size()) && (i < Grid.this.items.size() + Grid.this.columns.size()))
        {
          localObject = Grid.this.getColumn(i - Grid.this.items.size());
          if (localObject != null)
          {
            localRectangle.x = Grid.this.getColumnHeaderXPosition((GridColumn)localObject);
            if (((GridColumn)localObject).getColumnGroup() == null)
              localRectangle.y = 0;
            else
              localRectangle.y = Grid.this.groupHeaderHeight;
            localRectangle.height = Grid.this.headerHeight;
            localRectangle.width = ((GridColumn)localObject).getWidth();
          }
        }
        else if ((i >= Grid.this.items.size() + Grid.this.columns.size()) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length))
        {
          localObject = Grid.this.getColumnGroup(i - Grid.this.items.size() - Grid.this.columns.size());
          if (localObject != null)
          {
            localRectangle.y = 0;
            localRectangle.height = Grid.this.groupHeaderHeight;
            localRectangle.x = Grid.this.getColumnHeaderXPosition(((GridColumnGroup)localObject).getFirstVisibleColumn());
            int j = 0;
            for (int k = 0; k < ((GridColumnGroup)localObject).getColumns().length; k++)
              if (localObject.getColumns()[k].isVisible())
                j += localObject.getColumns()[k].getWidth();
            localRectangle.width = j;
          }
        }
        else if ((i >= Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length + Grid.this.columnGroups.length))
        {
          localObject = Grid.this.getColumnGroup(i - Grid.this.items.size() - Grid.this.columns.size() - Grid.this.columnGroups.length);
          localRectangle = ((DefaultColumnGroupHeaderRenderer)((GridColumnGroup)localObject).getHeaderRenderer()).getToggleBounds();
        }
        if (localRectangle != null)
        {
          localObject = Grid.this.toDisplay(localRectangle.x, localRectangle.y);
          paramAnonymousAccessibleControlEvent.x = ((Point)localObject).x;
          paramAnonymousAccessibleControlEvent.y = ((Point)localObject).y;
          paramAnonymousAccessibleControlEvent.width = localRectangle.width;
          paramAnonymousAccessibleControlEvent.height = localRectangle.height;
        }
      }

      public void getRole(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = paramAnonymousAccessibleControlEvent.childID;
        if ((i >= 0) && (i < Grid.this.items.size()))
        {
          if (Grid.this.isTree)
            paramAnonymousAccessibleControlEvent.detail = 36;
          else
            paramAnonymousAccessibleControlEvent.detail = 34;
        }
        else if ((i >= Grid.this.items.size()) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length))
          paramAnonymousAccessibleControlEvent.detail = 25;
        else if ((i >= Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length + Grid.this.columnGroups.length))
          paramAnonymousAccessibleControlEvent.detail = 43;
        else if (i == -1)
          if (Grid.this.isTree)
            paramAnonymousAccessibleControlEvent.detail = 35;
          else
            paramAnonymousAccessibleControlEvent.detail = 24;
      }

      public void getSelection(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        paramAnonymousAccessibleControlEvent.childID = -2;
        if (Grid.this.selectedItems.size() == 1)
        {
          paramAnonymousAccessibleControlEvent.childID = Grid.this.indexOf((GridItem)Grid.this.selectedItems.get(0));
        }
        else if (Grid.this.selectedItems.size() > 1)
        {
          paramAnonymousAccessibleControlEvent.childID = -3;
          int i = Grid.this.selectedItems.size();
          Object[] arrayOfObject = new Object[i];
          for (int j = 0; j < i; j++)
          {
            GridItem localGridItem = (GridItem)Grid.this.selectedItems.get(j);
            arrayOfObject[j] = Integer.valueOf(Grid.this.indexOf(localGridItem));
          }
          paramAnonymousAccessibleControlEvent.children = arrayOfObject;
        }
      }

      public void getState(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = paramAnonymousAccessibleControlEvent.childID;
        if ((i >= 0) && (i < Grid.this.items.size()))
        {
          paramAnonymousAccessibleControlEvent.detail = 2097152;
          if (Grid.this.getDisplay().getActiveShell() == Grid.this.getParent().getShell())
            paramAnonymousAccessibleControlEvent.detail |= 1048576;
          if (Grid.this.selectedItems.contains(Grid.this.getItem(i)))
          {
            paramAnonymousAccessibleControlEvent.detail |= 2;
            if (Grid.this.getDisplay().getActiveShell() == Grid.this.getParent().getShell())
              paramAnonymousAccessibleControlEvent.detail |= 4;
          }
          if (Grid.this.getItem(i).getChecked())
            paramAnonymousAccessibleControlEvent.detail |= 16;
          if (Grid.this.getItem(i).hasChildren())
            if (Grid.this.getItem(i).isExpanded())
              paramAnonymousAccessibleControlEvent.detail |= 512;
            else
              paramAnonymousAccessibleControlEvent.detail |= 1024;
          if (!Grid.this.getItem(i).isVisible())
            paramAnonymousAccessibleControlEvent.detail |= 32768;
        }
        else if ((i >= Grid.this.items.size()) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length))
        {
          paramAnonymousAccessibleControlEvent.detail = 64;
        }
        else if ((i >= Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length) && (i < Grid.this.items.size() + Grid.this.columns.size() + Grid.this.columnGroups.length + Grid.this.columnGroups.length))
        {
          if (Grid.this.getColumnGroup(i - Grid.this.items.size() - Grid.this.columns.size() - Grid.this.columnGroups.length).getExpanded())
            paramAnonymousAccessibleControlEvent.detail = 512;
          else
            paramAnonymousAccessibleControlEvent.detail = 1024;
        }
      }

      public void getValue(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = paramAnonymousAccessibleControlEvent.childID;
        if ((i >= 0) && (i < Grid.this.items.size()) && (Grid.this.isTree))
          paramAnonymousAccessibleControlEvent.result = Grid.this.getItem(i).getLevel();
      }
    });
    addListener(13, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (Grid.this.selectedItems.size() > 0)
          localAccessible.setFocus(Grid.this.items.indexOf(Grid.this.selectedItems.get(Grid.this.selectedItems.size() - 1)));
      }
    });
    addTreeListener(new TreeListener()
    {
      public void treeCollapsed(TreeEvent paramAnonymousTreeEvent)
      {
        if (Grid.this.getFocusItem() != null)
          localAccessible.setFocus(Grid.this.items.indexOf(Grid.this.getFocusItem()));
      }

      public void treeExpanded(TreeEvent paramAnonymousTreeEvent)
      {
        if (Grid.this.getFocusItem() != null)
          localAccessible.setFocus(Grid.this.items.indexOf(Grid.this.getFocusItem()));
      }
    });
  }

  boolean isDisposing()
  {
    return this.disposing;
  }

  void setHasSpanning(boolean paramBoolean)
  {
    this.hasSpanning = paramBoolean;
  }

  public String getToolTipText()
  {
    checkWidget();
    return this.toolTipText;
  }

  public void setToolTipText(String paramString)
  {
    checkWidget();
    this.toolTipText = paramString;
  }

  void imageSetOnItem(int paramInt, GridItem paramGridItem)
  {
    int i;
    if (this.sizeOnEveryItemImageChange)
    {
      if ((paramGridItem == null) || (paramGridItem.getImage(paramInt) == null))
        return;
      i = paramGridItem.getImage(paramInt).getBounds().height;
      if (i + 20 > getItemHeight())
      {
        i = computeItemHeight(paramGridItem, this.sizingGC);
        setItemHeight(i);
      }
    }
    else
    {
      if ((this.firstImageSet) || (this.userModifiedItemHeight))
        return;
      i = computeItemHeight(paramGridItem, this.sizingGC);
      setItemHeight(i);
      this.firstImageSet = true;
    }
  }

  private boolean handleHoverOnSelectionDragArea(int paramInt1, int paramInt2)
  {
    boolean bool = false;
    if (((!this.rowHeaderVisible) || (paramInt1 > this.rowHeaderWidth - 2)) && ((!this.columnHeadersVisible) || (paramInt2 > this.headerHeight - 2)))
    {
      Point localPoint;
      Object localObject;
      if (this.cellSelectionEnabled)
      {
        localPoint = new Point(paramInt1, paramInt2);
        localObject = getCell(localPoint);
        bool = (localObject != null) && (isCellSelected((Point)localObject));
      }
      else
      {
        localPoint = new Point(paramInt1, paramInt2);
        localObject = getItem(localPoint);
        bool = (localObject != null) && (isSelected((GridItem)localObject));
      }
    }
    if (bool != this.hoveringOnSelectionDragArea)
      this.hoveringOnSelectionDragArea = bool;
    return bool;
  }

  void setInsertMark(GridItem paramGridItem, GridColumn paramGridColumn, boolean paramBoolean)
  {
    checkWidget();
    if ((paramGridItem != null) && (paramGridItem.isDisposed()))
      SWT.error(5);
    if ((paramGridColumn != null) && (paramGridColumn.isDisposed()))
      SWT.error(5);
    this.insertMarkItem = paramGridItem;
    this.insertMarkColumn = paramGridColumn;
    this.insertMarkBefore = paramBoolean;
    redraw();
  }

  boolean isInDragScrollArea(Point paramPoint)
  {
    int i = this.rowHeaderVisible ? this.rowHeaderWidth : 0;
    int j = this.columnHeadersVisible ? this.headerHeight : 0;
    Rectangle localRectangle1 = new Rectangle(i, j, getClientArea().width - i, 12);
    Rectangle localRectangle2 = new Rectangle(i, getClientArea().height - 12, getClientArea().width - i, 12);
    return (localRectangle1.contains(paramPoint)) || (localRectangle2.contains(paramPoint));
  }

  public void clear(int paramInt, boolean paramBoolean)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt >= this.items.size()))
      SWT.error(6);
    GridItem localGridItem = getItem(paramInt);
    localGridItem.clear(paramBoolean);
    redraw();
  }

  public void clear(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    checkWidget();
    if (paramInt1 > paramInt2)
      return;
    int i = this.items.size();
    if ((paramInt1 < 0) || (paramInt1 > paramInt2) || (paramInt2 >= i))
      SWT.error(6);
    for (int j = paramInt1; j <= paramInt2; j++)
    {
      GridItem localGridItem = (GridItem)this.items.get(j);
      localGridItem.clear(paramBoolean);
    }
    redraw();
  }

  public void clear(int[] paramArrayOfInt, boolean paramBoolean)
  {
    checkWidget();
    if (paramArrayOfInt == null)
      SWT.error(4);
    if (paramArrayOfInt.length == 0)
      return;
    int i = this.items.size();
    for (int j = 0; j < paramArrayOfInt.length; j++)
      if ((paramArrayOfInt[j] < 0) || (paramArrayOfInt[j] >= i))
        SWT.error(6);
    for (j : paramArrayOfInt)
    {
      GridItem localGridItem = (GridItem)this.items.get(j);
      localGridItem.clear(paramBoolean);
    }
    redraw();
  }

  public void clearAll(boolean paramBoolean)
  {
    checkWidget();
    if (this.items.size() > 0)
      clear(0, this.items.size() - 1, paramBoolean);
  }

  void recalculateHeader()
  {
    computeHeaderHeight(this.sizingGC);
    this.scrollValuesObsolete = true;
    redraw();
  }

  public GridVisibleRange getVisibleRange()
  {
    int i = getTopIndex();
    int j = getBottomIndex();
    int k = getStartColumnIndex();
    int m = getEndColumnIndex();
    GridVisibleRange localGridVisibleRange = new GridVisibleRange();
    localGridVisibleRange.items = new GridItem[0];
    localGridVisibleRange.columns = new GridColumn[0];
    if ((i <= j) && (this.items.size() > 0))
    {
      localGridVisibleRange.items = new GridItem[j - i + 1];
      for (int n = i; n <= j; n++)
        localGridVisibleRange.items[(n - i)] = ((GridItem)this.items.get(n));
    }
    if ((k <= m) && (this.displayOrderedColumns.size() > 0))
    {
      ArrayList localArrayList = new ArrayList();
      for (int i1 = k; i1 <= m; i1++)
      {
        GridColumn localGridColumn = (GridColumn)this.displayOrderedColumns.get(i1);
        if (localGridColumn.isVisible())
          localArrayList.add(localGridColumn);
      }
      localGridVisibleRange.columns = new GridColumn[localArrayList.size()];
      localArrayList.toArray(localGridVisibleRange.columns);
    }
    return localGridVisibleRange;
  }

  int getStartColumnIndex()
  {
    checkWidget();
    if (this.startColumnIndex != -1)
      return this.startColumnIndex;
    if (!this.hScroll.getVisible())
      this.startColumnIndex = 0;
    this.startColumnIndex = this.hScroll.getSelection();
    return this.startColumnIndex;
  }

  int getEndColumnIndex()
  {
    checkWidget();
    if (this.endColumnIndex != -1)
      return this.endColumnIndex;
    if (this.displayOrderedColumns.size() == 0)
    {
      this.endColumnIndex = 0;
    }
    else if (getVisibleGridWidth() < 1)
    {
      this.endColumnIndex = getStartColumnIndex();
    }
    else
    {
      int i = 0;
      i -= getHScrollSelectionInPixels();
      if (this.rowHeaderVisible)
        i += this.rowHeaderWidth;
      int j = getStartColumnIndex();
      GridColumn[] arrayOfGridColumn = new GridColumn[this.displayOrderedColumns.size()];
      this.displayOrderedColumns.toArray(arrayOfGridColumn);
      for (int k = j; k < arrayOfGridColumn.length; k++)
      {
        this.endColumnIndex = k;
        GridColumn localGridColumn = arrayOfGridColumn[k];
        if (localGridColumn.isVisible())
          i += localGridColumn.getWidth();
        if (i > getClientArea().width)
          break;
      }
    }
    this.endColumnIndex = Math.max(0, this.endColumnIndex);
    return this.endColumnIndex;
  }

  void setSizeOnEveryItemImageChange(boolean paramBoolean)
  {
    this.sizeOnEveryItemImageChange = paramBoolean;
  }

  public boolean getHiddenByFreeze(GridColumn paramGridColumn)
  {
    int i = getFrozenColumnWidth();
    if (i > 0)
    {
      int j = getHScrollSelectionInPixels();
      if (j > 0)
      {
        Iterator localIterator = this.displayOrderedColumns.iterator();
        for (GridColumn localGridColumn = (GridColumn)localIterator.next(); localGridColumn.getFrozen(); localGridColumn = (GridColumn)localIterator.next());
        while (j > 0)
        {
          if (localGridColumn.getText().equals(paramGridColumn.getText()))
            return true;
          j -= localGridColumn.getWidth();
          if (j > 0)
            localGridColumn = (GridColumn)localIterator.next();
        }
      }
    }
    return false;
  }

  private int getFrozenColumnWidth()
  {
    int i = 0;
    Iterator localIterator = this.displayOrderedColumns.iterator();
    while (localIterator.hasNext())
    {
      GridColumn localGridColumn = (GridColumn)localIterator.next();
      if (localGridColumn.getFrozen())
        i += localGridColumn.getWidth();
    }
    return i;
  }

  public int getColumnGroupHeaderDepth()
  {
    checkWidget();
    int i = 1;
    for (GridColumnGroup localGridColumnGroup : this.columnGroups)
    {
      int m = localGridColumnGroup.getHeaderGroupCount();
      i = Math.max(i, m);
    }
    return i;
  }

  public void scaleGrid(double paramDouble)
  {
    if (size100 == -1)
    {
      size100 = getItemHeight();
      FontData[] arrayOfFontData1 = getFont().getFontData();
      font100 = arrayOfFontData1[0].getHeight();
    }
    if (paramDouble < 0.1D)
      return;
    int i = getItemHeight();
    int j = (int)(size100 * paramDouble);
    setItemHeight(j);
    int k = (int)(font100 * paramDouble);
    FontData[] arrayOfFontData2 = getFont().getFontData();
    for (localObject : arrayOfFontData2)
      ((FontData)localObject).setHeight(k);
    Object localObject = Display.getCurrent();
    Font localFont = new Font((Device)localObject, arrayOfFontData2);
    setFont(localFont);
    ??? = getColumnCount();
    float f = j / i;
    for (int i1 = 0; i1 < ???; i1++)
    {
      GridColumn localGridColumn = getColumn(i1);
      int i2 = localGridColumn.getWidth();
      int i3 = (int)((0.5D + i2 * 100.0D * f) / 100.0D);
      localGridColumn.setWidth(i3);
    }
    computeHeaderHeight(this.sizingGC);
  }

  public static class GridVisibleRange
  {
    private GridItem[] items = new GridItem[0];
    private GridColumn[] columns = new GridColumn[0];

    public GridItem[] getItems()
    {
      return this.items;
    }

    public GridColumn[] getColumns()
    {
      return this.columns;
    }
  }

  private static class RowRange
  {
    public int startIndex;
    public int endIndex;
    public int rows;
    public int height;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.Grid
 * JD-Core Version:    0.6.2
 */