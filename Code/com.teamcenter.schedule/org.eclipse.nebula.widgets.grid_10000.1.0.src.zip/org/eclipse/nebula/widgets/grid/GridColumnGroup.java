package org.eclipse.nebula.widgets.grid;

import java.util.Vector;
import org.eclipse.nebula.widgets.grid.internal.DefaultColumnGroupHeaderRenderer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.TreeListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.TypedListener;

public class GridColumnGroup extends Item
{
  private Grid parent;
  private GridColumnGroup parentGroup = null;
  private int orderInParentGroup = -1;
  private int numberOfChildGroups = 0;
  private GridColumn[] columns = new GridColumn[0];
  private boolean expanded = true;
  private GridHeaderRenderer headerRenderer = new DefaultColumnGroupHeaderRenderer();

  public GridColumnGroup(Grid paramGrid, int paramInt)
  {
    super(paramGrid, paramInt);
    this.parent = paramGrid;
    this.headerRenderer.setDisplay(getDisplay());
    paramGrid.newColumnGroup(this);
  }

  public void addTreeListener(TreeListener paramTreeListener)
  {
    checkWidget();
    if (paramTreeListener == null)
      SWT.error(4);
    TypedListener localTypedListener = new TypedListener(paramTreeListener);
    addListener(17, localTypedListener);
    addListener(18, localTypedListener);
  }

  public void removeTreeListener(TreeListener paramTreeListener)
  {
    checkWidget();
    if (paramTreeListener == null)
      SWT.error(4);
    removeListener(17, paramTreeListener);
    removeListener(18, paramTreeListener);
  }

  public Grid getParent()
  {
    checkWidget();
    return this.parent;
  }

  int getNewColumnIndex()
  {
    if (this.columns.length == 0)
      return -1;
    GridColumn localGridColumn = this.columns[(this.columns.length - 1)];
    return this.parent.indexOf(localGridColumn) + 1;
  }

  void newColumn(GridColumn paramGridColumn, int paramInt)
  {
    GridColumn[] arrayOfGridColumn = new GridColumn[this.columns.length + 1];
    System.arraycopy(this.columns, 0, arrayOfGridColumn, 0, this.columns.length);
    arrayOfGridColumn[(arrayOfGridColumn.length - 1)] = paramGridColumn;
    this.columns = arrayOfGridColumn;
  }

  void removeColumn(GridColumn paramGridColumn)
  {
    GridColumn[] arrayOfGridColumn1 = new GridColumn[this.columns.length - 1];
    int i = 0;
    for (GridColumn localGridColumn : this.columns)
      if (localGridColumn != paramGridColumn)
      {
        arrayOfGridColumn1[i] = localGridColumn;
        i++;
      }
    this.columns = arrayOfGridColumn1;
  }

  public GridColumn[] getColumns()
  {
    checkWidget();
    GridColumn[] arrayOfGridColumn = new GridColumn[this.columns.length];
    System.arraycopy(this.columns, 0, arrayOfGridColumn, 0, this.columns.length);
    return arrayOfGridColumn;
  }

  public void dispose()
  {
    super.dispose();
    if (this.parent.isDisposing())
      return;
    for (GridColumn localGridColumn : this.columns)
      localGridColumn.dispose();
    this.parent.removeColumnGroup(this);
  }

  public GridHeaderRenderer getHeaderRenderer()
  {
    checkWidget();
    return this.headerRenderer;
  }

  public void setHeaderRenderer(GridHeaderRenderer paramGridHeaderRenderer)
  {
    if (paramGridHeaderRenderer == null)
      SWT.error(4);
    this.headerRenderer = paramGridHeaderRenderer;
    paramGridHeaderRenderer.setDisplay(getDisplay());
  }

  public boolean getExpanded()
  {
    checkWidget();
    return this.expanded;
  }

  public void setExpanded(boolean paramBoolean)
  {
    checkWidget();
    this.expanded = paramBoolean;
    if ((!paramBoolean) && (getParent().getCellSelectionEnabled()))
    {
      Vector localVector = new Vector();
      for (int i = 0; i < this.columns.length; i++)
        if (!this.columns[i].isSummary())
          localVector.add(Integer.valueOf(getParent().indexOf(this.columns[i])));
      Point[] arrayOfPoint1 = getParent().getCellSelection();
      for (Point localPoint : arrayOfPoint1)
        if (localVector.contains(Integer.valueOf(localPoint.x)))
          getParent().deselectCell(localPoint);
      if ((getParent().getFocusColumn() != null) && (getParent().getFocusColumn().getColumnGroup() == this))
        getParent().updateColumnFocus();
      this.parent.updateColumnSelection();
    }
    if (this.parent.getCellSelectionEnabled())
      this.parent.refreshHoverState();
    this.parent.setScrollValuesObsolete();
    this.parent.redraw();
  }

  GridColumn getFirstVisibleColumn()
  {
    GridColumn[] arrayOfGridColumn1 = this.parent.getColumnsInOrder();
    for (GridColumn localGridColumn : arrayOfGridColumn1)
      if ((localGridColumn.getColumnGroup() == this) && (localGridColumn.isVisible()))
        return localGridColumn;
    return null;
  }

  GridColumn getLastVisibleColumn()
  {
    GridColumn[] arrayOfGridColumn1 = this.parent.getColumnsInOrder();
    Object localObject = null;
    for (GridColumn localGridColumn : arrayOfGridColumn1)
      if ((localGridColumn.getColumnGroup() == this) && (localGridColumn.isVisible()))
        localObject = localGridColumn;
    return localObject;
  }

  Rectangle getBounds()
  {
    Rectangle localRectangle = new Rectangle(0, 0, 0, 0);
    localRectangle.height = this.parent.getGroupHeaderHeight();
    int i = 0;
    GridColumn[] arrayOfGridColumn1 = this.parent.getColumnsInOrder();
    for (GridColumn localGridColumn : arrayOfGridColumn1)
      if (localGridColumn.getColumnGroup() == this)
      {
        if (localGridColumn.isVisible())
        {
          if (i == 0)
          {
            localRectangle.x = this.parent.getOrigin(localGridColumn, null).x;
            i = 1;
          }
          localRectangle.width += localGridColumn.getWidth();
        }
      }
      else
        if (i != 0)
          break;
    return localRectangle;
  }

  public int getOrderInParentGroup()
  {
    return this.orderInParentGroup;
  }

  public int getNumberOfChildGroups()
  {
    return this.numberOfChildGroups;
  }

  public void setParentGroup(GridColumnGroup paramGridColumnGroup)
  {
    this.parentGroup = paramGridColumnGroup;
    this.orderInParentGroup = this.parentGroup.numberOfChildGroups;
    this.parentGroup.numberOfChildGroups += 1;
  }

  public GridColumnGroup getParentGroup()
  {
    checkWidget();
    return this.parentGroup;
  }

  int getHeaderGroupCount()
  {
    int i = 1;
    for (GridColumnGroup localGridColumnGroup = this; localGridColumnGroup.parentGroup != null; localGridColumnGroup = localGridColumnGroup.parentGroup)
      i++;
    return i;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridColumnGroup
 * JD-Core Version:    0.6.2
 */