package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.AbstractRenderer;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class DefaultEmptyColumnFooterRenderer extends AbstractRenderer
{
  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    return new Point(paramInt1, paramInt2);
  }

  public void paint(GC paramGC, Object paramObject)
  {
    paramGC.setBackground(getDisplay().getSystemColor(22));
    paramGC.fillRectangle(getBounds().x, getBounds().y, getBounds().width + 1, getBounds().height + 1);
    paramGC.drawLine(getBounds().x, getBounds().y, getBounds().x + getBounds().width, getBounds().y);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.DefaultEmptyColumnFooterRenderer
 * JD-Core Version:    0.6.2
 */