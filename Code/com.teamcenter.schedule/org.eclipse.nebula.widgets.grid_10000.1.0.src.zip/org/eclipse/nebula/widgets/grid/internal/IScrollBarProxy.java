package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Event;

public abstract interface IScrollBarProxy
{
  public abstract boolean getVisible();

  public abstract void setVisible(boolean paramBoolean);

  public abstract int getSelection();

  public abstract void setSelection(int paramInt);

  public abstract void setValues(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);

  public abstract void handleMouseWheel(Event paramEvent);

  public abstract void setMinimum(int paramInt);

  public abstract int getMinimum();

  public abstract void setMaximum(int paramInt);

  public abstract int getMaximum();

  public abstract void setThumb(int paramInt);

  public abstract int getThumb();

  public abstract void setIncrement(int paramInt);

  public abstract int getIncrement();

  public abstract void setPageIncrement(int paramInt);

  public abstract int getPageIncrement();

  public abstract void addSelectionListener(SelectionListener paramSelectionListener);

  public abstract void removeSelectionListener(SelectionListener paramSelectionListener);
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.IScrollBarProxy
 * JD-Core Version:    0.6.2
 */