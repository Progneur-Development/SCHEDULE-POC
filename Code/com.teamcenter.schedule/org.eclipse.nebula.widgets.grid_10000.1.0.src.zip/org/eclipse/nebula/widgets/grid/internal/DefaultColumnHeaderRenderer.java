package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridColumn;
import org.eclipse.nebula.widgets.grid.GridHeaderRenderer;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;

public class DefaultColumnHeaderRenderer extends GridHeaderRenderer
{
  int leftMargin = 6;
  int rightMargin = 6;
  int topMargin = 3;
  int bottomMargin = 3;
  int arrowMargin = 6;
  int imageSpacing = 3;
  private SortArrowRenderer arrowRenderer = new SortArrowRenderer();

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    GridColumn localGridColumn = (GridColumn)paramObject;
    int i = 0;
    i += this.leftMargin;
    i += paramGC.stringExtent(localGridColumn.getText()).x + this.rightMargin;
    int j = 0;
    j += this.topMargin;
    j += paramGC.getFontMetrics().getHeight();
    j += this.bottomMargin;
    if (localGridColumn.getImage() != null)
    {
      i += localGridColumn.getImage().getBounds().width + this.imageSpacing;
      j = Math.max(j, this.topMargin + localGridColumn.getImage().getBounds().height + this.bottomMargin);
    }
    j += computeControlSize(localGridColumn).y;
    return new Point(i, j);
  }

  public void paint(GC paramGC, Object paramObject)
  {
    GridColumn localGridColumn = (GridColumn)paramObject;
    int i = (localGridColumn.getParent().getCellSelectionEnabled()) && (!localGridColumn.getMoveable()) ? 1 : 0;
    int j = (isMouseDown()) && (isHover()) ? 1 : 0;
    paramGC.setBackground(getDisplay().getSystemColor(22));
    if ((i != 0) && (isSelected()))
      paramGC.setBackground(localGridColumn.getParent().getCellHeaderSelectionBackground());
    paramGC.fillRectangle(getBounds().x, getBounds().y, getBounds().width, getBounds().height);
    int k = 0;
    if (j != 0)
      k = 1;
    int m = this.leftMargin;
    if (localGridColumn.getImage() != null)
    {
      n = this.bottomMargin;
      if (localGridColumn.getHeaderControl() == null)
        n = getBounds().y + k + getBounds().height - this.bottomMargin - localGridColumn.getImage().getBounds().height;
      paramGC.drawImage(localGridColumn.getImage(), getBounds().x + m + k, n);
      m += localGridColumn.getImage().getBounds().width + this.imageSpacing;
    }
    int n = getBounds().width - m;
    if (localGridColumn.getSort() == 0)
      n -= this.rightMargin;
    else
      n -= this.arrowMargin + this.arrowRenderer.getSize().x + this.arrowMargin;
    paramGC.setForeground(getDisplay().getSystemColor(21));
    int i1 = this.bottomMargin;
    if (localGridColumn.getHeaderControl() == null)
      i1 = getBounds().y + getBounds().height - this.bottomMargin - paramGC.getFontMetrics().getHeight();
    else
      i1 = getBounds().y + getBounds().height - this.bottomMargin - paramGC.getFontMetrics().getHeight() - computeControlSize(localGridColumn).y;
    String str = TextUtils.getShortString(paramGC, localGridColumn.getText(), n);
    int i2;
    if (localGridColumn.getAlignment() == 131072)
    {
      i2 = paramGC.stringExtent(str).x;
      if (i2 < n)
        m += n - i2;
    }
    else if (localGridColumn.getAlignment() == 16777216)
    {
      i2 = paramGC.stringExtent(str).x;
      if (i2 < n)
        m += (n - i2) / 2;
    }
    paramGC.drawString(str, getBounds().x + m + k, i1 + k, true);
    if (localGridColumn.getSort() != 0)
    {
      if (localGridColumn.getHeaderControl() == null)
        i1 = getBounds().y + (getBounds().height - this.arrowRenderer.getBounds().height) / 2 + 1;
      else
        i1 = getBounds().y + (getBounds().height - computeControlSize(localGridColumn).y - this.arrowRenderer.getBounds().height) / 2 + 1;
      this.arrowRenderer.setSelected(localGridColumn.getSort() == 128);
      if (j != 0)
      {
        this.arrowRenderer.setLocation(getBounds().x + getBounds().width - this.arrowMargin - this.arrowRenderer.getBounds().width + 1, i1);
      }
      else
      {
        if (localGridColumn.getHeaderControl() == null)
          i1 = getBounds().y + (getBounds().height - this.arrowRenderer.getBounds().height) / 2;
        else
          i1 = getBounds().y + (getBounds().height - computeControlSize(localGridColumn).y - this.arrowRenderer.getBounds().height) / 2;
        this.arrowRenderer.setLocation(getBounds().x + getBounds().width - this.arrowMargin - this.arrowRenderer.getBounds().width, i1);
      }
      this.arrowRenderer.paint(paramGC, null);
    }
    if (i == 0)
    {
      if (j != 0)
        paramGC.setForeground(getDisplay().getSystemColor(18));
      else
        paramGC.setForeground(getDisplay().getSystemColor(20));
      paramGC.drawLine(getBounds().x, getBounds().y, getBounds().x + getBounds().width - 1, getBounds().y);
      paramGC.drawLine(getBounds().x, getBounds().y, getBounds().x, getBounds().y + getBounds().height - 1);
      if (j == 0)
      {
        paramGC.setForeground(getDisplay().getSystemColor(19));
        paramGC.drawLine(getBounds().x + 1, getBounds().y + 1, getBounds().x + getBounds().width - 2, getBounds().y + 1);
        paramGC.drawLine(getBounds().x + 1, getBounds().y + 1, getBounds().x + 1, getBounds().y + getBounds().height - 2);
      }
      if (j != 0)
        paramGC.setForeground(getDisplay().getSystemColor(18));
      else
        paramGC.setForeground(getDisplay().getSystemColor(17));
      paramGC.drawLine(getBounds().x + getBounds().width - 1, getBounds().y, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
      paramGC.drawLine(getBounds().x, getBounds().y + getBounds().height - 1, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
      if (j == 0)
      {
        paramGC.setForeground(getDisplay().getSystemColor(18));
        paramGC.drawLine(getBounds().x + getBounds().width - 2, getBounds().y + 1, getBounds().x + getBounds().width - 2, getBounds().y + getBounds().height - 2);
        paramGC.drawLine(getBounds().x + 1, getBounds().y + getBounds().height - 2, getBounds().x + getBounds().width - 2, getBounds().y + getBounds().height - 2);
      }
    }
    else
    {
      paramGC.setForeground(getDisplay().getSystemColor(17));
      paramGC.drawLine(getBounds().x + getBounds().width - 1, getBounds().y, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
      paramGC.drawLine(getBounds().x, getBounds().y + getBounds().height - 1, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
    }
  }

  public void setDisplay(Display paramDisplay)
  {
    super.setDisplay(paramDisplay);
    this.arrowRenderer.setDisplay(paramDisplay);
  }

  public boolean notify(int paramInt, Point paramPoint, Object paramObject)
  {
    return false;
  }

  public Rectangle getTextBounds(Object paramObject, boolean paramBoolean)
  {
    GridColumn localGridColumn = (GridColumn)paramObject;
    int i = this.leftMargin;
    if (localGridColumn.getImage() != null)
      i += localGridColumn.getImage().getBounds().width + this.imageSpacing;
    GC localGC = new GC(localGridColumn.getParent());
    localGC.setFont(localGridColumn.getParent().getFont());
    int j = getBounds().height - this.bottomMargin - localGC.getFontMetrics().getHeight();
    Rectangle localRectangle = new Rectangle(i, j, 0, 0);
    Point localPoint = localGC.stringExtent(localGridColumn.getText());
    localRectangle.height = localPoint.y;
    if (paramBoolean)
    {
      localRectangle.width = localPoint.x;
    }
    else
    {
      int k = getBounds().width - i;
      if (localGridColumn.getSort() == 0)
        k -= this.rightMargin;
      else
        k -= this.arrowMargin + this.arrowRenderer.getSize().x + this.arrowMargin;
      localRectangle.width = k;
    }
    localGC.dispose();
    return localRectangle;
  }

  protected Rectangle getControlBounds(Object paramObject, boolean paramBoolean)
  {
    Rectangle localRectangle = getBounds();
    GridColumn localGridColumn = (GridColumn)paramObject;
    Point localPoint = computeControlSize(localGridColumn);
    int i = getBounds().y + getBounds().height - this.bottomMargin - localPoint.y;
    return new Rectangle(localRectangle.x + 3, i, localRectangle.width - 6, localPoint.y);
  }

  private Point computeControlSize(GridColumn paramGridColumn)
  {
    if (paramGridColumn.getHeaderControl() != null)
      return paramGridColumn.getHeaderControl().computeSize(-1, -1);
    return new Point(0, 0);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.DefaultColumnHeaderRenderer
 * JD-Core Version:    0.6.2
 */