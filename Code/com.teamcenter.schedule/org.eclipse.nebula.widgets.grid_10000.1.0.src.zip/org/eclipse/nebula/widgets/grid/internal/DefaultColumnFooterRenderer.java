package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridColumn;
import org.eclipse.nebula.widgets.grid.GridFooterRenderer;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class DefaultColumnFooterRenderer extends GridFooterRenderer
{
  int leftMargin = 6;
  int rightMargin = 6;
  int topMargin = 3;
  int bottomMargin = 3;
  int arrowMargin = 6;
  int imageSpacing = 3;

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    GridColumn localGridColumn = (GridColumn)paramObject;
    int i = 0;
    i += this.leftMargin;
    i += paramGC.stringExtent(localGridColumn.getText()).x + this.rightMargin;
    int j = 0;
    j += this.topMargin;
    j += paramGC.getFontMetrics().getHeight();
    j += this.bottomMargin;
    if (localGridColumn.getFooterImage() != null)
    {
      i += localGridColumn.getFooterImage().getBounds().width + this.imageSpacing;
      j = Math.max(j, this.topMargin + localGridColumn.getFooterImage().getBounds().height + this.bottomMargin);
    }
    return new Point(i, j);
  }

  public void paint(GC paramGC, Object paramObject)
  {
    GridColumn localGridColumn = (GridColumn)paramObject;
    paramGC.setBackground(getDisplay().getSystemColor(22));
    paramGC.setForeground(getDisplay().getSystemColor(21));
    paramGC.fillRectangle(getBounds().x, getBounds().y, getBounds().width, getBounds().height);
    paramGC.drawLine(getBounds().x, getBounds().y, getBounds().x + getBounds().width, getBounds().y);
    int i = this.leftMargin;
    if (localGridColumn.getFooterImage() != null)
    {
      paramGC.drawImage(localGridColumn.getFooterImage(), getBounds().x + i, getBounds().y + getBounds().height - this.bottomMargin - localGridColumn.getFooterImage().getBounds().height);
      i += localGridColumn.getFooterImage().getBounds().width + this.imageSpacing;
    }
    int j = getBounds().width - i;
    if (localGridColumn.getSort() == 0)
      j -= this.rightMargin;
    paramGC.setForeground(getDisplay().getSystemColor(21));
    int k = getBounds().y + getBounds().height - this.bottomMargin - paramGC.getFontMetrics().getHeight();
    String str = TextUtils.getShortString(paramGC, localGridColumn.getFooterText(), j);
    int m;
    if (localGridColumn.getAlignment() == 131072)
    {
      m = paramGC.stringExtent(str).x;
      if (m < j)
        i += j - m;
    }
    else if (localGridColumn.getAlignment() == 16777216)
    {
      m = paramGC.stringExtent(str).x;
      if (m < j)
        i += (j - m) / 2;
    }
    paramGC.drawString(str, getBounds().x + i, k, true);
  }

  public boolean notify(int paramInt, Point paramPoint, Object paramObject)
  {
    return false;
  }

  public Rectangle getTextBounds(Object paramObject, boolean paramBoolean)
  {
    GridColumn localGridColumn = (GridColumn)paramObject;
    int i = this.leftMargin;
    if (localGridColumn.getImage() != null)
      i += localGridColumn.getImage().getBounds().width + this.imageSpacing;
    GC localGC = new GC(localGridColumn.getParent());
    localGC.setFont(localGridColumn.getParent().getFont());
    int j = getBounds().height - this.bottomMargin - localGC.getFontMetrics().getHeight();
    Rectangle localRectangle = new Rectangle(i, j, 0, 0);
    Point localPoint = localGC.stringExtent(localGridColumn.getText());
    localRectangle.height = localPoint.y;
    if (paramBoolean)
    {
      localRectangle.width = localPoint.x;
    }
    else
    {
      int k = getBounds().width - i;
      if (localGridColumn.getSort() == 0)
        k -= this.rightMargin;
      localRectangle.width = k;
    }
    localGC.dispose();
    return localRectangle;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.DefaultColumnFooterRenderer
 * JD-Core Version:    0.6.2
 */