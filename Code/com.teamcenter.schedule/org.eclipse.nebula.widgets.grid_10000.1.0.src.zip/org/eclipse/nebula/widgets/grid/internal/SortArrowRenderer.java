package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.AbstractRenderer;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class SortArrowRenderer extends AbstractRenderer
{
  public SortArrowRenderer()
  {
    setSize(7, 4);
  }

  public void paint(GC paramGC, Object paramObject)
  {
    paramGC.setForeground(getDisplay().getSystemColor(18));
    if (isSelected())
    {
      paramGC.drawLine(getBounds().x + 0, getBounds().y + 0, getBounds().x + 6, getBounds().y + 0);
      paramGC.drawLine(getBounds().x + 1, getBounds().y + 1, getBounds().x + 5, getBounds().y + 1);
      paramGC.drawLine(getBounds().x + 2, getBounds().y + 2, getBounds().x + 4, getBounds().y + 2);
      paramGC.drawPoint(getBounds().x + 3, getBounds().y + 3);
    }
    else
    {
      paramGC.drawPoint(getBounds().x + 3, getBounds().y + 0);
      paramGC.drawLine(getBounds().x + 2, getBounds().y + 1, getBounds().x + 4, getBounds().y + 1);
      paramGC.drawLine(getBounds().x + 1, getBounds().y + 2, getBounds().x + 5, getBounds().y + 2);
      paramGC.drawLine(getBounds().x + 0, getBounds().y + 3, getBounds().x + 6, getBounds().y + 3);
    }
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    return new Point(7, 4);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.SortArrowRenderer
 * JD-Core Version:    0.6.2
 */