package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.AbstractRenderer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class BranchRenderer extends AbstractRenderer
{
  private static final int[] LINE_STYLE = { 1, 1 };
  public static final int H_FULL = 1;
  public static final int H_RIGHT = 2;
  public static final int H_CENTRE_TOGGLE = 4;
  public static final int H_LEFT_TOGGLE = 8;
  public static final int V_FULL = 16;
  public static final int V_TOP = 32;
  public static final int DESCENDER = 64;
  public static final int ASCENDER = 128;
  public static final int NONE = 0;
  public static final int T = 18;
  public static final int L = 34;
  public static final int I = 16;
  public static final int NODE = 64;
  public static final int LEAF = 8;
  public static final int ROOT = 192;
  public static final int LAST_ROOT = 128;
  public static final int SMALL_T = 20;
  public static final int SMALL_L = 36;
  private int indent;
  private int[] branches;
  private Rectangle toggleBounds;

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    return new Point(getBounds().width, getBounds().height);
  }

  public void paint(GC paramGC, Object paramObject)
  {
    Rectangle localRectangle = getBounds();
    boolean bool = SWT.getPlatform().equals("carbon");
    int i = localRectangle.x;
    int j = localRectangle.y - 1;
    int k = j + localRectangle.height;
    int m = this.toggleBounds.y + this.toggleBounds.height / 2;
    int n = this.toggleBounds.y + this.toggleBounds.height - 1;
    int i1 = this.toggleBounds.y;
    int i2 = paramGC.getLineStyle();
    Color localColor = paramGC.getForeground();
    int[] arrayOfInt = paramGC.getLineDash();
    paramGC.setForeground(getDisplay().getSystemColor(isSelected() ? 27 : 18));
    int i3 = localRectangle.y % 2;
    if (!bool)
    {
      paramGC.setLineDash(LINE_STYLE);
      i1--;
      j++;
      n++;
      if (localRectangle.height % 2 == 0)
      {
        k--;
      }
      else
      {
        j += i3;
        k -= i3;
      }
      n += i3;
      if ((i1 - j + 1) % 2 == 0)
        i1--;
      if ((n - k + 1) % 2 == 0)
        n += (i3 == 1 ? -1 : 1);
    }
    for (int i4 = 0; i4 < this.branches.length; i4++)
    {
      int i5 = i + this.indent;
      int i6 = i + this.toggleBounds.width / 2;
      int i7 = i6;
      int i8 = i + this.toggleBounds.width;
      int i9 = 0;
      if (!bool)
      {
        i5--;
        i7 += 2;
        i8--;
        if (this.indent % 2 == 0)
        {
          i5--;
        }
        else
        {
          i9 = i % 2;
          i += i9;
          i5 -= i9;
        }
      }
      if ((this.branches[i4] & 0x1) == 1)
        paramGC.drawLine(i, m, i5, m);
      if ((this.branches[i4] & 0x2) == 2)
        paramGC.drawLine(i7, m, i5, m);
      if ((this.branches[i4] & 0x4) == 4)
        paramGC.drawLine(i7, m, i8, m);
      if ((this.branches[i4] & 0x8) == 8)
        paramGC.drawLine(i, m, i8, m);
      if ((this.branches[i4] & 0x10) == 16)
        paramGC.drawLine(i6, j, i6, k);
      if ((this.branches[i4] & 0x20) == 32)
        paramGC.drawLine(i6, j, i6, m);
      if ((this.branches[i4] & 0x80) == 128)
        paramGC.drawLine(i6, j, i6, i1);
      if ((this.branches[i4] & 0x40) == 64)
        paramGC.drawLine(i6, n, i6, k);
      i += this.indent - i9;
    }
    paramGC.setLineDash(arrayOfInt);
    paramGC.setLineStyle(i2);
    paramGC.setForeground(localColor);
  }

  public void setBranches(int[] paramArrayOfInt)
  {
    this.branches = paramArrayOfInt;
  }

  public void setIndent(int paramInt)
  {
    this.indent = paramInt;
  }

  public void setToggleBounds(Rectangle paramRectangle)
  {
    this.toggleBounds = paramRectangle;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.BranchRenderer
 * JD-Core Version:    0.6.2
 */