package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.AbstractRenderer;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class ExpandToggleRenderer extends AbstractRenderer
{
  public ExpandToggleRenderer()
  {
    setSize(11, 9);
  }

  public void paint(GC paramGC, Object paramObject)
  {
    Color localColor1 = null;
    Color localColor2 = getDisplay().getSystemColor(18);
    if (isHover())
      localColor1 = getDisplay().getSystemColor(25);
    else
      localColor1 = getDisplay().getSystemColor(21);
    if (isExpanded())
    {
      drawLeftPointingLine(paramGC, localColor1, localColor2, 0);
      drawLeftPointingLine(paramGC, localColor1, localColor2, 5);
    }
    else
    {
      drawRightPointingLine(paramGC, localColor1, localColor2, 0);
      drawRightPointingLine(paramGC, localColor1, localColor2, 5);
    }
  }

  private void drawRightPointingLine(GC paramGC, Color paramColor1, Color paramColor2, int paramInt)
  {
    paramGC.setForeground(paramColor2);
    paramGC.drawLine(getBounds().x + 1 + paramInt, getBounds().y, getBounds().x + 5 + paramInt, getBounds().y + 4);
    paramGC.drawLine(getBounds().x + 4 + paramInt, getBounds().y + 5, getBounds().x + 1 + paramInt, getBounds().y + 8);
    paramGC.drawPoint(getBounds().x + paramInt, getBounds().y + 7);
    paramGC.drawLine(getBounds().x + paramInt, getBounds().y + 6, getBounds().x + 2 + paramInt, getBounds().y + 4);
    paramGC.drawLine(getBounds().x + 1 + paramInt, getBounds().y + 3, getBounds().x + paramInt, getBounds().y + 2);
    paramGC.drawPoint(getBounds().x + paramInt, getBounds().y + 1);
    paramGC.setForeground(paramColor1);
    paramGC.drawLine(getBounds().x + 1 + paramInt, getBounds().y + 1, getBounds().x + 4 + paramInt, getBounds().y + 4);
    paramGC.drawLine(getBounds().x + 1 + paramInt, getBounds().y + 2, getBounds().x + 3 + paramInt, getBounds().y + 4);
    paramGC.drawLine(getBounds().x + 3 + paramInt, getBounds().y + 5, getBounds().x + 1 + paramInt, getBounds().y + 7);
    paramGC.drawLine(getBounds().x + 2 + paramInt, getBounds().y + 5, getBounds().x + 1 + paramInt, getBounds().y + 6);
  }

  private void drawLeftPointingLine(GC paramGC, Color paramColor1, Color paramColor2, int paramInt)
  {
    paramGC.setForeground(paramColor2);
    paramGC.drawLine(getBounds().x + paramInt, getBounds().y + 4, getBounds().x + 4 + paramInt, getBounds().y);
    paramGC.drawPoint(getBounds().x + 5 + paramInt, getBounds().y + 1);
    paramGC.drawLine(getBounds().x + 5 + paramInt, getBounds().y + 2, getBounds().x + 3 + paramInt, getBounds().y + 4);
    paramGC.drawPoint(getBounds().x + 4 + paramInt, getBounds().y + 5);
    paramGC.drawLine(getBounds().x + 5 + paramInt, getBounds().y + 6, getBounds().x + 5 + paramInt, getBounds().y + 7);
    paramGC.drawLine(getBounds().x + 4 + paramInt, getBounds().y + 8, getBounds().x + 1 + paramInt, getBounds().y + 5);
    paramGC.setForeground(paramColor1);
    paramGC.drawLine(getBounds().x + 1 + paramInt, getBounds().y + 4, getBounds().x + 4 + paramInt, getBounds().y + 1);
    paramGC.drawLine(getBounds().x + 2 + paramInt, getBounds().y + 4, getBounds().x + 4 + paramInt, getBounds().y + 2);
    paramGC.drawLine(getBounds().x + 2 + paramInt, getBounds().y + 5, getBounds().x + 4 + paramInt, getBounds().y + 7);
    paramGC.drawLine(getBounds().x + 2 + paramInt, getBounds().y + 4, getBounds().x + 4 + paramInt, getBounds().y + 6);
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    return new Point(11, 9);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.ExpandToggleRenderer
 * JD-Core Version:    0.6.2
 */