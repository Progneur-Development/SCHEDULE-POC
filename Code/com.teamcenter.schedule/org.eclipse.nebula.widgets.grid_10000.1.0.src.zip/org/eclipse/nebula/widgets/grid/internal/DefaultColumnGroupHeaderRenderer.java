package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridColumnGroup;
import org.eclipse.nebula.widgets.grid.GridHeaderRenderer;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;

public class DefaultColumnGroupHeaderRenderer extends GridHeaderRenderer
{
  int leftMargin = 6;
  int rightMargin = 6;
  int topMargin = 3;
  int bottomMargin = 3;
  int imageSpacing = 3;
  private ExpandToggleRenderer toggleRenderer = new ExpandToggleRenderer();

  public void paint(GC paramGC, Object paramObject)
  {
    GridColumnGroup localGridColumnGroup1 = (GridColumnGroup)paramObject;
    int i = localGridColumnGroup1.getParent().getColumnGroupHeaderDepth();
    if (isSelected())
      paramGC.setBackground(localGridColumnGroup1.getParent().getCellHeaderSelectionBackground());
    else
      paramGC.setBackground(getDisplay().getSystemColor(22));
    paramGC.fillRectangle(getBounds().x, getBounds().y, getBounds().width + 1, getBounds().height + 1);
    int j = this.leftMargin;
    if (localGridColumnGroup1.getImage() != null)
    {
      paramGC.drawImage(localGridColumnGroup1.getImage(), getBounds().x + j, getBounds().y + this.topMargin);
      j += localGridColumnGroup1.getImage().getBounds().width + this.imageSpacing;
    }
    int k = getBounds().width - j - this.rightMargin;
    if ((localGridColumnGroup1.getStyle() & 0x2) != 0)
      k -= this.toggleRenderer.getSize().x;
    paramGC.setForeground(getDisplay().getSystemColor(21));
    int m = getBounds().height;
    Object localObject = localGridColumnGroup1;
    for (int n = 2; ((GridColumnGroup)localObject).getOrderInParentGroup() == 0; n++)
    {
      GridColumnGroup localGridColumnGroup2 = ((GridColumnGroup)localObject).getParentGroup();
      paramGC.drawString(TextUtils.getShortString(paramGC, localGridColumnGroup2.getText(), k), getBounds().x + j, getBounds().y + (i - n) * m / i + this.topMargin);
      localObject = localGridColumnGroup2;
    }
    paramGC.drawString(TextUtils.getShortString(paramGC, localGridColumnGroup1.getText(), k), getBounds().x + j, getBounds().y + (i - 1) * m / i + this.topMargin);
    if ((localGridColumnGroup1.getStyle() & 0x2) != 0)
    {
      this.toggleRenderer.setHover((isHover()) && (getHoverDetail().equals("toggle")));
      this.toggleRenderer.setExpanded(localGridColumnGroup1.getExpanded());
      this.toggleRenderer.setBounds(getToggleBounds());
      this.toggleRenderer.paint(paramGC, null);
    }
    paramGC.setForeground(getDisplay().getSystemColor(17));
    paramGC.drawLine(getBounds().x + getBounds().width - 1, getBounds().y + (i - 1) * m / i, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
    paramGC.drawLine(getBounds().x, getBounds().y + getBounds().height - 1, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
    for (int i1 = 1; i1 < i; i1++)
      paramGC.drawLine(getBounds().x, getBounds().y + i1 * m / i - 1, getBounds().x + getBounds().width - 1, getBounds().y + i1 * m / i - 1);
    n = i - 2;
    localObject = localGridColumnGroup1;
    GridColumnGroup localGridColumnGroup3 = ((GridColumnGroup)localObject).getParentGroup();
    while (localGridColumnGroup3 != null)
      if (((GridColumnGroup)localObject).getOrderInParentGroup() == localGridColumnGroup3.getNumberOfChildGroups() - 1)
      {
        paramGC.drawLine(getBounds().x + getBounds().width - 1, getBounds().y + n * m / i, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height - 1);
        localObject = localGridColumnGroup3;
        localGridColumnGroup3 = ((GridColumnGroup)localObject).getParentGroup();
        n--;
      }
      else
      {
        localGridColumnGroup3 = null;
      }
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    GridColumnGroup localGridColumnGroup = (GridColumnGroup)paramObject;
    int i = 0;
    i += this.leftMargin;
    i += paramGC.stringExtent(localGridColumnGroup.getText()).x + this.rightMargin;
    int j = 0;
    j += this.topMargin;
    j += paramGC.getFontMetrics().getHeight();
    j += this.bottomMargin;
    if (localGridColumnGroup.getImage() != null)
    {
      i += localGridColumnGroup.getImage().getBounds().width + this.imageSpacing;
      j = Math.max(j, this.topMargin + localGridColumnGroup.getImage().getBounds().height + this.bottomMargin);
    }
    return new Point(i, j);
  }

  public boolean notify(int paramInt, Point paramPoint, Object paramObject)
  {
    GridColumnGroup localGridColumnGroup = (GridColumnGroup)paramObject;
    if ((localGridColumnGroup.getStyle() & 0x2) != 0)
      if (paramInt == 3)
      {
        if (getToggleBounds().contains(paramPoint))
        {
          localGridColumnGroup.setExpanded(!localGridColumnGroup.getExpanded());
          if (localGridColumnGroup.getExpanded())
            localGridColumnGroup.notifyListeners(17, new Event());
          else
            localGridColumnGroup.notifyListeners(18, new Event());
          return true;
        }
      }
      else if (getToggleBounds().contains(paramPoint))
      {
        setHoverDetail("toggle");
        return true;
      }
    return false;
  }

  public Rectangle getToggleBounds()
  {
    int i = getBounds().x + getBounds().width - this.toggleRenderer.getBounds().width - this.rightMargin;
    int j = getBounds().y + (getBounds().height - this.toggleRenderer.getBounds().height) / 2;
    return new Rectangle(i, j, this.toggleRenderer.getBounds().width, this.toggleRenderer.getBounds().height);
  }

  public void setDisplay(Display paramDisplay)
  {
    super.setDisplay(paramDisplay);
    this.toggleRenderer.setDisplay(paramDisplay);
  }

  public Rectangle getTextBounds(Object paramObject, boolean paramBoolean)
  {
    GridColumnGroup localGridColumnGroup = (GridColumnGroup)paramObject;
    int i = this.leftMargin;
    if (localGridColumnGroup.getImage() != null)
      i += localGridColumnGroup.getImage().getBounds().width + this.imageSpacing;
    Rectangle localRectangle = new Rectangle(i, this.topMargin, 0, 0);
    GC localGC = new GC(localGridColumnGroup.getParent());
    localGC.setFont(localGridColumnGroup.getParent().getFont());
    Point localPoint = localGC.stringExtent(localGridColumnGroup.getText());
    localRectangle.height = localPoint.y;
    if (paramBoolean)
    {
      localRectangle.width = localPoint.x;
    }
    else
    {
      int j = getBounds().width - i - this.rightMargin;
      if ((localGridColumnGroup.getStyle() & 0x2) != 0)
        j -= this.toggleRenderer.getSize().x;
      localRectangle.width = j;
    }
    localGC.dispose();
    return localRectangle;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.DefaultColumnGroupHeaderRenderer
 * JD-Core Version:    0.6.2
 */