package org.eclipse.nebula.widgets.grid;

import org.eclipse.swt.graphics.Point;

public abstract interface IInternalWidget extends IRenderer
{
  public static final int MouseMove = 5;
  public static final int LeftMouseButtonDown = 3;

  public abstract boolean notify(int paramInt, Point paramPoint, Object paramObject);

  public abstract String getHoverDetail();

  public abstract void setHoverDetail(String paramString);
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.IInternalWidget
 * JD-Core Version:    0.6.2
 */