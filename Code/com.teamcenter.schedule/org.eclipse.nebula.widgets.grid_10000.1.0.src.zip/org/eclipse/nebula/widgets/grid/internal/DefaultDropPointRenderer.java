package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.AbstractRenderer;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class DefaultDropPointRenderer extends AbstractRenderer
{
  public void paint(GC paramGC, Object paramObject)
  {
    paramGC.setBackground(getDisplay().getSystemColor(21));
    paramGC.fillPolygon(new int[] { getBounds().x + 0, getBounds().y + 4, getBounds().x + 4, getBounds().y + 0, getBounds().x + 8, getBounds().y + 4, getBounds().x + 7, getBounds().y + 5, getBounds().x + 6, getBounds().y + 5, getBounds().x + 4, getBounds().y + 3, getBounds().x + 2, getBounds().y + 5, getBounds().x + 1, getBounds().y + 5 });
    paramGC.setForeground(getDisplay().getSystemColor(18));
    paramGC.drawPolyline(new int[] { getBounds().x + 0, getBounds().y + 4, getBounds().x + 4, getBounds().y + 0, getBounds().x + 8, getBounds().y + 4, getBounds().x + 7, getBounds().y + 5, getBounds().x + 6, getBounds().y + 5, getBounds().x + 4, getBounds().y + 3, getBounds().x + 2, getBounds().y + 5, getBounds().x + 1, getBounds().y + 5 });
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    return new Point(9, 7);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.DefaultDropPointRenderer
 * JD-Core Version:    0.6.2
 */