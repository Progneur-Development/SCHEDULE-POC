package org.eclipse.nebula.widgets.grid;

import org.eclipse.nebula.widgets.grid.internal.IScrollBarProxy;
import org.eclipse.swt.custom.ControlEditor;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

class GridHeaderEditor extends ControlEditor
{
  private Grid table;
  private GridColumn column;
  ControlListener columnListener;
  Listener resizeListener;
  private final Listener columnVisibleListener;
  private final Listener columnGroupListener;
  private final SelectionListener scrollListener;
  private final Listener mouseOverListener;

  GridHeaderEditor(final GridColumn paramGridColumn)
  {
    super(paramGridColumn.getParent());
    this.table = paramGridColumn.getParent();
    this.column = paramGridColumn;
    this.columnListener = new ControlListener()
    {
      public void controlMoved(ControlEvent paramAnonymousControlEvent)
      {
        GridHeaderEditor.this.table.getDisplay().asyncExec(new Runnable()
        {
          public void run()
          {
            GridHeaderEditor.this.layout();
          }
        });
      }

      public void controlResized(ControlEvent paramAnonymousControlEvent)
      {
        GridHeaderEditor.this.layout();
      }
    };
    this.columnVisibleListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        GridHeaderEditor.this.getEditor().setVisible(paramGridColumn.isVisible());
        GridHeaderEditor.this.layout();
      }
    };
    this.resizeListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        GridHeaderEditor.this.layout();
      }
    };
    this.scrollListener = new SelectionListener()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        GridHeaderEditor.this.layout();
      }

      public void widgetDefaultSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
      }
    };
    this.columnGroupListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if ((GridHeaderEditor.this.getEditor() == null) || (GridHeaderEditor.this.getEditor().isDisposed()))
          return;
        GridHeaderEditor.this.getEditor().setVisible(paramGridColumn.isVisible());
        GridHeaderEditor.this.layout();
      }
    };
    this.mouseOverListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (GridHeaderEditor.this.table.getCursor() != null)
        {
          GridHeaderEditor.this.table.hoveringOnColumnResizer = false;
          GridHeaderEditor.this.table.setCursor(null);
        }
      }
    };
    this.table.addListener(11, this.resizeListener);
    if (this.table.getVerticalScrollBarProxy() != null)
      this.table.getVerticalScrollBarProxy().addSelectionListener(this.scrollListener);
    if (this.table.getHorizontalScrollBarProxy() != null)
      this.table.getHorizontalScrollBarProxy().addSelectionListener(this.scrollListener);
    this.grabVertical = true;
  }

  protected Rectangle internalComputeBounds()
  {
    this.column.getHeaderRenderer().setBounds(this.column.getBounds());
    return this.column.getHeaderRenderer().getControlBounds(this.column, true);
  }

  public void dispose()
  {
    if ((!this.table.isDisposed()) && (!this.column.isDisposed()))
    {
      this.column.removeControlListener(this.columnListener);
      if (this.column.getColumnGroup() != null)
      {
        this.column.getColumnGroup().removeListener(17, this.columnGroupListener);
        this.column.getColumnGroup().removeListener(18, this.columnGroupListener);
      }
    }
    if (!this.table.isDisposed())
    {
      this.table.removeListener(11, this.resizeListener);
      if (this.table.getVerticalScrollBarProxy() != null)
        this.table.getVerticalScrollBarProxy().removeSelectionListener(this.scrollListener);
      if (this.table.getHorizontalScrollBarProxy() != null)
        this.table.getHorizontalScrollBarProxy().removeSelectionListener(this.scrollListener);
    }
    this.columnListener = null;
    this.resizeListener = null;
    this.table = null;
    super.dispose();
  }

  void initColumn()
  {
    this.column.addControlListener(this.columnListener);
    this.column.addListener(22, this.columnVisibleListener);
    this.column.addListener(23, this.columnVisibleListener);
    if (this.column.getColumnGroup() != null)
    {
      this.column.getColumnGroup().addListener(17, this.columnGroupListener);
      this.column.getColumnGroup().addListener(18, this.columnGroupListener);
    }
    layout();
  }

  public void layout()
  {
    if (this.table.isDisposed())
      return;
    boolean bool = false;
    if ((getEditor() == null) || (getEditor().isDisposed()) || (!this.column.isVisible()))
      return;
    if (getEditor().getVisible())
      bool = getEditor().isFocusControl();
    Rectangle localRectangle = internalComputeBounds();
    if ((localRectangle == null) || (localRectangle.x < 0))
    {
      getEditor().setVisible(false);
      return;
    }
    getEditor().setVisible(true);
    getEditor().setBounds(localRectangle);
    if (bool)
    {
      if ((getEditor() == null) || (getEditor().isDisposed()))
        return;
      getEditor().setFocus();
    }
  }

  public void setEditor(Control paramControl)
  {
    if (getEditor() != null)
      getEditor().removeListener(6, this.mouseOverListener);
    super.setEditor(paramControl);
    if (paramControl != null)
      getEditor().addListener(6, this.mouseOverListener);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridHeaderEditor
 * JD-Core Version:    0.6.2
 */