package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.AbstractRenderer;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class GroupToggleRenderer extends AbstractRenderer
{
  public void paint(GC paramGC, Object paramObject)
  {
    paramGC.setForeground(getDisplay().getSystemColor(17));
    paramGC.setBackground(getDisplay().getSystemColor(18));
    paramGC.fillArc(getBounds().x, getBounds().y, 8, getBounds().height + -1, 90, 180);
    paramGC.drawArc(getBounds().x, getBounds().y, 8, getBounds().height + -1, 90, 180);
    paramGC.fillRectangle(getBounds().x + 4, getBounds().y, getBounds().width - 4, getBounds().height);
    int i = (getBounds().height - 1) / 2;
    if (isHover())
      paramGC.setForeground(getDisplay().getSystemColor(25));
    else
      paramGC.setForeground(getDisplay().getSystemColor(21));
    if (isExpanded())
    {
      paramGC.drawLine(getBounds().x + 5, getBounds().y + i, getBounds().x + 8, getBounds().y + i - 3);
      paramGC.drawLine(getBounds().x + 6, getBounds().y + i, getBounds().x + 8, getBounds().y + i - 2);
      paramGC.drawLine(getBounds().x + 5, getBounds().y + i, getBounds().x + 8, getBounds().y + i + 3);
      paramGC.drawLine(getBounds().x + 6, getBounds().y + i, getBounds().x + 8, getBounds().y + i + 2);
      paramGC.drawLine(getBounds().x + 9, getBounds().y + i, getBounds().x + 12, getBounds().y + i - 3);
      paramGC.drawLine(getBounds().x + 10, getBounds().y + i, getBounds().x + 12, getBounds().y + i - 2);
      paramGC.drawLine(getBounds().x + 9, getBounds().y + i, getBounds().x + 12, getBounds().y + i + 3);
      paramGC.drawLine(getBounds().x + 10, getBounds().y + i, getBounds().x + 12, getBounds().y + i + 2);
    }
    else
    {
      paramGC.drawLine(getBounds().x + getBounds().width - 5, getBounds().y + i, getBounds().x + getBounds().width - 8, getBounds().y + i - 3);
      paramGC.drawLine(getBounds().x + getBounds().width - 6, getBounds().y + i, getBounds().x + getBounds().width - 8, getBounds().y + i - 2);
      paramGC.drawLine(getBounds().x + getBounds().width - 5, getBounds().y + i, getBounds().x + getBounds().width - 8, getBounds().y + i + 3);
      paramGC.drawLine(getBounds().x + getBounds().width - 6, getBounds().y + i, getBounds().x + getBounds().width - 8, getBounds().y + i + 2);
      paramGC.drawLine(getBounds().x + getBounds().width - 9, getBounds().y + i, getBounds().x + getBounds().width - 12, getBounds().y + i - 3);
      paramGC.drawLine(getBounds().x + getBounds().width - 10, getBounds().y + i, getBounds().x + getBounds().width - 12, getBounds().y + i - 2);
      paramGC.drawLine(getBounds().x + getBounds().width - 9, getBounds().y + i, getBounds().x + getBounds().width - 12, getBounds().y + i + 3);
      paramGC.drawLine(getBounds().x + getBounds().width - 10, getBounds().y + i, getBounds().x + getBounds().width - 12, getBounds().y + i + 2);
    }
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    return new Point(0, 0);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.GroupToggleRenderer
 * JD-Core Version:    0.6.2
 */