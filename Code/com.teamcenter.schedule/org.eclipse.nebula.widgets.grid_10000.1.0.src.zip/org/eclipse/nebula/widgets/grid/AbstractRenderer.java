package org.eclipse.nebula.widgets.grid;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public abstract class AbstractRenderer
  implements IRenderer
{
  private boolean hover;
  private boolean focus;
  private boolean mouseDown;
  private boolean selected;
  private boolean expanded;
  private Rectangle bounds = new Rectangle(0, 0, 0, 0);
  private Display display;

  public Rectangle getBounds()
  {
    return this.bounds;
  }

  public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    setBounds(new Rectangle(paramInt1, paramInt2, paramInt3, paramInt4));
  }

  public void setBounds(Rectangle paramRectangle)
  {
    this.bounds = paramRectangle;
  }

  public Point getSize()
  {
    return new Point(this.bounds.width, this.bounds.height);
  }

  public void setLocation(int paramInt1, int paramInt2)
  {
    setBounds(new Rectangle(paramInt1, paramInt2, this.bounds.width, this.bounds.height));
  }

  public void setLocation(Point paramPoint)
  {
    setBounds(new Rectangle(paramPoint.x, paramPoint.y, this.bounds.width, this.bounds.height));
  }

  public void setSize(int paramInt1, int paramInt2)
  {
    setBounds(new Rectangle(this.bounds.x, this.bounds.y, paramInt1, paramInt2));
  }

  public void setSize(Point paramPoint)
  {
    setBounds(new Rectangle(this.bounds.x, this.bounds.y, paramPoint.x, paramPoint.y));
  }

  public boolean isFocus()
  {
    return this.focus;
  }

  public void setFocus(boolean paramBoolean)
  {
    this.focus = paramBoolean;
  }

  public boolean isHover()
  {
    return this.hover;
  }

  public void setHover(boolean paramBoolean)
  {
    this.hover = paramBoolean;
  }

  public boolean isMouseDown()
  {
    return this.mouseDown;
  }

  public void setMouseDown(boolean paramBoolean)
  {
    this.mouseDown = paramBoolean;
  }

  public boolean isSelected()
  {
    return this.selected;
  }

  public void setSelected(boolean paramBoolean)
  {
    this.selected = paramBoolean;
  }

  public boolean isExpanded()
  {
    return this.expanded;
  }

  public void setExpanded(boolean paramBoolean)
  {
    this.expanded = paramBoolean;
  }

  public Display getDisplay()
  {
    return this.display;
  }

  public void setDisplay(Display paramDisplay)
  {
    this.display = paramDisplay;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.AbstractRenderer
 * JD-Core Version:    0.6.2
 */