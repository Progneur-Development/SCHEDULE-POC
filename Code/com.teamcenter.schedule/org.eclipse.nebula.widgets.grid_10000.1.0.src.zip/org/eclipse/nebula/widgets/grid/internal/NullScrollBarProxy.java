package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Event;

public class NullScrollBarProxy
  implements IScrollBarProxy
{
  public boolean getVisible()
  {
    return false;
  }

  public void setVisible(boolean paramBoolean)
  {
  }

  public int getSelection()
  {
    return 0;
  }

  public void setSelection(int paramInt)
  {
  }

  public void setValues(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
  }

  public void handleMouseWheel(Event paramEvent)
  {
  }

  public void setMinimum(int paramInt)
  {
  }

  public int getMinimum()
  {
    return 0;
  }

  public void setMaximum(int paramInt)
  {
  }

  public int getMaximum()
  {
    return 0;
  }

  public void setThumb(int paramInt)
  {
  }

  public int getThumb()
  {
    return 0;
  }

  public void setIncrement(int paramInt)
  {
  }

  public int getIncrement()
  {
    return 0;
  }

  public void setPageIncrement(int paramInt)
  {
  }

  public int getPageIncrement()
  {
    return 0;
  }

  public void addSelectionListener(SelectionListener paramSelectionListener)
  {
  }

  public void removeSelectionListener(SelectionListener paramSelectionListener)
  {
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.NullScrollBarProxy
 * JD-Core Version:    0.6.2
 */