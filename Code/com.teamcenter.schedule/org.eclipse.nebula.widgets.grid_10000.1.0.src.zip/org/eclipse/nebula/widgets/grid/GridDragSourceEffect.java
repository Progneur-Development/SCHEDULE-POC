package org.eclipse.nebula.widgets.grid;

import java.util.ArrayList;
import java.util.List;
import org.eclipse.swt.dnd.DragSourceEffect;
import org.eclipse.swt.dnd.DragSourceEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class GridDragSourceEffect extends DragSourceEffect
{
  Image dragSourceImage = null;

  public GridDragSourceEffect(Grid paramGrid)
  {
    super(paramGrid);
  }

  public void dragFinished(DragSourceEvent paramDragSourceEvent)
  {
    if (this.dragSourceImage != null)
      this.dragSourceImage.dispose();
    this.dragSourceImage = null;
  }

  public void dragStart(DragSourceEvent paramDragSourceEvent)
  {
    paramDragSourceEvent.image = getDragSourceImage(paramDragSourceEvent);
  }

  Image getDragSourceImage(DragSourceEvent paramDragSourceEvent)
  {
    if (this.dragSourceImage != null)
      this.dragSourceImage.dispose();
    this.dragSourceImage = null;
    Grid localGrid = (Grid)getControl();
    Display localDisplay = localGrid.getDisplay();
    Rectangle localRectangle1 = new Rectangle(0, 0, 0, 0);
    Point[] arrayOfPoint;
    if (localGrid.getCellSelectionEnabled())
    {
      arrayOfPoint = localGrid.getCellSelection();
    }
    else
    {
      localObject1 = new ArrayList();
      GridItem[] arrayOfGridItem = localGrid.getSelection();
      for (int j = 0; j < arrayOfGridItem.length; j++)
        for (int m = 0; m < localGrid.getColumnCount(); m++)
          if (localGrid.getColumn(m).isVisible())
            ((List)localObject1).add(new Point(m, localGrid.indexOf(arrayOfGridItem[j])));
      arrayOfPoint = (Point[])((List)localObject1).toArray(new Point[((List)localObject1).size()]);
    }
    if (arrayOfPoint.length == 0)
      return null;
    Object localObject1 = null;
    Object localObject2;
    for (int i = 0; i < arrayOfPoint.length; i++)
    {
      GridItem localGridItem = localGrid.getItem(arrayOfPoint[i].y);
      localObject2 = localGridItem.getBounds(arrayOfPoint[i].x);
      if (localRectangle1.equals(localObject2))
        arrayOfPoint[i] = null;
      else if (localObject1 == null)
        localObject1 = localObject2;
      else
        localObject1 = ((Rectangle)localObject1).union((Rectangle)localObject2);
    }
    if (localObject1 == null)
      return null;
    this.dragSourceImage = new Image(localDisplay, ((Rectangle)localObject1).width, ((Rectangle)localObject1).height);
    GC localGC = new GC(this.dragSourceImage);
    for (int k = 0; k < arrayOfPoint.length; k++)
      if (arrayOfPoint[k] != null)
      {
        localObject2 = localGrid.getItem(arrayOfPoint[k].y);
        GridColumn localGridColumn = localGrid.getColumn(arrayOfPoint[k].x);
        Rectangle localRectangle2 = ((GridItem)localObject2).getBounds(arrayOfPoint[k].x);
        GridCellRenderer localGridCellRenderer = localGridColumn.getCellRenderer();
        localGridCellRenderer.setBounds(localRectangle2.x - ((Rectangle)localObject1).x, localRectangle2.y - ((Rectangle)localObject1).y, localRectangle2.width, localRectangle2.height);
        localGC.setClipping(localRectangle2.x - ((Rectangle)localObject1).x - 1, localRectangle2.y - ((Rectangle)localObject1).y - 1, localRectangle2.width + 2, localRectangle2.height + 2);
        localGridCellRenderer.setColumn(arrayOfPoint[k].x);
        localGridCellRenderer.setSelected(false);
        localGridCellRenderer.setFocus(false);
        localGridCellRenderer.setRowFocus(false);
        localGridCellRenderer.setCellFocus(false);
        localGridCellRenderer.setRowHover(false);
        localGridCellRenderer.setColumnHover(false);
        localGridCellRenderer.setCellSelected(false);
        localGridCellRenderer.setHoverDetail("");
        localGridCellRenderer.setDragging(true);
        localGridCellRenderer.paint(localGC, localObject2);
        localGC.setClipping(null);
      }
    localGC.dispose();
    return this.dragSourceImage;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridDragSourceEffect
 * JD-Core Version:    0.6.2
 */