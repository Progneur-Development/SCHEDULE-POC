package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.AbstractRenderer;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class CheckBoxRenderer extends AbstractRenderer
{
  private boolean checked = false;
  private boolean grayed = false;

  public CheckBoxRenderer()
  {
    setSize(13, 13);
  }

  public void paint(GC paramGC, Object paramObject)
  {
    if (isGrayed())
      paramGC.setBackground(getDisplay().getSystemColor(22));
    else
      paramGC.setBackground(getDisplay().getSystemColor(25));
    paramGC.fillRectangle(getBounds());
    paramGC.setForeground(getDisplay().getSystemColor(21));
    paramGC.drawRectangle(getBounds().x, getBounds().y, getBounds().width - 1, getBounds().height - 1);
    paramGC.drawRectangle(getBounds().x + 1, getBounds().y + 1, getBounds().width - 3, getBounds().height - 3);
    if (isGrayed())
      paramGC.setForeground(getDisplay().getSystemColor(18));
    if (isChecked())
    {
      paramGC.drawLine(getBounds().x + 3, getBounds().y + 5, getBounds().x + 6, getBounds().y + 8);
      paramGC.drawLine(getBounds().x + 3, getBounds().y + 6, getBounds().x + 5, getBounds().y + 8);
      paramGC.drawLine(getBounds().x + 3, getBounds().y + 7, getBounds().x + 5, getBounds().y + 9);
      paramGC.drawLine(getBounds().x + 9, getBounds().y + 3, getBounds().x + 6, getBounds().y + 6);
      paramGC.drawLine(getBounds().x + 9, getBounds().y + 4, getBounds().x + 6, getBounds().y + 7);
      paramGC.drawLine(getBounds().x + 9, getBounds().y + 5, getBounds().x + 7, getBounds().y + 7);
    }
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    return getSize();
  }

  public boolean isChecked()
  {
    return this.checked;
  }

  public void setChecked(boolean paramBoolean)
  {
    this.checked = paramBoolean;
  }

  public boolean isGrayed()
  {
    return this.grayed;
  }

  public void setGrayed(boolean paramBoolean)
  {
    this.grayed = paramBoolean;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.CheckBoxRenderer
 * JD-Core Version:    0.6.2
 */