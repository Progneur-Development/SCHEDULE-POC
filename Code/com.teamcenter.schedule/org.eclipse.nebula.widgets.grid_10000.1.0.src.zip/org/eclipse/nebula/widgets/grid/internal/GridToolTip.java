package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Widget;

public class GridToolTip extends Widget
{
  private Shell shell;
  private String text;
  private int ymargin = 2;
  private int xmargin = 3;

  public GridToolTip(Control paramControl)
  {
    super(paramControl, 0);
    this.shell = new Shell(paramControl.getShell(), 540684);
    this.shell.setBackground(this.shell.getDisplay().getSystemColor(29));
    this.shell.setForeground(this.shell.getDisplay().getSystemColor(28));
    paramControl.addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        GridToolTip.this.shell.dispose();
        GridToolTip.this.dispose();
      }
    });
    this.shell.addListener(9, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        GridToolTip.this.onPaint(paramAnonymousEvent.gc);
      }
    });
  }

  private void onPaint(GC paramGC)
  {
    paramGC.drawRectangle(0, 0, this.shell.getSize().x - 1, this.shell.getSize().y - 1);
    paramGC.drawString(this.text, this.xmargin, this.ymargin, true);
  }

  public void setLocation(Point paramPoint)
  {
    this.shell.setLocation(paramPoint.x - this.xmargin, paramPoint.y - this.ymargin);
  }

  public void setVisible(boolean paramBoolean)
  {
    if ((paramBoolean) && (this.shell.getVisible()))
      this.shell.redraw();
    else
      this.shell.setVisible(paramBoolean);
  }

  public void setFont(Font paramFont)
  {
    this.shell.setFont(paramFont);
  }

  public String getText()
  {
    return this.text;
  }

  public void setText(String paramString)
  {
    this.text = paramString;
    GC localGC = new GC(this.shell);
    Point localPoint = localGC.stringExtent(paramString);
    localGC.dispose();
    localPoint.x += this.xmargin + this.xmargin;
    localPoint.y += this.ymargin + this.ymargin;
    this.shell.setSize(localPoint);
  }

  protected void checkSubclass()
  {
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.GridToolTip
 * JD-Core Version:    0.6.2
 */