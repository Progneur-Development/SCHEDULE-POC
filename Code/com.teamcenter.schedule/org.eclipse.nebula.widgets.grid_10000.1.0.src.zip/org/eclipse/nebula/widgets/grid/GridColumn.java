package org.eclipse.nebula.widgets.grid;

import org.eclipse.nebula.widgets.grid.internal.DefaultCellRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultColumnFooterRenderer;
import org.eclipse.nebula.widgets.grid.internal.DefaultColumnHeaderRenderer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.TypedListener;

public class GridColumn extends Item
{
  private GridHeaderEditor controlEditor;
  private static final int DEFAULT_WIDTH = 10;
  private Grid parent;
  private GridHeaderRenderer headerRenderer = new DefaultColumnHeaderRenderer();
  private GridFooterRenderer footerRenderer = new DefaultColumnFooterRenderer();
  private GridCellRenderer cellRenderer = new DefaultCellRenderer();
  private int width = 10;
  private int sortStyle = 0;
  private boolean tree = false;
  private boolean check = false;
  private boolean tableCheck = false;
  private boolean resizeable = true;
  private boolean moveable = false;
  private boolean frozen = false;
  private boolean summary = true;
  private boolean detail = true;
  private boolean visible = true;
  private boolean cellSelectionEnabled = true;
  private GridColumnGroup group;
  private boolean checkable = true;
  private Image footerImage;
  private String footerText = "";

  public GridColumn(Grid paramGrid, int paramInt)
  {
    this(paramGrid, paramInt, -1);
  }

  public GridColumn(Grid paramGrid, int paramInt1, int paramInt2)
  {
    super(paramGrid, paramInt1, paramInt2);
    init(paramGrid, paramInt1, paramInt2);
  }

  public GridColumn(GridColumnGroup paramGridColumnGroup, int paramInt)
  {
    super(paramGridColumnGroup.getParent(), paramInt, paramGridColumnGroup.getNewColumnIndex());
    init(paramGridColumnGroup.getParent(), paramInt, paramGridColumnGroup.getNewColumnIndex());
    this.group = paramGridColumnGroup;
    this.group.newColumn(this, -1);
  }

  private void init(Grid paramGrid, int paramInt1, int paramInt2)
  {
    this.parent = paramGrid;
    paramGrid.newColumn(this, paramInt2);
    if ((paramInt1 & 0x20) == 32)
      this.check = true;
    initHeaderRenderer();
    initFooterRenderer();
    initCellRenderer();
  }

  public void dispose()
  {
    if (!this.parent.isDisposing())
    {
      this.parent.removeColumn(this);
      if (this.group != null)
        this.group.removeColumn(this);
    }
    super.dispose();
  }

  public void setGroup(GridColumnGroup paramGridColumnGroup)
  {
    this.group = paramGridColumnGroup;
    this.group.newColumn(this, -1);
  }

  private void initHeaderRenderer()
  {
    this.headerRenderer.setDisplay(getDisplay());
  }

  private void initFooterRenderer()
  {
    this.footerRenderer.setDisplay(getDisplay());
  }

  private void initCellRenderer()
  {
    this.cellRenderer.setDisplay(getDisplay());
    this.cellRenderer.setCheck(this.check);
    this.cellRenderer.setTree(this.tree);
    this.cellRenderer.setColumn(this.parent.indexOf(this));
    if ((getStyle() & 0x20000) == 131072)
      this.cellRenderer.setAlignment(131072);
    if ((getStyle() & 0x1000000) == 16777216)
      this.cellRenderer.setAlignment(16777216);
  }

  GridHeaderRenderer getHeaderRenderer()
  {
    return this.headerRenderer;
  }

  GridFooterRenderer getFooterRenderer()
  {
    return this.footerRenderer;
  }

  GridCellRenderer getCellRenderer()
  {
    return this.cellRenderer;
  }

  public int getWidth()
  {
    checkWidget();
    return this.width;
  }

  public void setWidth(int paramInt)
  {
    checkWidget();
    setWidth(paramInt, true);
  }

  void setWidth(int paramInt, boolean paramBoolean)
  {
    this.width = paramInt;
    if (paramBoolean)
    {
      this.parent.setScrollValuesObsolete();
      this.parent.redraw();
    }
  }

  public void setSort(int paramInt)
  {
    checkWidget();
    this.sortStyle = paramInt;
    this.parent.redraw();
  }

  public int getSort()
  {
    checkWidget();
    return this.sortStyle;
  }

  public void addSelectionListener(SelectionListener paramSelectionListener)
  {
    checkWidget();
    if (paramSelectionListener == null)
      SWT.error(4);
    addListener(13, new TypedListener(paramSelectionListener));
  }

  public void removeSelectionListener(SelectionListener paramSelectionListener)
  {
    checkWidget();
    removeListener(13, paramSelectionListener);
  }

  void fireListeners()
  {
    Event localEvent = new Event();
    localEvent.display = getDisplay();
    localEvent.item = this;
    localEvent.widget = this.parent;
    notifyListeners(13, localEvent);
  }

  public boolean isVisible()
  {
    checkWidget();
    if ((this.group != null) && (((this.group.getExpanded()) && (!isDetail())) || ((!this.group.getExpanded()) && (!isSummary()))))
      return false;
    if (this.parent.getHiddenByFreeze(this))
      return false;
    return this.visible;
  }

  public boolean getVisible()
  {
    checkWidget();
    return this.visible;
  }

  public void setVisible(boolean paramBoolean)
  {
    checkWidget();
    boolean bool = isVisible();
    this.visible = paramBoolean;
    if (isVisible() != bool)
    {
      if (paramBoolean)
        notifyListeners(22, new Event());
      else
        notifyListeners(23, new Event());
      GridColumn[] arrayOfGridColumn1 = this.parent.getColumnsInOrder();
      for (GridColumn localGridColumn : arrayOfGridColumn1)
        if ((localGridColumn != this) && (localGridColumn.isVisible()))
          localGridColumn.fireMoved();
      this.parent.redraw();
    }
  }

  public void pack()
  {
    checkWidget();
    GC localGC = new GC(this.parent);
    int i = getHeaderRenderer().computeSize(localGC, -1, -1, this).x;
    GridItem[] arrayOfGridItem1 = this.parent.getItems();
    for (GridItem localGridItem : arrayOfGridItem1)
      if (localGridItem.isVisible())
        i = Math.max(i, getCellRenderer().computeSize(localGC, -1, -1, localGridItem).x);
    localGC.dispose();
    setWidth(i);
    this.parent.redraw();
  }

  public boolean isTree()
  {
    checkWidget();
    return this.tree;
  }

  public boolean isCheck()
  {
    checkWidget();
    return (this.check) || (this.tableCheck);
  }

  public void setCellRenderer(GridCellRenderer paramGridCellRenderer)
  {
    checkWidget();
    this.cellRenderer = paramGridCellRenderer;
    initCellRenderer();
  }

  public void setHeaderRenderer(GridHeaderRenderer paramGridHeaderRenderer)
  {
    checkWidget();
    this.headerRenderer = paramGridHeaderRenderer;
    initHeaderRenderer();
  }

  public void setFooterRenderer(GridFooterRenderer paramGridFooterRenderer)
  {
    checkWidget();
    this.footerRenderer = paramGridFooterRenderer;
    initFooterRenderer();
  }

  public void addControlListener(ControlListener paramControlListener)
  {
    checkWidget();
    if (paramControlListener == null)
      SWT.error(4);
    TypedListener localTypedListener = new TypedListener(paramControlListener);
    addListener(11, localTypedListener);
    addListener(10, localTypedListener);
  }

  public void removeControlListener(ControlListener paramControlListener)
  {
    checkWidget();
    if (paramControlListener == null)
      SWT.error(4);
    removeListener(11, paramControlListener);
    removeListener(10, paramControlListener);
  }

  void fireMoved()
  {
    Event localEvent = new Event();
    localEvent.display = getDisplay();
    localEvent.item = this;
    localEvent.widget = this.parent;
    notifyListeners(10, localEvent);
  }

  void fireResized()
  {
    Event localEvent = new Event();
    localEvent.display = getDisplay();
    localEvent.item = this;
    localEvent.widget = this.parent;
    notifyListeners(11, localEvent);
  }

  public void setTree(boolean paramBoolean)
  {
    checkWidget();
    this.tree = paramBoolean;
    this.cellRenderer.setTree(paramBoolean);
    this.parent.redraw();
  }

  public int getAlignment()
  {
    checkWidget();
    return this.cellRenderer.getAlignment();
  }

  public void setAlignment(int paramInt)
  {
    checkWidget();
    this.cellRenderer.setAlignment(paramInt);
  }

  public boolean getMoveable()
  {
    checkWidget();
    return this.moveable;
  }

  public void setMoveable(boolean paramBoolean)
  {
    checkWidget();
    this.moveable = paramBoolean;
    this.parent.redraw();
  }

  public boolean getFrozen()
  {
    checkWidget();
    return this.frozen;
  }

  public void setFrozen(boolean paramBoolean)
  {
    checkWidget();
    this.frozen = paramBoolean;
    this.parent.redraw();
  }

  public boolean getResizeable()
  {
    checkWidget();
    return this.resizeable;
  }

  public void setResizeable(boolean paramBoolean)
  {
    checkWidget();
    this.resizeable = paramBoolean;
  }

  public GridColumnGroup getColumnGroup()
  {
    checkWidget();
    return this.group;
  }

  public boolean isDetail()
  {
    checkWidget();
    return this.detail;
  }

  public void setDetail(boolean paramBoolean)
  {
    checkWidget();
    this.detail = paramBoolean;
  }

  public boolean isSummary()
  {
    checkWidget();
    return this.summary;
  }

  public void setSummary(boolean paramBoolean)
  {
    checkWidget();
    this.summary = paramBoolean;
  }

  Rectangle getBounds()
  {
    Rectangle localRectangle = new Rectangle(0, 0, 0, 0);
    if (!isVisible())
      return localRectangle;
    Point localPoint = this.parent.getOrigin(this, null);
    localRectangle.x = localPoint.x;
    localRectangle.y = localPoint.y;
    localRectangle.width = getWidth();
    localRectangle.height = this.parent.getHeaderHeight();
    if (getColumnGroup() != null)
      localRectangle.height -= this.parent.getGroupHeaderHeight();
    return localRectangle;
  }

  protected boolean isTableCheck()
  {
    return this.tableCheck;
  }

  protected void setTableCheck(boolean paramBoolean)
  {
    this.tableCheck = paramBoolean;
    this.cellRenderer.setCheck((paramBoolean) || (this.check));
  }

  public boolean getCellSelectionEnabled()
  {
    checkWidget();
    return this.cellSelectionEnabled;
  }

  public void setCellSelectionEnabled(boolean paramBoolean)
  {
    checkWidget();
    this.cellSelectionEnabled = paramBoolean;
  }

  public Grid getParent()
  {
    checkWidget();
    return this.parent;
  }

  public boolean getCheckable()
  {
    checkWidget();
    return this.checkable;
  }

  public void setCheckable(boolean paramBoolean)
  {
    checkWidget();
    this.checkable = paramBoolean;
  }

  void setColumnIndex(int paramInt)
  {
    this.cellRenderer.setColumn(paramInt);
  }

  public boolean getWordWrap()
  {
    checkWidget();
    return this.cellRenderer.isWordWrap();
  }

  public void setWordWrap(boolean paramBoolean)
  {
    checkWidget();
    this.cellRenderer.setWordWrap(paramBoolean);
    this.parent.redraw();
  }

  public void setHeaderControl(Control paramControl)
  {
    if (this.controlEditor == null)
    {
      this.controlEditor = new GridHeaderEditor(this);
      this.controlEditor.initColumn();
    }
    if (paramControl == null)
      this.controlEditor.setEditor(null);
    else
      this.controlEditor.setEditor(paramControl);
    getParent().recalculateHeader();
    if (paramControl != null)
      paramControl.getDisplay().asyncExec(new Runnable()
      {
        public void run()
        {
          if ((GridColumn.this.controlEditor != null) && (GridColumn.this.controlEditor.getEditor() != null))
            GridColumn.this.controlEditor.layout();
        }
      });
  }

  public Control getHeaderControl()
  {
    if (this.controlEditor != null)
      return this.controlEditor.getEditor();
    return null;
  }

  public void setFooterImage(Image paramImage)
  {
    checkWidget();
    if ((paramImage != null) && (paramImage.isDisposed()))
      SWT.error(5);
    this.footerImage = paramImage;
  }

  public void setFooterText(String paramString)
  {
    checkWidget();
    if (paramString == null)
      SWT.error(4);
    this.footerText = paramString;
  }

  public Image getFooterImage()
  {
    checkWidget();
    return this.footerImage;
  }

  public String getFooterText()
  {
    checkWidget();
    return this.footerText;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridColumn
 * JD-Core Version:    0.6.2
 */