package org.eclipse.nebula.widgets.grid;

import org.eclipse.swt.graphics.Rectangle;

public abstract class GridFooterRenderer extends AbstractInternalWidget
{
  public Rectangle getTextBounds(Object paramObject, boolean paramBoolean)
  {
    return null;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridFooterRenderer
 * JD-Core Version:    0.6.2
 */