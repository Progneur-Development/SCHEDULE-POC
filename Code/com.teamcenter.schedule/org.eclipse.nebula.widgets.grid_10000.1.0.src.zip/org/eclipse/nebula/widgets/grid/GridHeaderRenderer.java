package org.eclipse.nebula.widgets.grid;

import org.eclipse.swt.graphics.Rectangle;

public abstract class GridHeaderRenderer extends AbstractInternalWidget
{
  public Rectangle getTextBounds(Object paramObject, boolean paramBoolean)
  {
    return null;
  }

  public Rectangle getToggleBounds()
  {
    return null;
  }

  protected Rectangle getControlBounds(Object paramObject, boolean paramBoolean)
  {
    return null;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridHeaderRenderer
 * JD-Core Version:    0.6.2
 */