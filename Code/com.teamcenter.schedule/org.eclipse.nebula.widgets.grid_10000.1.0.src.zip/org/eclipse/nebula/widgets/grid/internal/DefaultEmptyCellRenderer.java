package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridCellRenderer;
import org.eclipse.nebula.widgets.grid.GridItem;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class DefaultEmptyCellRenderer extends GridCellRenderer
{
  public void paint(GC paramGC, Object paramObject)
  {
    Grid localGrid = null;
    if ((paramObject instanceof Grid))
      localGrid = (Grid)paramObject;
    if ((paramObject instanceof GridItem))
    {
      GridItem localGridItem = (GridItem)paramObject;
      localGrid = localGridItem.getParent();
    }
    int i = 1;
    if (isSelected())
    {
      paramGC.setBackground(getDisplay().getSystemColor(26));
      paramGC.setForeground(getDisplay().getSystemColor(27));
    }
    else
    {
      if (localGrid.isEnabled())
        i = 0;
      else
        paramGC.setBackground(getDisplay().getSystemColor(22));
      paramGC.setForeground(localGrid.getForeground());
    }
    if (i != 0)
      paramGC.fillRectangle(getBounds().x, getBounds().y, getBounds().width + 1, getBounds().height);
    if (localGrid.getLinesVisible())
    {
      paramGC.setForeground(localGrid.getLineColor());
      paramGC.drawLine(getBounds().x, getBounds().y + getBounds().height, getBounds().x + getBounds().width, getBounds().y + getBounds().height);
      paramGC.drawLine(getBounds().x + getBounds().width - 1, getBounds().y, getBounds().x + getBounds().width - 1, getBounds().y + getBounds().height);
    }
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    return new Point(paramInt1, paramInt2);
  }

  public boolean notify(int paramInt, Point paramPoint, Object paramObject)
  {
    return false;
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.DefaultEmptyCellRenderer
 * JD-Core Version:    0.6.2
 */