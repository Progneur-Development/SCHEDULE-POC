package org.eclipse.nebula.widgets.grid.internal;

import org.eclipse.nebula.widgets.grid.AbstractRenderer;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class DefaultInsertMarkRenderer extends AbstractRenderer
{
  public void paint(GC paramGC, Object paramObject)
  {
    Rectangle localRectangle = (Rectangle)paramObject;
    paramGC.setLineStyle(1);
    paramGC.setForeground(getDisplay().getSystemColor(26));
    paramGC.drawLine(localRectangle.x, localRectangle.y - 1, localRectangle.x + localRectangle.width, localRectangle.y - 1);
    paramGC.drawLine(localRectangle.x, localRectangle.y, localRectangle.x + localRectangle.width, localRectangle.y);
    paramGC.drawLine(localRectangle.x, localRectangle.y + 1, localRectangle.x + localRectangle.width, localRectangle.y + 1);
    paramGC.drawLine(localRectangle.x - 1, localRectangle.y - 2, localRectangle.x - 1, localRectangle.y + 2);
    paramGC.drawLine(localRectangle.x - 2, localRectangle.y - 3, localRectangle.x - 2, localRectangle.y + 3);
  }

  public Point computeSize(GC paramGC, int paramInt1, int paramInt2, Object paramObject)
  {
    return new Point(9, 7);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.internal.DefaultInsertMarkRenderer
 * JD-Core Version:    0.6.2
 */