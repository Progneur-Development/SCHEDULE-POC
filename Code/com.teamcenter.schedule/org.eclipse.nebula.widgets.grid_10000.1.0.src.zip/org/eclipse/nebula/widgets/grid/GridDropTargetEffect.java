package org.eclipse.nebula.widgets.grid;

import org.eclipse.swt.dnd.DropTargetEffect;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Widget;

public class GridDropTargetEffect extends DropTargetEffect
{
  static final int SCROLL_HYSTERESIS = 200;
  static final int EXPAND_HYSTERESIS = 1000;
  private Grid grid;
  private boolean ignoreCellSelection = false;
  private GridItem scrollItem;
  private long scrollBeginTime;
  private GridItem expandItem;
  private long expandBeginTime;
  private Point insertCell;
  private boolean insertBefore;
  private Point selectedCell;

  public GridDropTargetEffect(Grid paramGrid)
  {
    super(paramGrid);
    this.grid = paramGrid;
  }

  public void setIgnoreCellSelection(boolean paramBoolean)
  {
    this.ignoreCellSelection = paramBoolean;
  }

  public boolean getIgnoreCellSelection()
  {
    return this.ignoreCellSelection;
  }

  int checkEffect(int paramInt)
  {
    if ((paramInt & 0x1) != 0)
      paramInt = paramInt & 0xFFFFFFFB & 0xFFFFFFFD;
    if ((paramInt & 0x2) != 0)
      paramInt &= -5;
    return paramInt;
  }

  public Widget getItem(int paramInt1, int paramInt2)
  {
    Point localPoint = new Point(paramInt1, paramInt2);
    localPoint = this.grid.toControl(localPoint);
    return this.grid.getItem(localPoint);
  }

  public void dragEnter(DropTargetEvent paramDropTargetEvent)
  {
    this.expandBeginTime = 0L;
    this.expandItem = null;
    this.scrollBeginTime = 0L;
    this.scrollItem = null;
    this.insertCell = null;
    this.selectedCell = null;
  }

  public void dragLeave(DropTargetEvent paramDropTargetEvent)
  {
    if (this.selectedCell != null)
    {
      deselect(this.selectedCell);
      this.selectedCell = null;
    }
    if (this.insertCell != null)
    {
      setInsertMark(null, false);
      this.insertCell = null;
    }
    this.expandBeginTime = 0L;
    this.expandItem = null;
    this.scrollBeginTime = 0L;
    this.scrollItem = null;
  }

  public void dragOver(DropTargetEvent paramDropTargetEvent)
  {
    int i = checkEffect(paramDropTargetEvent.feedback);
    Point localPoint1 = new Point(paramDropTargetEvent.x, paramDropTargetEvent.y);
    localPoint1 = this.grid.toControl(localPoint1);
    GridItem localGridItem1 = this.grid.getItem(localPoint1);
    GridColumn localGridColumn = this.grid.getColumn(localPoint1);
    Point localPoint2 = this.grid.getCell(localPoint1);
    if ((localGridItem1 == null) || (localGridColumn == null) || (localPoint2 == null))
    {
      localGridItem1 = null;
      localGridColumn = null;
      localPoint2 = null;
    }
    if ((i & 0x8) == 0)
    {
      this.scrollBeginTime = 0L;
      this.scrollItem = null;
    }
    else if ((localGridItem1 != null) && (this.scrollItem == localGridItem1) && (this.scrollBeginTime != 0L))
    {
      if (System.currentTimeMillis() >= this.scrollBeginTime)
      {
        GridItem localGridItem2 = this.grid.getItem(this.grid.getTopIndex());
        GridItem localGridItem3 = localGridItem1 == localGridItem2 ? this.grid.getPreviousVisibleItem(localGridItem1) : this.grid.getNextVisibleItem(localGridItem1);
        int j = (localGridItem3 != null) && (this.grid.isInDragScrollArea(localPoint1)) ? 1 : 0;
        if (j != 0)
          this.grid.showItem(localGridItem3);
        this.scrollBeginTime = 0L;
        this.scrollItem = null;
      }
    }
    else
    {
      this.scrollBeginTime = (System.currentTimeMillis() + 200L);
      this.scrollItem = localGridItem1;
    }
    if ((i & 0x10) == 0)
    {
      this.expandBeginTime = 0L;
      this.expandItem = null;
    }
    else if ((localGridItem1 != null) && (this.expandItem == localGridItem1) && (this.expandBeginTime != 0L))
    {
      if (System.currentTimeMillis() >= this.expandBeginTime)
      {
        if ((localGridColumn.isTree()) && (!localGridItem1.isExpanded()))
        {
          localGridItem1.setExpanded(true);
          if (localGridItem1.hasChildren())
            localGridItem1.fireEvent(17);
        }
        this.expandBeginTime = 0L;
        this.expandItem = null;
      }
    }
    else
    {
      this.expandBeginTime = (System.currentTimeMillis() + 1000L);
      this.expandItem = localGridItem1;
    }
    if (((i & 0x1) != 0) && (localPoint2 != null) && (!localPoint2.equals(this.selectedCell)))
    {
      if (this.selectedCell != null)
        deselect(this.selectedCell);
      select(localPoint2);
      this.selectedCell = new Point(localPoint2.x, localPoint2.y);
    }
    if (((i & 0x1) == 0) && (this.selectedCell != null))
    {
      deselect(this.selectedCell);
      this.selectedCell = null;
    }
    if (((i & 0x2) != 0) || ((i & 0x4) != 0))
    {
      boolean bool = (i & 0x2) != 0;
      if (localPoint2 != null)
      {
        if ((!localPoint2.equals(this.insertCell)) || (bool != this.insertBefore))
          setInsertMark(localPoint2, bool);
        this.insertCell = new Point(localPoint2.x, localPoint2.y);
        this.insertBefore = bool;
      }
      else
      {
        if (this.insertCell != null)
          setInsertMark(null, false);
        this.insertCell = null;
      }
    }
    else
    {
      if (this.insertCell != null)
        setInsertMark(null, false);
      this.insertCell = null;
    }
  }

  private void select(Point paramPoint)
  {
    if ((this.grid.getCellSelectionEnabled()) && (!this.ignoreCellSelection))
      this.grid.selectCell(paramPoint);
    else
      this.grid.select(paramPoint.y);
  }

  private void deselect(Point paramPoint)
  {
    if ((this.grid.getCellSelectionEnabled()) && (!this.ignoreCellSelection))
      this.grid.deselectCell(paramPoint);
    else
      this.grid.deselect(paramPoint.y);
  }

  private void setInsertMark(Point paramPoint, boolean paramBoolean)
  {
    if (paramPoint != null)
    {
      if ((this.grid.getCellSelectionEnabled()) && (!this.ignoreCellSelection))
        this.grid.setInsertMark(this.grid.getItem(paramPoint.y), this.grid.getColumn(paramPoint.x), paramBoolean);
      else
        this.grid.setInsertMark(this.grid.getItem(paramPoint.y), null, paramBoolean);
    }
    else
      this.grid.setInsertMark(null, null, false);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridDropTargetEffect
 * JD-Core Version:    0.6.2
 */