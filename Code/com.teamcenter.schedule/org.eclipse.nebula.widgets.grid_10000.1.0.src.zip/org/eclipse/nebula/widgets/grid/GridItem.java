package org.eclipse.nebula.widgets.grid;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.TypedListener;

public class GridItem extends Item
{
  private ArrayList backgrounds = new ArrayList();
  private ArrayList checks = new ArrayList();
  private ArrayList checkable = new ArrayList();
  private ArrayList children = new ArrayList();
  private ArrayList columnSpans = new ArrayList();
  private Color defaultBackground;
  private Font defaultFont;
  private Color defaultForeground;
  private int height = 1;
  private boolean expanded = false;
  private ArrayList fonts = new ArrayList();
  private ArrayList foregrounds = new ArrayList();
  private ArrayList grayeds = new ArrayList();
  private boolean hasChildren = false;
  private ArrayList images = new ArrayList();
  private int level = 0;
  private Grid parent;
  private GridItem parentItem;
  private ArrayList texts = new ArrayList();
  private ArrayList tooltips = new ArrayList();
  private boolean visible = true;
  private String headerText = null;
  private Image headerImage = null;
  private boolean hasSetData = false;

  public GridItem(Grid paramGrid, int paramInt)
  {
    this(paramGrid, paramInt, -1);
  }

  public GridItem(Grid paramGrid, int paramInt1, int paramInt2)
  {
    super(paramGrid, paramInt1, paramInt2);
    this.parent = paramGrid;
    init();
    paramGrid.newItem(this, paramInt2, true);
    paramGrid.newRootItem(this, paramInt2);
  }

  public GridItem(GridItem paramGridItem, int paramInt)
  {
    this(paramGridItem, paramInt, -1);
  }

  public GridItem(GridItem paramGridItem, int paramInt1, int paramInt2)
  {
    super(paramGridItem, paramInt1, paramInt2);
    this.parentItem = paramGridItem;
    this.parent = this.parentItem.getParent();
    init();
    this.parent.newItem(this, paramInt2, false);
    this.level = (this.parentItem.getLevel() + 1);
    this.parentItem.newItem(this, paramInt2);
    if ((paramGridItem.isVisible()) && (paramGridItem.isExpanded()))
      setVisible(true);
    else
      setVisible(false);
  }

  public void dispose()
  {
    if (!this.parent.isDisposing())
    {
      this.parent.removeItem(this);
      if (this.parentItem != null)
        this.parentItem.remove(this);
      else
        this.parent.removeRootItem(this);
      for (int i = this.children.size() - 1; i >= 0; i--)
        ((GridItem)this.children.get(i)).dispose();
    }
    super.dispose();
  }

  public void addControlListener(ControlListener paramControlListener)
  {
    checkWidget();
    if (paramControlListener == null)
      SWT.error(4);
    TypedListener localTypedListener = new TypedListener(paramControlListener);
    addListener(11, localTypedListener);
  }

  public void removeControlListener(ControlListener paramControlListener)
  {
    checkWidget();
    if (paramControlListener == null)
      SWT.error(4);
    removeListener(11, paramControlListener);
  }

  public void fireEvent(int paramInt)
  {
    checkWidget();
    Event localEvent = new Event();
    localEvent.display = getDisplay();
    localEvent.widget = this;
    localEvent.item = this;
    localEvent.type = paramInt;
    getParent().notifyListeners(paramInt, localEvent);
  }

  public void fireCheckEvent(int paramInt)
  {
    checkWidget();
    Event localEvent = new Event();
    localEvent.display = getDisplay();
    localEvent.widget = this;
    localEvent.item = this;
    localEvent.type = 13;
    localEvent.detail = 32;
    localEvent.index = paramInt;
    getParent().notifyListeners(13, localEvent);
  }

  public Color getBackground()
  {
    checkWidget();
    if (this.defaultBackground == null)
      return this.parent.getBackground();
    return this.defaultBackground;
  }

  public Color getBackground(int paramInt)
  {
    checkWidget();
    handleVirtual();
    Color localColor = (Color)this.backgrounds.get(paramInt);
    return localColor;
  }

  public Rectangle getBounds(int paramInt)
  {
    checkWidget();
    if (!isVisible())
      return new Rectangle(-1000, -1000, 0, 0);
    if (!this.parent.isShown(this))
      return new Rectangle(-1000, -1000, 0, 0);
    Point localPoint = this.parent.getOrigin(this.parent.getColumn(paramInt), this);
    if ((localPoint.x < 0) && (this.parent.isRowHeaderVisible()))
      return new Rectangle(-1000, -1000, 0, 0);
    int i = 0;
    int j = getColumnSpan(paramInt);
    for (int k = 0; k <= j; k++)
    {
      if (this.parent.getColumnCount() <= paramInt + k)
        break;
      i += this.parent.getColumn(paramInt + k).getWidth();
    }
    return new Rectangle(localPoint.x, localPoint.y, i - 1, getHeight());
  }

  public boolean getChecked()
  {
    checkWidget();
    return getChecked(0);
  }

  public boolean getChecked(int paramInt)
  {
    checkWidget();
    handleVirtual();
    Boolean localBoolean = (Boolean)this.checks.get(paramInt);
    if (localBoolean == null)
      return false;
    return localBoolean.booleanValue();
  }

  public int getColumnSpan(int paramInt)
  {
    checkWidget();
    Integer localInteger = (Integer)this.columnSpans.get(paramInt);
    if (localInteger == null)
      return 0;
    return localInteger.intValue();
  }

  public Font getFont()
  {
    if (this.defaultFont == null)
      return this.parent.getFont();
    return this.defaultFont;
  }

  public Font getFont(int paramInt)
  {
    checkWidget();
    handleVirtual();
    Font localFont = (Font)this.fonts.get(paramInt);
    if (localFont == null)
      localFont = getFont();
    return localFont;
  }

  public Color getForeground()
  {
    if (this.defaultForeground == null)
      return this.parent.getForeground();
    return this.defaultForeground;
  }

  public Color getForeground(int paramInt)
  {
    checkWidget();
    handleVirtual();
    Color localColor = (Color)this.foregrounds.get(paramInt);
    if (localColor == null)
      localColor = getForeground();
    return localColor;
  }

  public boolean getGrayed()
  {
    return getGrayed(0);
  }

  public boolean getGrayed(int paramInt)
  {
    checkWidget();
    handleVirtual();
    Boolean localBoolean = (Boolean)this.grayeds.get(paramInt);
    if (localBoolean == null)
      return false;
    return localBoolean.booleanValue();
  }

  public int getHeight()
  {
    checkWidget();
    return this.height;
  }

  public Image getImage()
  {
    checkWidget();
    return getImage(0);
  }

  public Image getImage(int paramInt)
  {
    checkWidget();
    handleVirtual();
    return (Image)this.images.get(paramInt);
  }

  public GridItem getItem(int paramInt)
  {
    checkWidget();
    return (GridItem)this.children.get(paramInt);
  }

  public int getItemCount()
  {
    checkWidget();
    return this.children.size();
  }

  public int indexOf(GridItem paramGridItem)
  {
    checkWidget();
    if (paramGridItem == null)
      SWT.error(4);
    if (paramGridItem.isDisposed())
      SWT.error(5);
    return this.children.indexOf(paramGridItem);
  }

  public GridItem[] getItems()
  {
    return (GridItem[])this.children.toArray(new GridItem[this.children.size()]);
  }

  public int getLevel()
  {
    checkWidget();
    return this.level;
  }

  public Grid getParent()
  {
    checkWidget();
    return this.parent;
  }

  public GridItem getParentItem()
  {
    checkWidget();
    return this.parentItem;
  }

  public String getText()
  {
    checkWidget();
    return getText(0);
  }

  public String getText(int paramInt)
  {
    checkWidget();
    handleVirtual();
    String str = (String)this.texts.get(paramInt);
    if (str == null)
      return "";
    return str;
  }

  public boolean hasChildren()
  {
    checkWidget();
    return this.hasChildren;
  }

  public boolean isExpanded()
  {
    checkWidget();
    return this.expanded;
  }

  public void setBackground(Color paramColor)
  {
    checkWidget();
    if ((paramColor != null) && (paramColor.isDisposed()))
      SWT.error(5);
    this.defaultBackground = paramColor;
    this.parent.redraw();
  }

  public void setBackground(int paramInt, Color paramColor)
  {
    checkWidget();
    if ((paramColor != null) && (paramColor.isDisposed()))
      SWT.error(5);
    this.backgrounds.set(paramInt, paramColor);
    this.parent.redraw();
  }

  public void setChecked(boolean paramBoolean)
  {
    checkWidget();
    setChecked(0, paramBoolean);
    this.parent.redraw();
  }

  public void setChecked(int paramInt, boolean paramBoolean)
  {
    checkWidget();
    this.checks.set(paramInt, Boolean.valueOf(paramBoolean));
    this.parent.redraw();
  }

  public void setColumnSpan(int paramInt1, int paramInt2)
  {
    checkWidget();
    this.columnSpans.set(paramInt1, Integer.valueOf(paramInt2));
    this.parent.setHasSpanning(true);
    this.parent.redraw();
  }

  public void setExpanded(boolean paramBoolean)
  {
    checkWidget();
    this.expanded = paramBoolean;
    int i = 0;
    Object localObject = this.children.iterator();
    while (((Iterator)localObject).hasNext())
    {
      GridItem localGridItem = (GridItem)((Iterator)localObject).next();
      localGridItem.setVisible((paramBoolean) && (this.visible));
      if (!paramBoolean)
        if (!getParent().getCellSelectionEnabled())
        {
          if (getParent().isSelected(localGridItem))
          {
            i = 1;
            getParent().deselect(getParent().indexOf(localGridItem));
          }
          if (deselectChildren(localGridItem))
            i = 1;
        }
        else if (deselectCells(localGridItem))
        {
          i = 1;
        }
    }
    getParent().topIndex = -1;
    getParent().bottomIndex = -1;
    getParent().setScrollValuesObsolete();
    if (i != 0)
    {
      localObject = new Event();
      ((Event)localObject).item = this;
      getParent().notifyListeners(13, (Event)localObject);
    }
    if ((getParent().getFocusItem() != null) && (!getParent().getFocusItem().isVisible()))
      getParent().setFocusItem(this);
    if (getParent().getCellSelectionEnabled())
      getParent().updateColumnSelection();
  }

  private boolean deselectCells(GridItem paramGridItem)
  {
    boolean bool = false;
    int i = getParent().indexOf(paramGridItem);
    GridColumn[] arrayOfGridColumn1 = getParent().getColumns();
    Object localObject2;
    for (localObject1 : arrayOfGridColumn1)
    {
      localObject2 = new Point(getParent().indexOf((GridColumn)localObject1), i);
      if (getParent().isCellSelected((Point)localObject2))
      {
        bool = true;
        getParent().deselectCell((Point)localObject2);
      }
    }
    Object localObject1 = paramGridItem.getItems();
    for (GridItem localGridItem : localObject1)
      if (deselectCells(localGridItem))
        bool = true;
    return bool;
  }

  private boolean deselectChildren(GridItem paramGridItem)
  {
    boolean bool = false;
    GridItem[] arrayOfGridItem1 = paramGridItem.getItems();
    for (GridItem localGridItem : arrayOfGridItem1)
    {
      if (getParent().isSelected(localGridItem))
        bool = true;
      getParent().deselect(getParent().indexOf(localGridItem));
      if (deselectChildren(localGridItem))
        bool = true;
    }
    return bool;
  }

  public void setFont(Font paramFont)
  {
    checkWidget();
    if ((paramFont != null) && (paramFont.isDisposed()))
      SWT.error(5);
    this.defaultFont = paramFont;
    this.parent.redraw();
  }

  public void setFont(int paramInt, Font paramFont)
  {
    checkWidget();
    if ((paramFont != null) && (paramFont.isDisposed()))
      SWT.error(5);
    this.fonts.set(paramInt, paramFont);
    this.parent.redraw();
  }

  public void setForeground(Color paramColor)
  {
    checkWidget();
    if ((paramColor != null) && (paramColor.isDisposed()))
      SWT.error(5);
    this.defaultForeground = paramColor;
    this.parent.redraw();
  }

  public void setForeground(int paramInt, Color paramColor)
  {
    checkWidget();
    if ((paramColor != null) && (paramColor.isDisposed()))
      SWT.error(5);
    this.foregrounds.set(paramInt, paramColor);
    this.parent.redraw();
  }

  public void setGrayed(boolean paramBoolean)
  {
    checkWidget();
    setGrayed(0, paramBoolean);
    this.parent.redraw();
  }

  public void setGrayed(int paramInt, boolean paramBoolean)
  {
    checkWidget();
    this.grayeds.set(paramInt, Boolean.valueOf(paramBoolean));
    this.parent.redraw();
  }

  public void setHeight(int paramInt)
  {
    checkWidget();
    if (paramInt < 1)
      SWT.error(5);
    this.height = paramInt;
    this.parent.hasDifferingHeights = true;
    if (isVisible())
    {
      int i = this.parent.indexOf(this);
      if ((this.parent.getTopIndex() <= i) && (i <= this.parent.getBottomIndex()))
        this.parent.bottomIndex = -1;
    }
    this.parent.setScrollValuesObsolete();
    this.parent.redraw();
  }

  public void pack()
  {
    checkWidget();
    int i = 2;
    GridColumn[] arrayOfGridColumn = this.parent.getColumns();
    GC localGC = new GC(this.parent);
    for (int j = 0; j < arrayOfGridColumn.length; j++)
      if (arrayOfGridColumn[j].isVisible())
      {
        GridCellRenderer localGridCellRenderer = arrayOfGridColumn[j].getCellRenderer();
        localGridCellRenderer.setAlignment(arrayOfGridColumn[j].getAlignment());
        localGridCellRenderer.setCheck(arrayOfGridColumn[j].isCheck());
        localGridCellRenderer.setColumn(j);
        localGridCellRenderer.setTree(arrayOfGridColumn[j].isTree());
        localGridCellRenderer.setWordWrap(arrayOfGridColumn[j].getWordWrap());
        Point localPoint = localGridCellRenderer.computeSize(localGC, arrayOfGridColumn[j].getWidth(), -1, this);
        if (localPoint != null)
          i = Math.max(i, localPoint.y);
      }
    localGC.dispose();
    setHeight(i);
  }

  public void setImage(Image paramImage)
  {
    setImage(0, paramImage);
    this.parent.redraw();
  }

  public void setImage(int paramInt, Image paramImage)
  {
    checkWidget();
    if ((paramImage != null) && (paramImage.isDisposed()))
      SWT.error(5);
    this.images.set(paramInt, paramImage);
    this.parent.imageSetOnItem(paramInt, this);
    this.parent.redraw();
  }

  public void setText(int paramInt, String paramString)
  {
    checkWidget();
    if (paramString == null)
      SWT.error(4);
    this.texts.set(paramInt, paramString);
    this.parent.redraw();
  }

  public void setText(String paramString)
  {
    setText(0, paramString);
    this.parent.redraw();
  }

  private void ensureSize(ArrayList paramArrayList)
  {
    int i = Math.max(1, this.parent.getColumnCount());
    paramArrayList.ensureCapacity(i);
    while (paramArrayList.size() <= i)
      paramArrayList.add(null);
  }

  private void remove(GridItem paramGridItem)
  {
    this.children.remove(paramGridItem);
    this.hasChildren = (this.children.size() > 0);
  }

  boolean isVisible()
  {
    return this.visible;
  }

  void newItem(GridItem paramGridItem, int paramInt)
  {
    setHasChildren(true);
    if (paramInt == -1)
      this.children.add(paramGridItem);
    else
      this.children.add(paramInt, paramGridItem);
  }

  void setHasChildren(boolean paramBoolean)
  {
    this.hasChildren = paramBoolean;
  }

  void setVisible(boolean paramBoolean)
  {
    if (this.visible == paramBoolean)
      return;
    this.visible = paramBoolean;
    if (paramBoolean)
      this.parent.updateVisibleItems(1);
    else
      this.parent.updateVisibleItems(-1);
    if (this.hasChildren)
    {
      boolean bool = paramBoolean;
      if (paramBoolean)
        bool = this.expanded;
      Iterator localIterator = this.children.iterator();
      while (localIterator.hasNext())
      {
        GridItem localGridItem = (GridItem)localIterator.next();
        localGridItem.setVisible(bool);
      }
    }
  }

  public String getHeaderText()
  {
    checkWidget();
    return this.headerText;
  }

  public Image getHeaderImage()
  {
    checkWidget();
    return this.headerImage;
  }

  public void setHeaderText(String paramString)
  {
    checkWidget();
    if (paramString != this.headerText)
    {
      GC localGC = new GC(this.parent);
      int i = this.parent.getRowHeaderRenderer().computeSize(localGC, -1, -1, this).x;
      this.headerText = paramString;
      int j = this.parent.getRowHeaderRenderer().computeSize(localGC, -1, -1, this).x;
      localGC.dispose();
      this.parent.recalculateRowHeaderWidth(this, i, j);
    }
    this.parent.redraw();
  }

  public void setHeaderImage(Image paramImage)
  {
    checkWidget();
    if (paramImage != this.headerImage)
    {
      GC localGC = new GC(this.parent);
      int i = this.parent.getRowHeaderRenderer().computeSize(localGC, -1, -1, this).x;
      int j = this.parent.getRowHeaderRenderer().computeSize(localGC, -1, -1, this).y;
      this.headerImage = paramImage;
      int k = this.parent.getRowHeaderRenderer().computeSize(localGC, -1, -1, this).x;
      int m = this.parent.getRowHeaderRenderer().computeSize(localGC, -1, -1, this).y;
      localGC.dispose();
      this.parent.recalculateRowHeaderWidth(this, i, k);
      this.parent.recalculateRowHeaderHeight(this, j, m);
    }
    this.parent.redraw();
  }

  public boolean getCheckable(int paramInt)
  {
    checkWidget();
    if (!this.parent.getColumn(paramInt).getCheckable())
      return false;
    Boolean localBoolean = (Boolean)this.checkable.get(paramInt);
    if (localBoolean == null)
      return true;
    return localBoolean.booleanValue();
  }

  public void setCheckable(int paramInt, boolean paramBoolean)
  {
    checkWidget();
    this.checkable.set(paramInt, Boolean.valueOf(paramBoolean));
  }

  public String getToolTipText(int paramInt)
  {
    checkWidget();
    handleVirtual();
    String str = (String)this.tooltips.get(paramInt);
    return str;
  }

  public void setToolTipText(int paramInt, String paramString)
  {
    checkWidget();
    this.tooltips.set(paramInt, paramString);
  }

  private void init()
  {
    ensureSize(this.backgrounds);
    ensureSize(this.checks);
    ensureSize(this.checkable);
    ensureSize(this.fonts);
    ensureSize(this.foregrounds);
    ensureSize(this.grayeds);
    ensureSize(this.images);
    ensureSize(this.texts);
    ensureSize(this.columnSpans);
    ensureSize(this.tooltips);
  }

  void columnRemoved(int paramInt)
  {
    removeValue(paramInt, this.backgrounds);
    removeValue(paramInt, this.checks);
    removeValue(paramInt, this.checkable);
    removeValue(paramInt, this.fonts);
    removeValue(paramInt, this.foregrounds);
    removeValue(paramInt, this.grayeds);
    removeValue(paramInt, this.images);
    removeValue(paramInt, this.texts);
    removeValue(paramInt, this.columnSpans);
    removeValue(paramInt, this.tooltips);
  }

  void columnAdded(int paramInt)
  {
    insertValue(paramInt, this.backgrounds);
    insertValue(paramInt, this.checks);
    insertValue(paramInt, this.checkable);
    insertValue(paramInt, this.fonts);
    insertValue(paramInt, this.foregrounds);
    insertValue(paramInt, this.grayeds);
    insertValue(paramInt, this.images);
    insertValue(paramInt, this.texts);
    insertValue(paramInt, this.columnSpans);
    insertValue(paramInt, this.tooltips);
    this.hasSetData = false;
  }

  private void insertValue(int paramInt, List paramList)
  {
    if (paramInt == -1)
      paramList.add(null);
    else
      paramList.add(paramInt, null);
  }

  private void removeValue(int paramInt, List paramList)
  {
    if (paramList.size() > paramInt)
      paramList.remove(paramInt);
  }

  private void handleVirtual()
  {
    if (((getParent().getStyle() & 0x10000000) != 0) && (!this.hasSetData))
    {
      this.hasSetData = true;
      Event localEvent = new Event();
      localEvent.item = this;
      if (this.parentItem == null)
        localEvent.index = getParent().indexOf(this);
      else
        localEvent.index = this.parentItem.indexOf(this);
      getParent().notifyListeners(36, localEvent);
    }
  }

  void initializeHeight(int paramInt)
  {
    this.height = paramInt;
  }

  void clear(boolean paramBoolean)
  {
    this.backgrounds.clear();
    this.checks.clear();
    this.checkable.clear();
    this.columnSpans.clear();
    this.fonts.clear();
    this.foregrounds.clear();
    this.grayeds.clear();
    this.images.clear();
    this.texts.clear();
    this.tooltips.clear();
    this.defaultForeground = null;
    this.defaultBackground = null;
    this.defaultFont = null;
    this.hasSetData = false;
    this.headerText = null;
    this.headerImage = null;
    if (paramBoolean)
      for (int i = this.children.size() - 1; i >= 0; i--)
        ((GridItem)this.children.get(i)).clear(true);
    init();
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridItem
 * JD-Core Version:    0.6.2
 */