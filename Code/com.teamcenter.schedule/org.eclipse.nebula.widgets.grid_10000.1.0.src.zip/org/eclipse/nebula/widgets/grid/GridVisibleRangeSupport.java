package org.eclipse.nebula.widgets.grid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.EventObject;
import java.util.Iterator;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

public class GridVisibleRangeSupport
{
  private Collection rangeChangeListener;
  private Grid grid;
  private Grid.GridVisibleRange oldRange = new Grid.GridVisibleRange();
  private Listener paintListener = new Listener()
  {
    public void handleEvent(Event paramAnonymousEvent)
    {
      GridVisibleRangeSupport.this.calculateChange();
    }
  };

  private GridVisibleRangeSupport(Grid paramGrid)
  {
    this.grid = paramGrid;
    this.grid.setSizeOnEveryItemImageChange(true);
    paramGrid.addListener(9, this.paintListener);
  }

  public void addRangeChangeListener(VisibleRangeChangedListener paramVisibleRangeChangedListener)
  {
    if (this.rangeChangeListener == null)
      this.rangeChangeListener = new ArrayList();
    this.rangeChangeListener.add(paramVisibleRangeChangedListener);
  }

  public void removeRangeChangeListener(VisibleRangeChangedListener paramVisibleRangeChangedListener)
  {
    if (this.rangeChangeListener != null)
    {
      this.rangeChangeListener.remove(paramVisibleRangeChangedListener);
      if (this.rangeChangeListener.size() == 0)
        this.rangeChangeListener = null;
    }
  }

  private void calculateChange()
  {
    if (this.rangeChangeListener != null)
    {
      Grid.GridVisibleRange localGridVisibleRange = this.grid.getVisibleRange();
      ArrayList localArrayList1 = new ArrayList();
      localArrayList1.addAll(Arrays.asList(this.oldRange.getItems()));
      ArrayList localArrayList2 = new ArrayList();
      localArrayList2.addAll(Arrays.asList(localGridVisibleRange.getItems()));
      Iterator localIterator = localArrayList2.iterator();
      while (localIterator.hasNext())
        if (localArrayList1.remove(localIterator.next()))
          localIterator.remove();
      ArrayList localArrayList3 = new ArrayList();
      localArrayList3.addAll(Arrays.asList(this.oldRange.getColumns()));
      ArrayList localArrayList4 = new ArrayList();
      localArrayList4.addAll(Arrays.asList(localGridVisibleRange.getColumns()));
      localIterator = localArrayList4.iterator();
      while (localIterator.hasNext())
        if (localArrayList3.remove(localIterator.next()))
          localIterator.remove();
      if ((localArrayList1.size() != 0) || (localArrayList2.size() != 0) || (localArrayList3.size() != 0) || (localArrayList4.size() != 0))
      {
        RangeChangedEvent localRangeChangedEvent = new RangeChangedEvent(this.grid, localGridVisibleRange);
        localRangeChangedEvent.addedRows = new GridItem[localArrayList2.size()];
        localArrayList2.toArray(localRangeChangedEvent.addedRows);
        localRangeChangedEvent.removedRows = new GridItem[localArrayList1.size()];
        localArrayList1.toArray(localRangeChangedEvent.removedRows);
        localRangeChangedEvent.addedColumns = new GridColumn[localArrayList4.size()];
        localArrayList4.toArray(localRangeChangedEvent.addedColumns);
        localRangeChangedEvent.removedColumns = new GridColumn[localArrayList3.size()];
        localArrayList4.toArray(localRangeChangedEvent.removedColumns);
        localIterator = this.rangeChangeListener.iterator();
        while (localIterator.hasNext())
          ((VisibleRangeChangedListener)localIterator.next()).rangeChanged(localRangeChangedEvent);
      }
      this.oldRange = localGridVisibleRange;
    }
  }

  public static GridVisibleRangeSupport createFor(Grid paramGrid)
  {
    return new GridVisibleRangeSupport(paramGrid);
  }

  public static class RangeChangedEvent extends EventObject
  {
    private static final long serialVersionUID = 1L;
    public GridItem[] addedRows;
    public GridItem[] removedRows;
    public GridColumn[] addedColumns;
    public GridColumn[] removedColumns;
    public Grid.GridVisibleRange visibleRange;

    RangeChangedEvent(Grid paramGrid, Grid.GridVisibleRange paramGridVisibleRange)
    {
      super();
      this.visibleRange = paramGridVisibleRange;
    }
  }

  public static abstract interface VisibleRangeChangedListener
  {
    public abstract void rangeChanged(GridVisibleRangeSupport.RangeChangedEvent paramRangeChangedEvent);
  }
}

/* Location:           D:\SPML_Prod_replica\TC10\TC_Root\portal\plugins\org.eclipse.nebula.widgets.grid_10000.1.0.jar
 * Qualified Name:     org.eclipse.nebula.widgets.grid.GridVisibleRangeSupport
 * JD-Core Version:    0.6.2
 */